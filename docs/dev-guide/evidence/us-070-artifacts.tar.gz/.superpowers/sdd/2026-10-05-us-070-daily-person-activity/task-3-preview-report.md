# Task 3 touched preview round 1

Authority base: `ed9ff60d9dda6aaf78fae5e9a61d189b1a8e4108`; Task 3 delta base: `cfcfe8d1821cb73b83bc47a379f63b8f35530d68`; committed HEAD: `8f3d39370c8625f2465d089b6a80e6caf9ee7f97`.

Ordinary preflight exit 0: expected 5 shards, actual 7, mismatch true. Exact manifest: `task-3-round1-preflight-manifest.json`. Changed production intersection: analytics-activity.ts, deferred.ts, analytics-ingestion.ts (import extension correction). Selected three exact manifest shards; schema/contracts/provider/dispatch retained unaffected and not rerun.

Fresh migrated ledger_owner/ledger_app fixture pair stayed alive across all previews; URLs remained child-process environment only. Fixture stop ran in finally and reported AggregateError `PostgreSQL fixture cleanup failed`; post-run docker ps contains only existing nous-db/nous-keycloak, confirming the isolated PostgreSQL container was removed. Cleanup failure remains infrastructure evidence; individual underlying errors were not exposed by launcher.

Execution artifact: `task-3-preview-round1-execution.json`; launcher log: `task-3-fixture-launcher-round1.log`. Start 2026-10-06T03:45:41.019Z; end 2026-10-06T03:53:44.608Z. Preview command total: 8.006550 minutes.

No cache clear, configuration/router/tooling change, production/test mutation, authoritative test_report, or survivor self-approval.

| Shard | Exit | Minutes | Counts | JSON artifact |
|---|---:|---:|---|---|
| vitest-3ff43baf3f6d | 1 | 3.026983 | NoCoverage=5; Killed=96; Survived=20; Timeout=1 | `reports/mutation/vitest-3ff43baf3f6d-23093-1791258344528-1ab2290fec8a58.json` (manifest `task-3-preview-vitest-3ff43baf3f6d-round1-manifest.json`) |
| vitest-4795ff5a0847 | 1 | 0.254217 | NoCoverage=4; Killed=4; Survived=1 | `reports/mutation/vitest-4795ff5a0847-27108-1791258526217-280e55c97652b8.json` (manifest `task-3-preview-vitest-4795ff5a0847-round1-manifest.json`) |
| vitest-7e4dfff580cb | 0 | 4.725350 | NoCoverage=2; Killed=296; Survived=22 | `reports/mutation/vitest-7e4dfff580cb-27541-1791258541448-ff881367b8e1e.json` (manifest `task-3-preview-vitest-7e4dfff580cb-round1-manifest.json`) |

All surviving and NoCoverage mutants below await reviewer disposition. No equivalence or acceptance is claimed.

```text
vitest-3ff43baf3f6d/14 apps/worker/src/jobs/analytics-activity.ts:31 NoCoverage StringLiteral replacement="\"\""
vitest-3ff43baf3f6d/33 apps/worker/src/jobs/analytics-activity.ts:32 NoCoverage StringLiteral replacement="\"\""
vitest-3ff43baf3f6d/60 apps/worker/src/jobs/analytics-activity.ts:44 NoCoverage ObjectLiteral replacement="{}"
vitest-3ff43baf3f6d/66 apps/worker/src/jobs/analytics-activity.ts:46 NoCoverage StringLiteral replacement="\"\""
vitest-3ff43baf3f6d/94 apps/worker/src/jobs/analytics-activity.ts:66 NoCoverage StringLiteral replacement="\"\""
vitest-3ff43baf3f6d/3 apps/worker/src/jobs/analytics-activity.ts:26 Survived ArrowFunction replacement="() => undefined"
vitest-3ff43baf3f6d/10 apps/worker/src/jobs/analytics-activity.ts:31 Survived ConditionalExpression replacement="false"
vitest-3ff43baf3f6d/11 apps/worker/src/jobs/analytics-activity.ts:31 Survived LogicalOperator replacement="!(input.at instanceof Date) && !Number.isFinite(input.at.getTime())"
vitest-3ff43baf3f6d/16 apps/worker/src/jobs/analytics-activity.ts:32 Survived ConditionalExpression replacement="false"
vitest-3ff43baf3f6d/21 apps/worker/src/jobs/analytics-activity.ts:32 Survived Regex replacement="/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i"
vitest-3ff43baf3f6d/22 apps/worker/src/jobs/analytics-activity.ts:32 Survived Regex replacement="/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i"
vitest-3ff43baf3f6d/39 apps/worker/src/jobs/analytics-activity.ts:38 Survived ConditionalExpression replacement="false"
vitest-3ff43baf3f6d/46 apps/worker/src/jobs/analytics-activity.ts:40 Survived ConditionalExpression replacement="true"
vitest-3ff43baf3f6d/59 apps/worker/src/jobs/analytics-activity.ts:44 Survived ConditionalExpression replacement="false"
vitest-3ff43baf3f6d/61 apps/worker/src/jobs/analytics-activity.ts:45 Survived MethodExpression replacement="options.kekFile"
vitest-3ff43baf3f6d/62 apps/worker/src/jobs/analytics-activity.ts:45 Survived OptionalChaining replacement="options.kekFile.trim"
vitest-3ff43baf3f6d/65 apps/worker/src/jobs/analytics-activity.ts:46 Survived ConditionalExpression replacement="false"
vitest-3ff43baf3f6d/91 apps/worker/src/jobs/analytics-activity.ts:66 Survived ConditionalExpression replacement="false"
vitest-3ff43baf3f6d/93 apps/worker/src/jobs/analytics-activity.ts:66 Survived StringLiteral replacement="\"\""
vitest-3ff43baf3f6d/99 apps/worker/src/jobs/analytics-activity.ts:71 Survived StringLiteral replacement="\"\""
vitest-3ff43baf3f6d/106 apps/worker/src/jobs/analytics-activity.ts:75 Survived StringLiteral replacement="\"\""
vitest-3ff43baf3f6d/107 apps/worker/src/jobs/analytics-activity.ts:76 Survived ObjectLiteral replacement="{}"
vitest-3ff43baf3f6d/113 apps/worker/src/jobs/analytics-activity.ts:80 Survived StringLiteral replacement="\"\""
vitest-3ff43baf3f6d/116 apps/worker/src/jobs/analytics-activity.ts:81 Survived StringLiteral replacement="\"\""
vitest-3ff43baf3f6d/119 apps/worker/src/jobs/analytics-activity.ts:82 Survived StringLiteral replacement="\"\""
vitest-4795ff5a0847/5 apps/worker/src/jobs/deferred.ts:44 NoCoverage ObjectLiteral replacement="{}"
vitest-4795ff5a0847/6 apps/worker/src/jobs/deferred.ts:45 NoCoverage BlockStatement replacement="{}"
vitest-4795ff5a0847/7 apps/worker/src/jobs/deferred.ts:45 NoCoverage ObjectLiteral replacement="{}"
vitest-4795ff5a0847/8 apps/worker/src/jobs/deferred.ts:46 NoCoverage BlockStatement replacement="{}"
vitest-4795ff5a0847/2 apps/worker/src/jobs/deferred.ts:43 Survived ConditionalExpression replacement="true"
vitest-7e4dfff580cb/85 packages/db/src/analytics-ingestion.ts:52 NoCoverage StringLiteral replacement="``"
vitest-7e4dfff580cb/86 packages/db/src/analytics-ingestion.ts:52 NoCoverage StringLiteral replacement="\"\""
vitest-7e4dfff580cb/24 packages/db/src/analytics-ingestion.ts:37 Survived ConditionalExpression replacement="false"
vitest-7e4dfff580cb/25 packages/db/src/analytics-ingestion.ts:37 Survived LogicalOperator replacement="typeof value !== \"string\" && !/^\\d{4}-\\d{2}-\\d{2}$/.test(value)"
vitest-7e4dfff580cb/26 packages/db/src/analytics-ingestion.ts:37 Survived ConditionalExpression replacement="false"
vitest-7e4dfff580cb/30 packages/db/src/analytics-ingestion.ts:37 Survived Regex replacement="/\\d{4}-\\d{2}-\\d{2}$/"
vitest-7e4dfff580cb/31 packages/db/src/analytics-ingestion.ts:37 Survived Regex replacement="/^\\d{4}-\\d{2}-\\d{2}/"
vitest-7e4dfff580cb/75 packages/db/src/analytics-ingestion.ts:51 Survived ConditionalExpression replacement="true"
vitest-7e4dfff580cb/79 packages/db/src/analytics-ingestion.ts:51 Survived EqualityOperator replacement="value !== null"
vitest-7e4dfff580cb/81 packages/db/src/analytics-ingestion.ts:51 Survived EqualityOperator replacement="typeof value === \"object\""
vitest-7e4dfff580cb/82 packages/db/src/analytics-ingestion.ts:51 Survived StringLiteral replacement="\"\""
vitest-7e4dfff580cb/84 packages/db/src/analytics-ingestion.ts:52 Survived ConditionalExpression replacement="false"
vitest-7e4dfff580cb/88 packages/db/src/analytics-ingestion.ts:53 Survived MethodExpression replacement="Object.entries(value)"
vitest-7e4dfff580cb/89 packages/db/src/analytics-ingestion.ts:53 Survived ArrowFunction replacement="() => undefined"
vitest-7e4dfff580cb/92 packages/db/src/analytics-ingestion.ts:54 Survived StringLiteral replacement="\"\""
vitest-7e4dfff580cb/149 packages/db/src/analytics-ingestion.ts:75 Survived ConditionalExpression replacement="false"
vitest-7e4dfff580cb/163 packages/db/src/analytics-ingestion.ts:81 Survived ConditionalExpression replacement="true"
vitest-7e4dfff580cb/166 packages/db/src/analytics-ingestion.ts:87 Survived BooleanLiteral replacement="true"
vitest-7e4dfff580cb/228 packages/db/src/analytics-ingestion.ts:134 Survived ObjectLiteral replacement="{}"
vitest-7e4dfff580cb/238 packages/db/src/analytics-ingestion.ts:136 Survived ObjectLiteral replacement="{}"
vitest-7e4dfff580cb/245 packages/db/src/analytics-ingestion.ts:139 Survived ObjectLiteral replacement="{}"
vitest-7e4dfff580cb/298 packages/db/src/analytics-ingestion.ts:163 Survived ConditionalExpression replacement="false"
vitest-7e4dfff580cb/299 packages/db/src/analytics-ingestion.ts:163 Survived LogicalOperator replacement="!current && current.syncedAt.getTime() < batch.syncedAt.getTime()"
vitest-7e4dfff580cb/301 packages/db/src/analytics-ingestion.ts:163 Survived ConditionalExpression replacement="false"
```

## Cleanup reconciliation (read-only; no rerun)

Named observed infrastructure failure: isolated `fixture.stop()` threw `AggregateError: PostgreSQL fixture cleanup failed`, causing launcher exit **1** after all three preview commands finished. The launcher catches the error and persists only `e.message`; it does not persist `AggregateError.errors`, PostgreSQL codes, or stack. Therefore the exact nested SQL errors are irrecoverable from this run's log/runtime, and no exact SQL cause is asserted.

Teardown ordering rules out a separate cluster-stop race: this launcher uses only `createPostgresFixture({isolatedContainer:true})`, no shared cluster handle or separate cluster stop. Private fixture teardown drains/terminates original-database backends, drops the original database, drops ledger_app and ledger_owner roles, ends the maintenance client, then stops its container (postgres-container.ts:436 onward). An AggregateError means at least two of these steps failed, and teardown continues through container stop.

Concrete causal evidence: activity artifact mutant **120** is Timeout, `apps/worker/src/jobs/analytics-activity.ts:83`, BlockStatement replacement `{}`. It removes the `finally { client.release(); }` body. The suite awaits job.close() before afterAll; missing release can stall pool.end(), causing worker timeout before clone fixture cleanup. Mutation fixtures allocate `ledger_mutation_*` databases using shared ledger_owner/ledger_app roles. The leading supported inference is a timeout-abandoned mutation clone retaining both roles' dependencies, causing the two DROP ROLE steps to fail. This is a mutation-induced pool-resource defect under test, not an observed ordinary-code pool leak; exact PostgreSQL error codes remain unavailable.

Containment proof: immediately after launcher exit, `rtk proxy docker ps --format '{{.ID}} {{.Image}} {{.Names}} {{.CreatedAt}}'` returned only `b6a76a09392e quay.io/keycloak/keycloak:26.0 nous-keycloak` and `c7bcabcff09b pgvector/pgvector:pg17 nous-db`, both created September 29. No isolated PostgreSQL16 preview container remained. The private server and any abandoned clones were removed despite cleanup SQL errors.

Next scratch launcher should preserve sanitized nested `AggregateError.errors` (name/message/code and teardown context) before reporting cleanup failure. A shared-cluster launcher can stop the owning cluster in a final outer finally after fixture cleanup; private-fixture launchers already stop their container within fixture.stop. Do not classify cleanup success based solely on command results, and do not silently suppress unclassified role/database errors. No launcher, production, test, configuration, or runtime mutation was made during this reconciliation.

## Task 3 touched preview round 2

Source cutoff `927835e559d3b330f3c49436ca095939f3a21216`; delta base `8f3d39370c8625f2465d089b6a80e6caf9ee7f97`; authority base `ed9ff60d9dda6aaf78fae5e9a61d189b1a8e4108`, work ID US-070. Ordinary preflight exit 0: 7 actual vs 5 expected, mismatch true; exact mapping `task-3-round2-preflight-manifest.json`. Only current job and deferred changed/test-seam sources intersected; ingestion/schema/contracts/provider/dispatch retained without rerun.

Actual fresh migrated owner/app pair remained alive through both preview commands. Start 2026-10-06T04:08:56.666Z; end 2026-10-06T04:12:50.977Z; preview total 3.852767 minutes.

Execution `task-3-preview-round2-execution.json`; launcher `task-3-fixture-launcher-round2.log`. No cache clear, authoritative campaign/test_report, or repository production/test/config/harness edits. Scratch launcher records sanitized nested cleanup errors.

| Shard/source | Exit | Minutes | Counts | Score | JSON artifact |
|---|---:|---:|---|---:|---|
| vitest-e927482a8578 / apps/worker/src/jobs/analytics-activity.ts | 0 | 3.186033 | NoCoverage=2; Killed=108; Survived=7; Timeout=1 | 92.37% | `reports/mutation/vitest-e927482a8578-45612-1791259740184-1506af9b554a88.json` (manifest `task-3-preview-vitest-e927482a8578-round2-manifest.json`) |
| vitest-f2d1787d45e2 / apps/worker/src/jobs/deferred.ts | 0 | 0.666733 | Killed=9 | 100.00% | `reports/mutation/vitest-f2d1787d45e2-49597-1791259931399-a9fee4af13076.json` (manifest `task-3-preview-vitest-f2d1787d45e2-round2-manifest.json`) |

Cleanup **failed**, launcher exit **1** after both previews passed: nested PostgreSQL **2BP01** errors explicitly say role ledger_app and role ledger_owner cannot be dropped because objects depend on them. This establishes role-dependency teardown failure, not fixture/cluster-stop ordering. The underlying dependent database/object names are not present in messages; abandoned mutation clone dependencies remain the supported explanation, not an exact allocation identification. Fixture.stop nevertheless reached container.stop. Post-run Docker inventory shows only existing nous-keycloak/nous-db plus testcontainers Ryuk; **no PostgreSQL16 fixture container remains**. Next disposable launcher can own a shared cluster, drop its fixture first and stop its cluster in outer finally, avoiding global role-drop cleanup of clone dependencies; do not suppress the present failure.

Own rollout pointer and measured token/call metadata are unavailable through this agent session; no unrelated session metadata was inspected. Preview command timings are measured execution artifacts. Preserve both report and referenced JSON artifacts before scratch deletion.

Current residuals await reviewer disposition; no self-approval:

```text
vitest-e927482a8578/66 apps/worker/src/jobs/analytics-activity.ts:63 NoCoverage StringLiteral replacement="\"\""
vitest-e927482a8578/94 apps/worker/src/jobs/analytics-activity.ts:97 NoCoverage StringLiteral replacement="\"\""
vitest-e927482a8578/39 apps/worker/src/jobs/analytics-activity.ts:51 Survived ConditionalExpression replacement="false"
vitest-e927482a8578/61 apps/worker/src/jobs/analytics-activity.ts:61 Survived MethodExpression replacement="options.kekFile"
vitest-e927482a8578/62 apps/worker/src/jobs/analytics-activity.ts:61 Survived OptionalChaining replacement="options.kekFile.trim"
vitest-e927482a8578/65 apps/worker/src/jobs/analytics-activity.ts:62 Survived ConditionalExpression replacement="false"
vitest-e927482a8578/91 apps/worker/src/jobs/analytics-activity.ts:96 Survived ConditionalExpression replacement="false"
vitest-e927482a8578/93 apps/worker/src/jobs/analytics-activity.ts:96 Survived StringLiteral replacement="\"\""
vitest-e927482a8578/99 apps/worker/src/jobs/analytics-activity.ts:104 Survived ObjectLiteral replacement="{}"
```
