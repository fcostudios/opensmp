# Task3 fix round1 scoped re-review — 8f3d393..927835e

## Finding verdicts

**I1 — outer transaction accidentally committed by first shared batch: ADDRESSED.** analytics-activity.ts:104–133 now uses db.transaction(async tx) and passes the actual tx to resolveActivityScopes, ingestActivityBatch and global warning inserts. The shared helper's nested transaction now uses savepoints; account/vendor FOR SHARE at :108–117 persists through outer completion. No raw BEGIN/COMMIT/ROLLBACK remains. Processing increments only after outer commit; client release remains in finally (:135–136).

Real database tests analytics-activity.integration.test.ts:230–267 synchronize at later global warning with a real advisory-lock trigger, then assert account opt-in and vendor usage changes both fail SQL55P03. :270–286 injects late global audit failure after both company batches and asserts zero rows/audits plus no open transaction before close. Worker report records initial2FAIL (disable erroneously succeeded;2rows remained), then2PASS, and final covering27PASS/worker type-check. These exact failures establish a load-bearing oracle for the former defect without owned mocks.

**I2 — nineteen genuine worker/deferred boundary residuals: ADDRESSED.** Invalid Date/UUID prefix/suffix (:289–300), unsupported global/targeted protocol without KEK (:303–317), exact entity attribution (:76–82), injected sixty-first-request limiter timing (:320–348), and real session transaction checks (:219–228) constrain named previous faults. Raw transaction mutants disappear through the actual transaction repair; later failure/lock oracles constrain their replacement lifetime. Deferred.test.ts:16–18 statically imports established integration scenarios, causing selected seam to execute services-backed handler/processed/finally contracts with real storage. Static import avoids router/config/harness edits and owned mocks; deliberate duplicate execution cost is disclosed in the report (27 total focused executions). Current worker9 residuals are all retained equivalent/accepted semantics; deferred9/9 mutants are Killed, confirming closure.

**M1 — compressed formatting: ADDRESSED.** Expanded production transaction/options/lifetime blocks and test bodies make the new boundaries readable (analytics-activity.ts:104–138; deferred.ts:44–58). Some SQL literals remain long but this does not obscure transaction ownership.

## New breakage in fix diff

None identified. Actual transaction callback finalizes zero-eligibility returns and failure before client release. SQL account filtering, trusted company authority, UTC calendar calculation, freshness and sanitized metadata retain prior semantics; new runtime change is restricted to the transaction lifetime. Tests use real DB triggers and finally restore vendor configuration, triggers/advisory resources and job ownership. No migration/shared provider/credential architecture change.

## Out-of-scope observations

Retained two-role credential composition and authority/migration/broad gates remain controller-owned as recorded in initial review. Previous preview cleanup failure is historical infrastructure evidence, not proven ordinary-code leakage; current preview cleanup must be assessed independently.

## Review checks

Read controller-resume-2 first, original I1/I2 verbatim, appended worker report and re-review-prompt. Read supplied fix diff once; the first tool response truncated its middle, so read only the omitted test hunks to complete that pass. No changed-source reread, git command, production/test/index/HEAD edit, subagent or test rerun. No outside-code check was required because unchanged driver semantics were verified in initial review and new actual tx usage is explicit in supplied diff.

## Verdict

**Spec compliance: APPROVED. Task quality: APPROVED.** All prior findings addressed, no new Critical/Important breakage. Current touched/retained residuals are33:24 equivalent/9 accepted/0 unapproved. Controller-owned infrastructure cleanup and broader gates remain explicitly outstanding.

## Current exact worker residual approvals

Evidence: reports/mutation/vitest-e927482a8578-45612-1791259740184-1506af9b554a88.json. 118 mutants; current9 residuals,5 equivalent/4 accepted. All formerly genuine worker semantic categories killed or removed by the actual transaction replacement; schema config mutant remapped107→99.

66 apps/worker/src/jobs/analytics-activity.ts:63:25 NoCoverage replacement='""' @accepted: Missing KEK still rejects; this untyped prose diagnostic is not specified.

94 apps/worker/src/jobs/analytics-activity.ts:97:29 NoCoverage replacement='""' @equivalent: Fixed rest implementation only returns provider/capacity failures or success; unsupported result cannot reach this branch.

39 apps/worker/src/jobs/analytics-activity.ts:51:11 Survived replacement='false' @equivalent: Empty account rows produce empty eligible rows, and the unchanged eligible-length return still exits before KEK/credentials.

61 apps/worker/src/jobs/analytics-activity.ts:61:20 Survived replacement='options.kekFile' @accepted: Whitespace-padded KEK paths change acceptance only; the declared configuration does not promise whitespace normalization and valid file paths retain behavior.

62 apps/worker/src/jobs/analytics-activity.ts:61:20 Survived replacement='options.kekFile.trim' @accepted: Absent KEK configuration still rejects; removing optional access changes only untyped failure diagnostics.

65 apps/worker/src/jobs/analytics-activity.ts:62:11 Survived replacement='false' @accepted: Absent or empty KEK path still rejects inside the real readKekFile validation; the prose diagnostic is not specified.

91 apps/worker/src/jobs/analytics-activity.ts:96:15 Survived replacement='false' @equivalent: Shipped fixed Anthropic rest syncActivity never produces unsupported, leaving identical provider-failure conversion.

93 apps/worker/src/jobs/analytics-activity.ts:96:33 Survived replacement='""' @equivalent: Shipped fixed Anthropic rest syncActivity never produces unsupported, so this comparison remains false.

99 apps/worker/src/jobs/analytics-activity.ts:104:38 Survived replacement='{}' @equivalent: Only explicit table query builders are used; schema-less Drizzle preserves select/insert/transaction behavior because no relational db.query API is used.


## Retained exact ingestion approvals

Ingestion source/tests are unchanged by this fix; retain the independently exact-verified round1 artifact reports/mutation/vitest-7e4dfff580cb-27541-1791258541448-ff881367b8e1e.json. 24 retained residuals:19 equivalent/5 accepted/0 unapproved. No ingestion preview was repeated.

85 packages/db/src/analytics-ingestion.ts:52:36 NoCoverage replacement="``" @equivalent: array canonical representation is unreachable for normalized allowlisted nullable integer/object counters.

86 packages/db/src/analytics-ingestion.ts:52:66 NoCoverage replacement="\"\"" @equivalent: array separator is unreachable because normalized counter trees contain no arrays.

24 packages/db/src/analytics-ingestion.ts:37:7 Survived replacement="false" @accepted: Exact ISO roundtrip preserves rejection and acceptance for JSON date inputs; malformed non-JSON Symbol/coercion values can change diagnostics, which the date contract does not specify. This is narrowly accepted, not literal equivalence.

25 packages/db/src/analytics-ingestion.ts:37:7 Survived replacement="typeof value !== \"string\" && !/^\\d{4}-\\d{2}-\\d{2}$/.test(value)" @accepted: Exact ISO roundtrip preserves rejection and acceptance for JSON date inputs; malformed non-JSON Symbol/coercion values can change diagnostics, which the date contract does not specify. This is narrowly accepted, not literal equivalence.

26 packages/db/src/analytics-ingestion.ts:37:7 Survived replacement="false" @accepted: Exact ISO roundtrip preserves rejection and acceptance for JSON date inputs; malformed non-JSON Symbol/coercion values can change diagnostics, which the date contract does not specify. This is narrowly accepted, not literal equivalence.

30 packages/db/src/analytics-ingestion.ts:37:37 Survived replacement="/\\d{4}-\\d{2}-\\d{2}$/" @equivalent: removing the regex start anchor cannot bypass exact ISO-date equality against the whole original string.

31 packages/db/src/analytics-ingestion.ts:37:37 Survived replacement="/^\\d{4}-\\d{2}-\\d{2}/" @equivalent: removing the regex end anchor cannot bypass exact ISO-date equality against the whole original string.

75 packages/db/src/analytics-ingestion.ts:51:7 Survived replacement="true" @equivalent: duplicate counters were reconstructed in deterministic allowlist key order; JSON.stringify of that complete tree has the same equality relation as recursive canonical encoding.

79 packages/db/src/analytics-ingestion.ts:51:7 Survived replacement="value !== null" @equivalent: normalized counter roots are nonnull objects, so this mutation serializes the complete deterministically ordered tree and preserves duplicate equality.

81 packages/db/src/analytics-ingestion.ts:51:25 Survived replacement="typeof value === \"object\"" @equivalent: serializing the complete normalized object tree preserves all nullable integer values and duplicate equality because reconstruction fixes key order.

82 packages/db/src/analytics-ingestion.ts:51:42 Survived replacement="\"\"" @equivalent: replacing the object type string makes the root serialize directly; normalized key order and full-tree duplicate equality remain deterministic.

84 packages/db/src/analytics-ingestion.ts:52:7 Survived replacement="false" @equivalent: counter normalization rejects arrays on every known path, so canonical never receives an array.

88 packages/db/src/analytics-ingestion.ts:53:14 Survived replacement="Object.entries(value)" @equivalent: normalization reconstructs every object in a fixed allowlist order, so removing canonical sorting cannot change duplicate equality.

89 packages/db/src/analytics-ingestion.ts:53:41 Survived replacement="() => undefined" @equivalent: retaining the reconstructed object order instead of sorting preserves deterministic equality for supported counter trees.

92 packages/db/src/analytics-ingestion.ts:54:77 Survived replacement="\"\"" @equivalent: removing the canonical object comma remains injective for fixed quoted allowlisted keys and nullable integer/object values; this encoding is used only for equality and is never persisted.

149 packages/db/src/analytics-ingestion.ts:75:22 Survived replacement="false" @equivalent: null duplicate keys are never stored in emails, so emails.get(null) still yields undefined.

163 packages/db/src/analytics-ingestion.ts:81:9 Survived replacement="true" @equivalent: storing an unused null Map key is unobservable because lookup explicitly skips null keys and the local Map is not returned.

166 packages/db/src/analytics-ingestion.ts:87:88 Survived replacement="true" @accepted: defaulting global read matching to shared locks preserves identity decisions and scope safety but may add contention; stronger locking is permitted and no latency/read-lock contract is specified.

228 packages/db/src/analytics-ingestion.ts:134:21 Survived replacement="{}" @equivalent: FOR SHARE without OF locks all relations in this two-table account/vendor query, the same set as its explicit OF list.

238 packages/db/src/analytics-ingestion.ts:136:39 Survived replacement="{}" @equivalent: company selection is consumed only as row existence; selecting an empty object preserves that existence result and row lock.

245 packages/db/src/analytics-ingestion.ts:139:37 Survived replacement="{}" @equivalent: actor selection is consumed only as row existence; its selected ID is never used, so empty-object selection preserves actor verification and lock.

298 packages/db/src/analytics-ingestion.ts:163:13 Survived replacement="false" @equivalent: a suppressed conditional upsert holds the existing key row with synced_at >= incoming; Person scope is locked, so the follow-up current row exists and cannot be older.

299 packages/db/src/analytics-ingestion.ts:163:13 Survived replacement="!current && current.syncedAt.getTime() < batch.syncedAt.getTime()" @equivalent: PostgreSQL conflict row locking plus the upsert timestamp predicate guarantee current exists and is at least as new, leaving the equal-contradiction check unchanged.

301 packages/db/src/analytics-ingestion.ts:163:25 Survived replacement="false" @equivalent: current.synced_at < incoming is unreachable after this upsert returns no row under the held conflict-row lock.

## Final current preview and infrastructure dispositions

Exact round2 source cutoff927835e. Worker108Killed/7Survived/2NoCoverage/1Timeout,92.37%PASS; deferred9Killed,100%PASS. Deferred current manifest selects exactly deferred.test.ts; all five previously genuine deferred entries are Killed. Worker explicit former guards/clock/protocol/zero-result IDs3,10,11,16,21,22,46,59,60 are Killed; warning entity metadata and actual transaction callback variants also Killed. Prior raw SQL transaction string mutants were removed by correct transaction abstraction, not waived. Timeout116 removes client.release, evidencing resource-lifetime fault detection.

**Cleanup infrastructure remains unresolved outside scoped code approval.** Independently read execution.cleanup: ok=false, AggregateError with two exact2BP01 errors for ledger_app/ledger_owner role dependencies. This is a failing launcher cleanup result despite both scored previews passing. Container removal is recorded/proven by verifier's Docker inventory; dependent object identities are absent. Timeout-abandoned mutation clone is a supported inference only, not proven exact cause. No evidence establishes ordinary production resource leakage: real success/failure/reuse cleanup assertions pass. Controller must use clean disposable ownership and preserve errors for final gates/cold; no unrequested rerun is warranted by scored artifacts. Historical expected5/actual7 preflight mismatch remains controller deviation/cost evidence.

**Final finding disposition:** I1/I2/M1 addressed;0new Critical/Important/Minor code findings;0unapproved current residuals. Signed reviewer task3_review, scoped fix review only. No test rerun or production/index/HEAD mutation.

Own related rollout pointer: /Users/fcolomas/.codex/sessions/2026/10/05/rollout-2026-10-05T22-45-45-01a10f51-41b3-7281-b41e-70a123cd08bd.jsonl. Metadata-only final pre-response snapshot: 19 response_item.function_call records (excludes custom tool-call types), peak last_token_usage.input_tokens=131260 retained context, total output_tokens=13673. Mixed initial-review/re-review seat segment; no unrelated transcript inspected.
