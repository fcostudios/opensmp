## Task 2: Correct Anthropic per-user activity contract and adapter

**Files:**
- Modify: `packages/connectors/src/contracts.ts`, `packages/connectors/src/dispatch.ts`.
- Modify: `packages/connectors/src/providers/anthropic/connector.ts`.
- Modify tests: `packages/connectors/src/providers/anthropic/connector.test.ts`, `packages/connectors/src/providers/anthropic/connector.pact.test.ts`; `packages/connectors/src/dispatch.test.ts` only if it contains affected activity fixtures or validation coverage.

**Production sources:** contracts.ts, dispatch.ts, providers/anthropic/connector.ts.

**Consumes:** Task 1 `ActivityIngestionRecord` and `normalizeActivityCounters`; current `SyncInput`, endpoint policies, opaque-page implementation, separated analytics credentials, rate limiter and observations.

**Produces:** `ActivitySnapshot = {records: readonly ActivityIngestionRecord[]}`; `VendorConnector.syncActivity` remains the existing method and `ConnectorResult` envelope. No second raw payload field is needed: Task 1 reconstructs replay from validated snapshot fields.

- [ ] **Step 1: Write the failing distinct-person contract test.** Use existing transport fixture/observation helpers, backed by the updated Pact interaction. Current org-summary duplication must fail this oracle:

```ts
const body = { data: [
  { user: { type: "user", id: "u-a", email_address: "ALICE@example.test" },
    chat_metrics: { message_count: 2, thinking_message_count: null },
    unrelated: { authorization: "must-not-persist" } },
  { user: { type: "user", id: "u-b", email_address: "bob@example.test" },
    chat_metrics: { message_count: 7 } },
  { user: null, chat_metrics: { message_count: 3 } },
], has_more: false, next_page: null };
// Run the existing connector with this documented users response.
expect(result.ok).toBe(true);
if (!result.ok) throw new Error("expected activity success");
expect(result.value.records.map(row => row.counters)).toEqual([
  { chat_metrics: { message_count: 2, thinking_message_count: null } },
  { chat_metrics: { message_count: 7 } },
  { chat_metrics: { message_count: 3 } },
]);
expect(result.value.records[2].email).toBeNull();
expect(result.value.records.every(row => row.activityDate === "2026-10-03")).toBe(true);
expect(requests.map(request => new URL(request.url).pathname))
  .toEqual(["/v1/organizations/analytics/users"]);
```

The request path is the existing `endpoints.ts` analytics_users policy; assert there is no summaries call.

- [ ] **Step 2: Run RED.** `rtk pnpm --filter @smp/connectors exec vitest run src/providers/anthropic/connector.test.ts src/providers/anthropic/connector.pact.test.ts`. Expected old flat-identity parser rejection or wrong per-person metrics, not infrastructure failure.

- [ ] **Step 3: Switch contract and adapter together.** Change ActivitySnapshot to shared records. Parse documented nested `user` with id/email_address nullable/missing (null user yields warning candidate); reject wrong nonnull types, malformed envelopes, conflicting duplicate identities/date values and mixed-day records. Provider queried day is `syncDate(input)`. Reconstruct counters using Task 1's explicit normalizer. Keep only normalized email/minimal id, activity date, counters. No organization summary request. Preserve bounded opaque pages (100), repeated-cursor rejection, key separation and observation policy. Keep top-level success raw null. Dispatch validates/canonicalizes each returned activity record (types, real UTC day, JSON/allowlist) using shared primitives; it cannot let an arbitrary connector bypass safe replay. Existing cost parser stays untouched.

```ts
const records = users.map(item => ({
  email: normalizedNullableEmail(item.user?.email_address),
  providerUserId: nullableProviderId(item.user?.id),
  activityDate: syncDate(input),
  counters: normalizeActivityCounters(item),
}));
return success({ records });
```

The adapter's local nullable-field helpers reject malformed nonnull values; put shared normalization in contracts when the database/dispatch also require it. Unknown identity fields are discarded. Validate duplicates over all pages, not just within one page. Equivalent repeated user rows can collapse; conflicts fail the snapshot before worker writes.

- [ ] **Step 4: Update Pact and named failure oracles.** Replace only the activity interaction with official nested-user metrics, exact date/header/query policy and per-person expected counters. Preserve unrelated member, cost and invitation interactions. Prove pagination uses opaque cursors and keeps distinct counters; null identity survives; missing/null groups stay unknown; nested negative/nonfinite/wrong-type counts fail; unknown group fields/headers/secrets never appear in output or observations; cross-page conflicting duplicates/repeated cursor/excess pages fail. Keep no-summary assertion, differentiated analytics key and sanitized failure observations. Fix affected dispatch fixtures rather than weakening legacy validation tests.

- [ ] **Step 5: Run GREEN and commit.** Run affected connector/Pact/dispatch tests, connector type-check and DB focused test (shared primitive changed). Commit `fix(US-070): return documented per-person activity metrics`. Controller routes touched previews and scoped review. Report Pact evidence as local contract-backed fixtures, never claim authenticated live-provider verification.

