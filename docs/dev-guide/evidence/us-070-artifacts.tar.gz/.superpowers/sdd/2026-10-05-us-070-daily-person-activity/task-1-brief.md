## Task 1: Shared source-aware persistence and append-only migration

**Files:**
- Modify: `packages/connectors/src/contracts.ts` (new shared types and counter normalizer; preserve current ActivitySnapshot until Task 2).
- Modify: `packages/db/src/schema.ts`, `packages/db/package.json`.
- Create: `packages/db/src/analytics-ingestion.ts`.
- Create test: `packages/db/src/analytics-ingestion.integration.test.ts`.
- Create migration: `packages/db/src/migrations/V20261006013000__analytics_activity_ingestion.sql` (check timestamp uniqueness first; if occupied choose the next unused UTC timestamp with the same slug).

**Production sources:** contracts.ts, schema.ts, analytics-ingestion.ts, the new SQL migration; package export configuration.

**Consumes:** existing schema, `JsonValue`/`assertJsonValue`, real PostgreSQL fixture `@smp/db/testing/postgres-container`, existing system actor/audit conventions and Drizzle clients.

**Produces:** the shared types and `normalizeActivityCounters` above; `@smp/db/analytics-ingestion` exporting `ActivityBatch`, `ActivityBatchResult`, `ingestActivityBatch`, `resolveActivityScopes`. Task 2 uses the shared record/normalizer; Task 3 uses both database functions. No connection is created inside this module.

- [ ] **Step 1: Write a failing real-database test for the natural-key contract.** Seed two companies, same normalized email in each, an active supported vendor/account and Person IDs. Use `createPostgresFixture`, migrate committed SQL and connect as `ledger_app`; owner connection is for fixtures/privilege inspection only. Use deterministic UUIDs and timestamps. Adapt existing seed helpers, not owned mocks. The core assertion is:

```ts
const first = await ingestActivityBatch(appDb, batchA);
const before = await appDb.select().from(activityRecord);
const second = await ingestActivityBatch(appDb, {
  ...batchA,
  syncedAt: new Date("2026-10-06T12:00:00Z"),
  records: [{ ...batchA.records[0], counters: { chat_metrics: { message_count: 9 } } }],
});
const after = await appDb.select().from(activityRecord);
expect(first.written).toBe(1);
expect(second.written).toBe(1);
expect(after.map(row => row.id)).toEqual(before.map(row => row.id));
expect(after).toHaveLength(1);
expect(after[0].personId).toBe(personAId);
expect(after[0].counters).toEqual({ chat_metrics: { message_count: 9 } });
expect(after[0].syncedAt.toISOString()).toBe("2026-10-06T12:00:00.000Z");
expect(after.some(row => row.personId === personBId)).toBe(false);
```

- [ ] **Step 2: Run RED.** `rtk pnpm --filter @smp/db exec vitest run src/analytics-ingestion.integration.test.ts`. Expected missing ingestion export/fields; record the diagnostic. Fixture services must be available; infrastructure failure is not the RED oracle.

- [ ] **Step 3: Add the schema and grant migration.** Verify existing enum/constraint names and account provisioning column. Declare a common ingestion enum and account default/manual backfill; activity source default/api. Mirror the existing committed activity unique key in Drizzle without duplicating it in SQL. The grant permits ONLY `UPDATE (counters, raw_payload, source, synced_at)` on activity_record. Do not grant UPDATE of key/id columns or DELETE. New runtime writes explicitly provide source. Add `./analytics-ingestion` package export. The SQL shape is:

```sql
CREATE TYPE ingestion_source AS ENUM ('api', 'csv_import', 'manual');
ALTER TABLE vendor_account ADD COLUMN ingestion_mode ingestion_source NOT NULL DEFAULT 'manual';
ALTER TABLE activity_record ADD COLUMN source ingestion_source NOT NULL DEFAULT 'api';
GRANT UPDATE (counters, raw_payload, source, synced_at) ON activity_record TO ledger_app;
```

- [ ] **Step 4: Implement validation/matching/upsert.** Validate UUID/date/source/finite sync instant, record date equals batch date, identity field types, supported vendor email matching and counters before any write. Real dates must round-trip (`2026-02-30` fails). Normalize email with trim/lowercase. Accept null email for warnings; malformed nonnull email is rejected. The counter normalizer reconstructs only the three allowlisted metric groups listed below, preserving missing/null and rejecting negative/noninteger/nonfinite counts. Unknown properties are dropped even if they contain secrets. Reject conflicting duplicate normalized identities/natural keys before writes; equivalent duplicates collapse.

Allowed paths: chat_metrics `{connectors_used_count,distinct_artifacts_created_count,distinct_connectors_used_count,distinct_conversation_count,distinct_files_uploaded_count,distinct_projects_created_count,distinct_projects_used_count,distinct_shared_artifacts_viewed_count,distinct_skills_used_count,message_count,shared_conversations_viewed_count,thinking_message_count}`; claude_code_metrics.core_metrics `{artifacts_created_count,commit_count,distinct_session_count,pull_request_count,lines_of_code:{added_count,removed_count}}`; claude_code_metrics.tool_actions `{edit_tool,multi_edit_tool,notebook_edit_tool,write_tool}` each `{accepted_count,rejected_count}`; cowork_metrics `{action_count,artifacts_created_count,connectors_used_count,dispatch_turn_count,distinct_connectors_used_count,distinct_session_count,distinct_skills_used_count,message_count,skills_used_count,distinct_plugins_used_count,edit_tool_count,file_edit_count,multi_edit_tool_count,notebook_edit_tool_count,plugins_used_count,sessions_with_file_edits_count,write_tool_count}`. Group/nested objects may be missing/null; never manufacture counters or zeros.

For API writes recheck and hold the account ingestion mode through commit; non-api account gives ignored rows and no writes. Prefer existing transaction row locks, no lifecycle/table. Other sources do not invoke providers and may persist regardless of account ingestion mode. Scope/match Person with `company_id`, including a race-safe recheck. Use a real PostgreSQL natural-key upsert; this is the atomic decision shape:

```sql
ON CONFLICT (vendor_account_id, person_id, activity_date)
DO UPDATE SET counters=EXCLUDED.counters, raw_payload=EXCLUDED.raw_payload,
  source=EXCLUDED.source, synced_at=EXCLUDED.synced_at
WHERE activity_record.synced_at < EXCLUDED.synced_at
```

When no row returns, read the now-current key and compare timestamp and JSONB semantics: newer persisted timestamp means ignore; equal and equivalent means ignore; equal and contradictory means reject. Do not compare JSON serialization order. Handle concurrency using PostgreSQL conflict/locks so simultaneous equal conflicts cannot both succeed. Persist `analytics_activity_sync` company summaries inside the same transaction, with account/date/source/written/ignored/warning counts and verified actor or system identity. Scoped callers retain structured warnings and persist scoped warning audit entries in that same transaction. Global routing warnings are persisted by Task 3 only, so an identity matched in another company is never mislabeled unknown globally.

- [ ] **Step 5: Prove specific boundaries with real assertions.** Extend the first test only where each assertion kills a named fault: stale replay preserves newer payload/time; equal equivalent retry preserves ID; equal contradiction rolls back data+audit; concurrent writes retain one row; two accounts retain independent keys; foreign-only email returns unmatched without foreign person data; null email returns missing_email; api/csv_import/manual produce explicit source and replay metadata; invalid full batch writes nothing; immutable-key/DELETE grants fail under ledger_app; audit INSERT failure rolls back rows (owner temporarily revokes grant and restores in finally); backfilled orchestration and automated accounts both default manual. Test mode disable during fetch via shared API batch returning ignored, not a sleep/race test. Global matcher must group two distinct-company records once and emit only true unmatched/null warnings.

- [ ] **Step 6: Run GREEN and commit.** Run the focused DB test and `rtk pnpm --filter @smp/db type-check`, plus connector type-check to prove additive primitives preserved old callers. Run migration parity. Commit only task paths with `feat(US-070): add source-aware activity ingestion`. Controller routes previews on the committed candidate, then sends scoped review. Report actual commands/results and privilege evidence, not coverage counts.

