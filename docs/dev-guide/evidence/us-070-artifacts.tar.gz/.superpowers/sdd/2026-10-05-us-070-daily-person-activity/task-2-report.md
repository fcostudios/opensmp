# Task 2 report — US-070

Status: DONE, implementation ready for controller preview and scoped review.

## Changes
- ActivitySnapshot now uses shared ActivityIngestionRecord.
- Anthropic users parse nested nullable/missing user id/email_address; retain normalized email/minimal id, queried UTC day and explicit allowlisted person counters.
- Removed organization summaries request and summary parser; cost production parser and endpoint policy unchanged.
- Opaque pagination remains bounded at 100 with repeated cursor refusal. Conflicting duplicate identities fail across all pages; equivalent rows collapse. Null identity survives for ingestion warnings.
- Dispatch reconstructs canonical allowlisted activity records, validates nullable identity/real UTC day/count values and rejects mixed days/conflicting identity before replay. Success raw is null.
- Added local Pact activity interaction with exact date/page/header policy and differentiated analytics key; unrelated invitation interactions preserved.

## TDD and commands
All commands prefixed rtk; explicit approved workdir /Users/fcolomas/.codex/worktrees/us-070-activity/smp.
1. RED: pnpm --filter @smp/connectors exec vitest run src/providers/anthropic/connector.test.ts src/providers/anthropic/connector.pact.test.ts — exit 1, documented distinct-person response expected ok=true, received false; 141 other tests passed. This is old flat identity parser rejection, not infrastructure.
2. GREEN after contract/adapter correction and affected fixture updates: affected three-file suite, 300 tests passed.
3. RED dispatch boundary: pnpm --filter @smp/connectors exec vitest run src/dispatch.test.ts -t activity dispatch safe replay boundary — mixed-day and conflicting identity checks resolved instead of rejected, 2 failed/5 passed.
4. GREEN same dispatch selection — 7 passed.
5. Final pnpm --filter @smp/connectors exec vitest run src/providers/anthropic/connector.test.ts src/providers/anthropic/connector.pact.test.ts src/dispatch.test.ts — exit 0, 310 tests passed in 6.41s.
6. pnpm --filter @smp/db exec vitest run src/analytics-ingestion.integration.test.ts — exit 0, 17 tests passed in 3.62s. Shared helper behavior was not modified; this additionally proves the switched snapshot dependency does not regress ingestion.
7. pnpm --filter @smp/connectors type-check — exit 0.
8. git diff --check — exit 0.

## Spec concern and evidence limits
Official https://platform.claude.com/docs/en/api/http/beta/organization/analytics/users/list confirms per-person nested user and next_page. has_more is optional because the official contract lists next_page; when provided (as in approved brief fixture), its boolean value must agree with next_page. Public docs and local Pact are not authenticated live-provider verification.

## Self-review
No secrets/headers/provider body retained in normalized output or observations. Unknown metrics ignored; missing/null metric groups stay unknown; nested negative/wrong-type/nonfinite counts rejected. Null and missing user identity preserved. Distinct metrics, opaque paging, repeated/excess cursors, cross-page duplicate conflicts, equivalent duplicate collapse, safe dispatch reconstruction and sanitized failures constrained by focused tests. No owned module mock, no harness/tooling/cache changes, no migrations, no worker changes. Mutation preflight/previews and scoped adversarial review belong to controller.

TDD skill applied after initial RED and before production changes. Main provider correction and added dispatch constraints have observed RED/GREEN evidence; supplementary malformed/duplicate fixtures reuse existing rejection behavior rather than claiming each was independently RED. Initial multi-file instruction read was truncated; targeted TESTING and constraints/interfaces/local guide were reread in full. Root AGENTS was supplied in task context; later filesystem confirmation found no nested AGENTS in touched directories. Testing critical path daily activity already declared by Task1; no generated testing guide edits.

## Cost
Own transcript pointer not exposed by tool runtime. Cost counters unavailable; no fabricated measured token/call numbers. Controller owns story-level cost closure.

## Commit
Implementation commit: 2db44d1 (full SHA returned to controller). Report is controller coordination artifact and remains outside implementation commit.


## Fix round 1 — reviewer-required oracle repair
Base 2db44d1cb74f3ba9c61ced55963a507ae25a80c3. Read task-2-review.md Important finding and exact 35 UNAPPROVED genuine survivor contracts; read task-2-preview-report.md artifacts (tail recovered after combined output truncation).

Tests only: dispatch now constrains successful nullable identity, equivalent normalized duplicate collapse, independent malformed string/boxed String email and numeric/blank/control/boxed String provider ID, same-email distinct-ID conflicts and cloneable empty typed-array envelope rejection. Provider tests constrain null/nonobject rows, wrong nested user type, malformed nested email, exact queried explicit date success with omitted optional has_more, and both supplied boolean/cursor disagreement cases. No production defect found or production changes made.

Representative RED verification used exact original report replacements at source locations, restoring original bytes in finally after each run. JSON evidence task-2-fix1-red-evidence.json and per-mutant logs record source, original expression, replacement and exit. Dispatch mutants 2/25/28/75/81 and provider mutants 2/14/32/44/67/74 each fail behaviorally (exit1, assertions or expected sanitized response rejection), covering all named fault categories. Initial location column interpretation was off by one and caused parse failures; this was corrected to the report one-based coordinates, all logs/evidence replaced with valid behavioral REDs. Invalid attempts are not claimed as TDD proof.

Commands: rtk proxy python3 bounded replacement runner invoked rtk pnpm --filter @smp/connectors exec vitest run <affected test> -t <named suite> for each exact replacement. Sources restored byte-for-byte; no harness/cache/config changes. GREEN rtk pnpm --filter @smp/connectors exec vitest run src/providers/anthropic/connector.test.ts src/dispatch.test.ts: exit0, 307 passed, 6.35s. rtk pnpm --filter @smp/connectors type-check: exit0. rtk git diff --check: exit0. Unchanged Pact/DB suites not repeated.

Self-review: additions correspond only to named required-contract survivors; no owned mocks or coverage-volume tests. Expected exact canonical success/failure and independent rejection oracles exercise real dispatcher/adapter. Controller owns affected provider/dispatch previews and scoped re-review. Fix commit SHA returned after commit.

Fix round 1 commit: cfcfe8d1821cb73b83bc47a379f63b8f35530d68. Own transcript pointer (filename lookup only, no transcript content read): /Users/fcolomas/.codex/sessions/2026/10/05/rollout-2026-10-05T22-12-27-01a10f32-c390-76a2-91de-6646b4cbf1ad.jsonl.
