# Task 1 independent review — ed9ff60..e4f62808f3f8a38d71e6b3bc89c52a3112a9f607

## Spec Compliance

❌ Issues found: duplicate detection conflates disjoint email and provider-only identity namespaces (Important I1 below). The remainder of the bounded Task 1 contract is implemented.

⚠️ Cross-task checks: Task 2 must provide only validated identity/counters; Task 3 must enforce company authorization before calling this trusted helper, exclude manual/CSV accounts before credentials/provider calls, use UTC at minus three days, and persist truly global warnings. Full application gates and authoritative mutation closure remain controller-owned. Whole-program generated provenance review belongs to the final reviewer.

## Strengths and evidence

- `packages/db/src/analytics-ingestion.ts:87-91,148` applies a genuine company predicate and holds Person scope with a share lock. `analytics-ingestion.integration.test.ts:290-318` uses a real database wait state and a tenant-movement rejection oracle.
- `analytics-ingestion.ts:152-171` uses atomic natural-key conflict updates, only refreshes newer observations, compares equal replays with JSONB semantics, and keeps warnings/summary in the row transaction. Tests at lines 74-100 and 167-181 constrain rollback, concurrent equal contradictions and restricted grants.
- `packages/connectors/src/contracts.ts:178-222` reconstructs only allowed counters and preserves missing/null data; `contracts.test.ts:6-69` checks every supported field, rejects malformed known paths and proves unknown secret getters are not read.
- Append-only migration lines 1-5 and verifier grant additions retain immutable keys/DELETE restrictions. Schema test lines 126-203 compares mapping/default/key semantics with real committed PostgreSQL independently of production schema constants.
- The controller's distinct-email fixture ruling preserves existing uniqueness while still testing actual company isolation. The four-line verifier matrix addition is necessary metadata, not a privilege relaxation beyond the specified columns. Call-time private shape construction is a justified bounded response to documented static mutant activation ordering; modest repeated object construction is acceptable here.

## Issues

### Critical

None found.

### Important I1 — duplicate key namespace collision

`packages/db/src/analytics-ingestion.ts:73-77`: provider-only identity `provider:${providerUserId}` and a normalized email share an untagged string namespace. A missing-email record with providerUserId `x@example.test` and an unrelated valid-email record with email `provider:x@example.test` (providerUserId null or another ID), on the same day, produce exactly the same key. The email validator accepts this local part. The second record then rejects as ACTIVITY_DUPLICATE_CONFLICT rather than producing a missing-email warning and independently matching/routing the real email. Both ingestActivityBatch and resolveActivityScopes fail the complete batch before writes. Tag both namespaces explicitly (or use separate maps/structured tuple encoding) and add the smallest regression asserting the missing warning and independent email record. Existing tests do not exercise a cross-namespace collision; this is a genuine logic gap outside the residual mutant set.

### Minor

None blocking. `analytics-ingestion.integration.test.ts:302-308` bounds progress observation by 1,000 database queries rather than elapsed time; the actual lock event is a strong oracle, but failure diagnostics would be easier with a meaningful bounded deadline. No additional suite run is justified by this observation.

## Assessment

Task quality: Needs fixes due to I1. No production/index/HEAD changes or test reruns were performed. The supplied diff was read once; output truncation required retrieving only omitted sections from that same package. Existing reported focused GREEN, type checks and migration parity evidence were used without regenerating it. Review inputs were the brief/interfaces/constraints, report, preview report, proposals, and current residual JSON artifacts. No outside-code crawl was needed.

Mutation disposition: all 33 current residuals independently approved (including 2 NoCoverage unreachable array-formatting branches), with counts below. Acceptance is restricted to unchanged specified behavior, with changed unspecified diagnostics or locking explicitly acknowledged; no diagnostic mutant is mislabeled equivalent. These annotations do not waive I1 or constitute authoritative mutation campaign approval.

## Approved current annotations

Counts: 24 equivalent, 9 narrowly accepted; 0 unapproved residuals.

5 packages/db/src/schema.ts:479:28 Survived replacement="\"\"" @equivalent: Drizzle ColumnBuilder.setName replaces an empty name with the source property key; mapping and generated SQL remain source.
85 packages/db/src/analytics-ingestion.ts:52:36 NoCoverage replacement="``" @equivalent: array canonical representation is unreachable for normalized allowlisted nullable integer/object counters.
86 packages/db/src/analytics-ingestion.ts:52:66 NoCoverage replacement="\"\"" @equivalent: array separator is unreachable because normalized counter trees contain no arrays.
24 packages/db/src/analytics-ingestion.ts:37:7 Survived replacement="false" @accepted: Exact ISO roundtrip preserves rejection and acceptance for JSON date inputs; malformed non-JSON Symbol/coercion values can change diagnostics, which the date contract does not specify. This is narrowly accepted, not literal equivalence.
25 packages/db/src/analytics-ingestion.ts:37:7 Survived replacement="typeof value !== \"string\" && !/^\\d{4}-\\d{2}-\\d{2}$/.test(value)" @accepted: Exact ISO roundtrip preserves rejection and acceptance for JSON date inputs; malformed non-JSON Symbol/coercion values can change diagnostics, which the date contract does not specify. This is narrowly accepted, not literal equivalence.
26 packages/db/src/analytics-ingestion.ts:37:7 Survived replacement="false" @accepted: Exact ISO roundtrip preserves rejection and acceptance for JSON date inputs; malformed non-JSON Symbol/coercion values can change diagnostics, which the date contract does not specify. This is narrowly accepted, not literal equivalence.
30 packages/db/src/analytics-ingestion.ts:37:37 Survived replacement="/\\d{4}-\\d{2}-\\d{2}$/" @equivalent: removing the regex start anchor cannot bypass exact ISO-date equality against the whole original string.
31 packages/db/src/analytics-ingestion.ts:37:37 Survived replacement="/^\\d{4}-\\d{2}-\\d{2}/" @equivalent: removing the regex end anchor cannot bypass exact ISO-date equality against the whole original string.
75 packages/db/src/analytics-ingestion.ts:51:7 Survived replacement="true" @equivalent: duplicate counters were reconstructed in deterministic allowlist key order; JSON.stringify of that complete tree has the same equality relation as recursive canonical encoding.
79 packages/db/src/analytics-ingestion.ts:51:7 Survived replacement="value !== null" @equivalent: normalized counter roots are nonnull objects, so this mutation serializes the complete deterministically ordered tree and preserves duplicate equality.
81 packages/db/src/analytics-ingestion.ts:51:25 Survived replacement="typeof value === \"object\"" @equivalent: serializing the complete normalized object tree preserves all nullable integer values and duplicate equality because reconstruction fixes key order.
82 packages/db/src/analytics-ingestion.ts:51:42 Survived replacement="\"\"" @equivalent: replacing the object type string makes the root serialize directly; normalized key order and full-tree duplicate equality remain deterministic.
84 packages/db/src/analytics-ingestion.ts:52:7 Survived replacement="false" @equivalent: counter normalization rejects arrays on every known path, so canonical never receives an array.
88 packages/db/src/analytics-ingestion.ts:53:14 Survived replacement="Object.entries(value)" @equivalent: normalization reconstructs every object in a fixed allowlist order, so removing canonical sorting cannot change duplicate equality.
89 packages/db/src/analytics-ingestion.ts:53:41 Survived replacement="() => undefined" @equivalent: retaining the reconstructed object order instead of sorting preserves deterministic equality for supported counter trees.
92 packages/db/src/analytics-ingestion.ts:54:77 Survived replacement="\"\"" @equivalent: removing the canonical object comma remains injective for fixed quoted allowlisted keys and nullable integer/object values; this encoding is used only for equality and is never persisted.
146 packages/db/src/analytics-ingestion.ts:75:22 Survived replacement="false" @equivalent: null duplicate keys are never stored in emails, so emails.get(null) still yields undefined.
160 packages/db/src/analytics-ingestion.ts:81:9 Survived replacement="true" @equivalent: storing an unused null Map key is unobservable because lookup explicitly skips null keys and the local Map is not returned.
163 packages/db/src/analytics-ingestion.ts:87:88 Survived replacement="true" @accepted: defaulting global read matching to shared locks preserves identity decisions and scope safety but may add contention; stronger locking is permitted and no latency/read-lock contract is specified.
225 packages/db/src/analytics-ingestion.ts:134:21 Survived replacement="{}" @equivalent: FOR SHARE without OF locks all relations in this two-table account/vendor query, the same set as its explicit OF list.
235 packages/db/src/analytics-ingestion.ts:136:39 Survived replacement="{}" @equivalent: company selection is consumed only as row existence; selecting an empty object preserves that existence result and row lock.
242 packages/db/src/analytics-ingestion.ts:139:37 Survived replacement="{}" @equivalent: actor selection is consumed only as row existence; its selected ID is never used, so empty-object selection preserves actor verification and lock.
295 packages/db/src/analytics-ingestion.ts:163:13 Survived replacement="false" @equivalent: a suppressed conditional upsert holds the existing key row with synced_at >= incoming; Person scope is locked, so the follow-up current row exists and cannot be older.
296 packages/db/src/analytics-ingestion.ts:163:13 Survived replacement="!current && current.syncedAt.getTime() < batch.syncedAt.getTime()" @equivalent: PostgreSQL conflict row locking plus the upsert timestamp predicate guarantee current exists and is at least as new, leaving the equal-contradiction check unchanged.
298 packages/db/src/analytics-ingestion.ts:163:25 Survived replacement="false" @equivalent: current.synced_at < incoming is unreachable after this upsert returns no row under the held conflict-row lock.
29 packages/connectors/src/contracts.ts:202:9 Survived replacement="false" @accepted: removing the null precheck still rejects root null via Object.getPrototypeOf(null); only Error subtype/diagnostic changes, and the normalizer contract specifies rejection without a typed error payload.
37 packages/connectors/src/contracts.ts:204:23 Survived replacement="``" @accepted: invalid known objects still reject; the shared normalizer promises validation, not this prose diagnostic, and no production caller branches on its text.
55 packages/connectors/src/contracts.ts:213:13 Survived replacement="false" @equivalent: Number.isInteger alone rejects all nonnumber/nonfinite values, so removing the preceding typeof/finite disjunction preserves accepted counters and the same rejection path.
56 packages/connectors/src/contracts.ts:213:13 Survived replacement="typeof metric !== \"number\" && !Number.isFinite(metric)" @equivalent: changing typeof/finite OR to AND cannot admit extra values: unchanged Number.isInteger rejects every nonnumber, NaN and infinity; unchanged metric<0 rejects negative integers.
57 packages/connectors/src/contracts.ts:213:13 Survived replacement="false" @equivalent: Number.isFinite and Number.isInteger reject nonnumbers without coercion, preserving the same count rejection when the typeof term is removed.
66 packages/connectors/src/contracts.ts:215:27 Survived replacement="``" @accepted: malformed counts still reject at the same boundary; the untyped prose diagnostic is not a provider or ingestion failure discriminant.
67 packages/connectors/src/contracts.ts:218:54 Survived replacement="``" @accepted: recursive path text feeds only validation diagnostics; supported output and rejection behavior stay unchanged, and no caller branches on the path.
68 packages/connectors/src/contracts.ts:222:49 Survived replacement="\"\"" @accepted: initial counters path label affects only untyped validation diagnostics, not accepted metrics or rejection decisions.
