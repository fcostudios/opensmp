## Task 3: Execute daily activity ingestion through the existing worker

**Files:**
- Create: `apps/worker/src/jobs/analytics-activity.ts`.
- Create test: `apps/worker/src/jobs/analytics-activity.integration.test.ts`.
- Modify: `apps/worker/src/jobs/deferred.ts`, `apps/worker/src/jobs/deferred.test.ts`.
- Modify: `apps/worker/src/connector-composition.ts` only if a small activity factory alias is needed; prefer the existing dispatcher factory over duplicating composition.

**Production sources:** jobs/analytics-activity.ts, jobs/deferred.ts, optional connector-composition.ts.

**Consumes:** Task 1 DB exports, Task 2 `syncActivity`, existing membership-poll credential/KEK and connector observation seams, worker service inputs/runtime retry failure reporting and `successfulJob`.

**Produces:**

```ts
export function createAnalyticsActivityJob(options: {
  connectionString: string; allowedKekRoot?: string; kekFile?: string;
  now: () => Date; sleep: (milliseconds: number) => Promise<void>;
  transport: (request: Request) => Promise<Response>;
}): {
  drain(input: { at: Date; vendorAccountId?: string }): Promise<{ processed: number }>;
  close(): Promise<void>;
};
```

- [ ] **Step 1: Write a failing end-to-end worker test with real ledger_app storage.** Seed a manual automated account, csv_import account, api orchestration account, two people in different companies and valid encrypted analytics credential. Transport uses Task 2's Pact-backed nested-user response with different counters plus one unmatched and one null user. Invoke the deferred handler with services and targeted account. Assert api rows reference each correct Person ID and retain distinct counters, the two warning audit reasons/evidence are persisted, and observation entries use sync_activity with provisioningActionId null and no credentials. Invoke again at a later injected now and assert row IDs/count unchanged and synced_at increased. For manual/CSV targeted runs use a transport that throws on ANY call, assert success zero, empty telemetry and no observation. Assert missing credentials do not break mode-excluded runs.

```ts
const job = createAnalyticsActivityJob(options);
try {
  expect(await job.drain({ at: new Date("2026-03-03T00:00:00Z"), vendorAccountId: apiAccountId }))
    .toEqual({ processed: 2 });
  expect(capturedDates).toEqual(["2026-02-28"]);
  expect(await job.drain({ at: new Date("2026-03-03T00:00:00Z"), vendorAccountId: manualAccountId }))
    .toEqual({ processed: 0 });
} finally { await job.close(); }
```

- [ ] **Step 2: Run RED.** `rtk pnpm --filter @smp/worker exec vitest run src/jobs/analytics-activity.integration.test.ts src/jobs/deferred.test.ts`. Expected absent job or deferred dependency result, not fixture failures.

- [ ] **Step 3: Compose worker resources and account filtering.** Model pool/Drizzle ownership, KEK decryption, rate limiter and sanitized observation session after `jobs/membership-poll.ts`; reuse module seams without copying domain feature logic. Query active account/vendor, ingestion_mode api, supported api connector, hasUsageData true and email matching before credential reads. Unsupported targeted matching fails explicitly when API ingestion is otherwise eligible. Account provisioning mode does not filter. Enumerate trusted active company IDs from database for global execution and route records once with resolveActivityScopes. Never derive company authority from account ID or email input. Fetch snapshot entirely before writes. For each company batch use ingestActivityBatch with API source, exact queried day, injected actual now and system actor. The shared transaction rechecks ingestion mode; disabled-in-flight account produces no persisted rows or warnings from that excluded attempt.

```ts
const observedAt = new Date(Date.UTC(at.getUTCFullYear(), at.getUTCMonth(), at.getUTCDate() - 3));
const observedDay = observedAt.toISOString().slice(0, 10);
const snapshot = await connector.syncActivity({ vendorAccountId: account.id, observedAt });
if (!snapshot.ok) throw providerFailureForExistingRuntime(snapshot);
const routed = await resolveActivityScopes(db, trustedCompanyIds, snapshot.value.records);
```

Use the existing worker's error/retry contract; no invented helper export is required for the local provider failure conversion. Persist each true global missing/unmatched warning as analytics_identity_warning, null company and allowlisted account/day/reason/identity. No arbitrary company assignment, truncation or lost warning on provider pagination. Audit failure rejects run. Successful earlier company batches remain safe to replay after later failure. processed counts written rows; ignored/stale records don't count. Drain does not close its reusable resources; handler closes in finally. Constructor/resource initialization must also clean up on errors.

- [ ] **Step 4: Replace deferred handler and prove UTC/errors/mode/concurrency.** With no configured services return dependencyNotDelivered("US-070"); with services create the activity job, drain `{at,vendorAccountId}`, wrap processed via successfulJob and close in finally. Update only analytics no-services expectation in deferred tests. Existing daily schedule stays unchanged. Add deterministic assertions for UTC midnight, leap day and month/year boundary; driver/provider errors propagate to existing failure reporter, unsupported vendor/matching behavior is explicit, pagination completes before persistence, disable during external fetch stops writes, concurrent reruns preserve one natural-key row, stale finishing attempt cannot replace newer counters and globally unmatched warnings persist once per attempt rather than per company. Test DB cleanup through real pool/session behavior and repeat job use, without mocking the owned job.

- [ ] **Step 5: Run GREEN and commit.** Run focused worker tests and worker type-check. Commit `feat(US-070): execute daily API activity ingestion`. Controller routes touched previews then scoped review. Report exact account exclusions, UTC examples and durable warning evidence.

## Integration, adversarial verification and terminal evidence

This section is controller/verifier work, not another implementation task. Never dispatch US-071 from this session.

- [ ] Record review phase. Package the complete branch diff and all task reports for one broad reviewer on the most capable available model. Reviewer adversarially attempts AC1..AC4 using real fixture tests and narrow commands where reported evidence leaves a concrete doubt; it also reviews deferred/minor rulings. Record one ac_verify per AC only after a passing verdict. Fix findings through one bounded implementer wave followed by scoped rereview; any logic fixes rerun only touched previews and focused tests.
- [ ] Update effectiveness-critical declarations by the Nous-owned config path, not by editing generated TESTING.md. Locate the authoritative testing.critical_paths config and preserve existing entries; add daily activity row idempotency/tenant matching/source gating/replay/warning retention with US-070. Use the normal generated delivery. If the producer is being modified concurrently, prepare a concrete bounded handoff and coordinate rather than editing its database behind its agent. Generated-only delivery does not change runtime semantics.
- [ ] Record integration phase. A verifier runs `rtk pnpm check` with MUTATION_WORK_ID=US-070 and MUTATION_BASE set to the recorded plan authority commit. Independently apply committed migrations and verify schema/parity on a fresh real PostgreSQL owner database; app privilege tests remain ledger_app. Preserve logs as files and report concise results. Infrastructure failure must be fixed or reported, never treated as a passing gate.
- [ ] After all repairs are committed, clear authoritative cache once and run one cold diff campaign: `rtk pnpm mutation:cache:clear`, then `rtk env MUTATION_WORK_ID=US-070 MUTATION_BASE=<recorded-authority-commit> pnpm test:mutation`. The exact base is captured before Task 1, not inferred from HEAD~1. Capture shard count/minutes. A post-campaign implementation change invalidates it and needs an explicit mutation_invalidation before another cold attempt. Shard-count estimate mismatch is a deviation, not a silent readiness rewrite.
- [ ] Reviewer signs off any survivor with exactly one line: `<mutant-id> <file>:<line> @equivalent: <reason>` or `@accepted: <reason>`. No separate equivalence document. Genuine unaccepted survivors are repaired; the killing test is evidence. Retain no tests whose only purpose was coverage.
- [ ] Controller records phase actuals, git authority/cutoff/file and commit counts, review loops, preview rounds/minutes, cold attempts/invalidations and cost provenance. Read `docs/dev-guide/FEEDBACK.md` and DEFINITION_OF_DONE before terminal evidence. Work-state tools are currently unavailable in this tool catalog; the plan-specific SDD ledger is the durable recovery map.
- [ ] Commit closed readiness actuals and feedback together in one evidence commit; emit build_pass, all four passing ac_verify, authoritative test_report and cost provenance before done. Do not mark US-026 done: it still awaits US-071 and fresh parent verification readiness. Finish according to the development-branch skill without merging or publishing without authorization.
