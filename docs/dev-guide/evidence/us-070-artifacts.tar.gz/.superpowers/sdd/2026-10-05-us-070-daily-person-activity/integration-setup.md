# US-070 integration verifier brief

Work from `/Users/fcolomas/.codex/worktrees/us-070-activity/smp`. All shell commands start with `rtk`. Do not rerun baseline; its 15 tasks were cached. Capture large gate output in this SDD directory and return exit codes, named failures, counts, and infrastructure/code classification.

## Integration gates after implementation and review

- `rtk pnpm check` expands to stale-container check, mutation scope preflight, type-check, lint, test, build. It does not include committed migration verification/parity or the cold mutation campaign.
- `rtk proxy env MUTATION_BASE=<approved-base-sha> MUTATION_WORK_ID=US-070 pnpm mutation:preflight` emits final JSON with `expected_mutation_shards`, `mutation_shards_actual`, `mismatch`, and shard IDs. Full source/test mapping lives in `.tmp/stryker-shards/manifest.json` under `shards[].sources`, `testFiles`, `id`, and provenance. This is `scripts/mutation-scope.mjs --preflight`, distinct from `pnpm test:mutation:preflight` (oracle/database prerequisite script).
- Set the exact approved base rather than a drifting ref. Without MUTATION_BASE, scope preflight defaults HEAD, while campaigns resolve the remote default branch. MUTATION_WORK_ID reads the approved readiness artifact expectation; invalid IDs fail. Do not use MUTATION_SHARD during preflight.
- Touched preview: `rtk proxy env MUTATION_BASE=<approved-base-sha> MUTATION_WORK_ID=US-070 MUTATION_SHARD=<manifest-id> pnpm test:mutation`. Preview only shards whose sources intersect later changes. After adversarial review closes, run one full cold diff campaign with the approved base/work ID and no shard selector; changing source/tests/dependencies/config invalidates it.

## PostgreSQL and environment

Docker daemon checked reachable (29.7.2). The repository fixture starts pinned PostgreSQL 16 alpine, serialized container startup, max_connections=400, 120s startup timeout, and bootstraps ledger_owner (CREATEDB, non-superuser) and ledger_app (non-superuser, no CREATEDB/BYPASSRLS). Reuse `startSharedPostgresCluster` plus `SMP_TEST_POSTGRES_CLUSTER_URL`, or existing package globalSetup; avoid parallel private containers. `tsx packages/db/src/testing/run-with-shared-postgres.ts <command> ...` wraps a command in that shared cluster and tears it down. Do not print its connection URLs.

For migration gates create one fresh fixture using exported `createPostgresFixture`, obtain ownerUrl/appUrl in memory, and pass only child-process environment: DATABASE_ADMIN_URL=ownerUrl, DATABASE_URL=appUrl. Execute sequentially from packages/db:

1. `rtk node scripts/apply-migrations.mjs`
2. `rtk node scripts/verify-schema.mjs`
3. `rtk node scripts/check-migration-parity.mjs`

Package aliases: `rtk pnpm --filter @smp/db db:migrate`, `db:verify`, `db:parity`. Always stop fixture/cluster in finally. Applier requires DATABASE_ADMIN_URL; verifier also requires DATABASE_URL and validates actual ledger_owner/ledger_app identities. Parity requires both and provisions/cleans two unique databases itself; owner CREATEDB is necessary. Parity's internal fresh drizzle push is a comparison implementation, not a replacement migration gate.

Build env: DB_DRIVER=pg with the fixture application URL; publicAppOrigin requires valid AUTH_URL or NEXTAUTH_URL outside development (e.g. local loopback origin). Auth.js consumes KEYCLOAK_ISSUER, KEYCLOAK_CLIENT_ID, KEYCLOAK_CLIENT_SECRET and its secret via the conventional AUTH_SECRET/NEXTAUTH_SECRET. Use isolated test values, not deployment credentials. Real Keycloak integration tests own their Docker seam; do not point them at production. No env file was added by setup.

## Authoritative critical-path additions

Source CLI: `/Users/fcolomas/Projects/nous/Nous/System/nous_trace.py`; project `fcostudios__smp`. Read current config with `rtk python3 /Users/fcolomas/Projects/nous/Nous/System/nous_trace.py config show --project fcostudios__smp` into a private temporary file (do not emit the full config to conversation). Read current `config.testing.critical_paths` from that snapshot, append the new bounded US-070 statement while preserving every prior row, then use `config patch --project fcostudios__smp --key testing.critical_paths --value <JSON-of-entire-preserved-plus-new-array>`. Patch deep-merges dictionaries but REPLACES arrays; passing only the new row would delete existing additions. Config patch creates an audited version. No config mutation has been performed.

Selective sync categories verified in nous_package.py: `agent_files` generates TESTING.md alongside governed agent docs; `sprint_plan` writes testing/critical-paths.md alongside sprint/changes/assignment catalogs. There is no selectable testing-only category. First preview `rtk ./infra/scripts/sync-from-nous.sh --dry-run -c agent_files sprint_plan`. The script also previews/applies repository-wide Ledger documentation invariants, regardless of chosen categories.

For bounded delivery avoid wholesale generator output: use a scratch copy with required target metadata, invoke those two categories there, review divergence refusals, and bring back only the two intended generated testing documents and any required manifest provenance after checking hashes. Alternatively inspect the category preview before syncing the real target and retain only approved target changes. Do not hand-edit generated critical rows or override refusal using force-docs. Critical-paths and agent docs have provenance/divergence guards; report refusals for reconciliation.

## Concrete blockers / pending inputs

- Implementation/review must finish before gates.
- Parent must supply/pin approved mutation base SHA; no campaign/base was chosen here.
- Isolated build/migration env and fixture harness have not been provisioned; use the existing exports without logging URLs.
- Current authoritative config rows and doc provenance were not queried from the database; availability and divergence must be checked before config patch/sync. No testing-only sync category exists, so bounded generation needs scratch staging/review.
