import { createPostgresFixture } from "../../../packages/db/src/testing/postgres-container";
import { spawn } from "node:child_process";
import { openSync, closeSync, readFileSync, writeFileSync } from "node:fs";
const dir = ".superpowers/sdd/2026-10-05-us-070-daily-person-activity";
const results: any = { round: 1, start: new Date().toISOString(), commands: [] };
async function main() {
 const fixture = await createPostgresFixture({isolatedContainer: true});
 try {
  await fixture.migrate();
  const env = {...process.env, DATABASE_ADMIN_URL: fixture.ownerUrl, DATABASE_URL: fixture.appUrl, US070_MUTATION_DATABASE_ADMIN_URL: fixture.ownerUrl, US070_MUTATION_DATABASE_URL: fixture.appUrl, DB_DRIVER: "pg", MUTATION_BASE: "ed9ff60d9dda6aaf78fae5e9a61d189b1a8e4108", MUTATION_WORK_ID: "US-070"};
  async function run(args: string[], name: string, extra: any={}) {
   const fd=openSync(`${dir}/${name}-round1.log`, "w"); const start=Date.now();
   try { const code=await new Promise<number>((resolve,reject)=>{ const child=spawn("rtk",["proxy","pnpm",...args],{env:{...env,...extra},stdio:["ignore",fd,fd]});child.on("error",reject);child.on("exit",c=>resolve(c??1)); }); results.commands.push({name,args,exit:code,minutes:(Date.now()-start)/60000}); if(code!==0) { const output=readFileSync(`${dir}/${name}-round1.log`, "utf8"); if(!extra.MUTATION_SHARD || !output.includes("[threshold]")) throw new Error(`${name} exited ${code}`); } } finally {closeSync(fd);}
  }
  await run(["mutation:preflight"], "task-3-preflight");
  const manifest=JSON.parse(readFileSync(".tmp/stryker-shards/manifest.json","utf8"));
  writeFileSync(`${dir}/task-3-round1-preflight-manifest.json`,JSON.stringify(manifest,null,2));
  results.head="8f3d39370c8625f2465d089b6a80e6caf9ee7f97";
  results.shards=manifest.shards.map((s:any)=>({id:s.id,sources:s.sources}));
  for(const id of manifest.shards.filter((s:any)=>s.sources.some((source:string)=>["packages/db/src/analytics-ingestion.ts","apps/worker/src/jobs/analytics-activity.ts","apps/worker/src/jobs/deferred.ts"].includes(source))).map((s:any)=>s.id)) {
   const shard=manifest.shards.find((s:any)=>s.id===id);if(!shard) throw new Error(`expected shard missing: ${id}`);
   await run(["test:mutation"],`task-3-preview-${id}`,{MUTATION_SHARD:id});
   const scored=JSON.parse(readFileSync(".tmp/stryker-shards/manifest.json","utf8"));
   writeFileSync(`${dir}/task-3-preview-${id}-round1-manifest.json`,JSON.stringify(scored,null,2));
  }
 } finally {await fixture.stop();}
}
main().then(()=>{results.end=new Date().toISOString();writeFileSync(`${dir}/task-3-preview-round1-execution.json`,JSON.stringify(results,null,2));console.log("preview_complete");},e=>{results.end=new Date().toISOString();results.error=String(e.message).replace(/postgres(?:ql)?:\/\/[^\s]+/g,"[redacted]");writeFileSync(`${dir}/task-3-preview-round1-execution.json`,JSON.stringify(results,null,2));console.error(results.error);process.exitCode=1;});
