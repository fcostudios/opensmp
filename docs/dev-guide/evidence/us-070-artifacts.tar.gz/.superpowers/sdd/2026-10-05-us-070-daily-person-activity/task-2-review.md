### Spec Compliance

- ❌ Issues found: production behavior matches Task 2, but mandated rejection/nullable/duplicate oracles leave genuine survivors unapproved. Production checks: shared snapshot records (contracts.ts:87), nested nullable identity and explicit counters (providers/anthropic/connector.ts:206), bounded opaque pagination (connector.ts:555), cross-page duplicate validation and no summaries request (connector.ts:677), canonical safe replay dispatch (dispatch.ts:399).
- ⚠️ Mutation evidence reviewed at head 2db44d1; 66 residuals classified independently below. Worker/database global requirements outside this task remain controller checks.
- Checked official [List User Activity reference](https://platform.claude.com/docs/en/api/http/beta/organization/analytics/users/list): nested optional/null user and next_page are documented; has_more is not a documented required field. Optional tolerance at connector.ts:566 is appropriate, while supplied malformed/inconsistent flags still reject.

### Strengths

- connector.test.ts:125 and connector.pact.test.ts:101 constrain distinct counters, nullable identity, exact analytics request policy and no summaries call; Pact explicitly remains local contract evidence.
- dispatch.test.ts:1346 constrains canonical reconstruction, discarded raw, invalid dates, mixed days, identity conflicts and malformed nested counts.
- connector.ts:680 validates identities across the entire collected snapshot before returning records; connector.test.ts:1334 adds cross-page conflict oracles.

### Issues

- Critical: none found in bounded code review.
- Important: dispatch.test.ts:1346 omits successful nullable identity and equivalent-duplicate cases, independent malformed identity cases and same-email conflicts; connector.test.ts:981 omits nested user.type/email failures, exact explicit-day success and optional/inconsistent pagination flags. These missed required oracles permit the genuine survivors below; add only the stated contracts and rerun affected previews.
- Minor: dispatch.test.ts:1346 and connector.ts:566 use dense formatting that makes boundary conditions harder to scan; format the new blocks consistently when next touched.

### Assessment

**Task quality:** Needs fixes.

**Reasoning:** The production changes implement the documented per-person contract with normalized minimal output and preserve cost production parsing. Current previews leave genuine required-contract survivors unapproved; repair the targeted oracles before task approval.

### Checks and limits

- Read supplied diff once; recovered only tool-truncated middle sections from the same diff package. No git state commands, checkout/index/HEAD changes, tests or subagents.
- Named focused risk: stringify duplicate equality depends on deterministic shared normalization. Checked only unchanged normalizeActivityCounters at contracts.ts:181–222: fixed allowlist order canonicalizes keys, preserves null/missing distinctions, and rejects malformed nested metric objects/counts. No broader crawl.
- Reviewed existing report evidence: final affected suite 310 passed, DB focused suite 17 passed, connector type-check and diff check succeeded; did not rerun reported validation.

### Mutation evidence

- Latest controller report: task-2-preview-report.md; contracts 61 killed/8 survived, Anthropic 89 killed/17 survived, dispatch 52 killed/40 survived/1 NoCoverage. No tests repeated by reviewer. Dispatch threshold failed, but decisions below depend on semantics, not score alone.
- Named focused risk: upstream clone validation may make guard mutants redundant. Checked only unchanged validateResult/cloneAndFreeze at dispatch.ts:185–200,254–259; values are structured-cloned but not JSON-asserted, so cloneable malformed identity types remain reachable.
- Classification totals: {'equivalent': 23, 'accepted': 8, 'repair': 35}. Diagnostic-only accepted residuals do not weaken validation and need no wording-only tests. No genuine survivor is approved.

### vitest-4a99c1dc33c5 exact residual classification

- @equivalent vitest-4a99c1dc33c5:29 packages/connectors/src/contracts.ts:202 replacement `false` — Removing the explicit null guard still rejects null via Object.getPrototypeOf(null); rejection is the contract.
- @accepted vitest-4a99c1dc33c5:37 packages/connectors/src/contracts.ts:204 replacement ```` — Only diagnostic wording changes; malformed metric objects still reject.
- @equivalent vitest-4a99c1dc33c5:55 packages/connectors/src/contracts.ts:213 replacement `false` — Number.isInteger and negative check still reject every nonnumber/nonfinite value.
- @equivalent vitest-4a99c1dc33c5:56 packages/connectors/src/contracts.ts:213 replacement `typeof metric !== "number" && !Number.isFinite(metric)` — Integer check independently rejects nonnumber/nonfinite values.
- @equivalent vitest-4a99c1dc33c5:57 packages/connectors/src/contracts.ts:213 replacement `false` — Number.isFinite plus integer check still rejects every nonnumber.
- @accepted vitest-4a99c1dc33c5:66 packages/connectors/src/contracts.ts:215 replacement ```` — Only diagnostic wording changes; malformed counts still reject.
- @accepted vitest-4a99c1dc33c5:67 packages/connectors/src/contracts.ts:218 replacement ```` — Only diagnostic path changes; nested metric normalization and rejection stay identical.
- @accepted vitest-4a99c1dc33c5:68 packages/connectors/src/contracts.ts:222 replacement `""` — Only diagnostic root path changes; normalized counters and rejection stay identical.

### vitest-766ecaa54205 exact residual classification

- UNAPPROVED genuine survivor — repair required vitest-766ecaa54205:2 packages/connectors/src/providers/anthropic/connector.ts:215 replacement `false` — Null/nonobject data row now throws on item.user instead of returning sanitized provider failure; assert exact failure envelope for data:[null] or data:[3].
- @equivalent vitest-766ecaa54205:4 packages/connectors/src/providers/anthropic/connector.ts:216 replacement `false` — record(null/undefined) remains null and optional user fields preserve null identities either way.
- UNAPPROVED genuine survivor — repair required vitest-766ecaa54205:14 packages/connectors/src/providers/anthropic/connector.ts:217 replacement `false` — Wrong nonnull user.type is accepted; assert user:{type:"invite",id:"u",email_address:"a@example.test"} rejects.
- UNAPPROVED genuine survivor — repair required vitest-766ecaa54205:32 packages/connectors/src/providers/anthropic/connector.ts:220 replacement `false` — Malformed nested string email can escape as undefined; assert invalid email_address string returns exact sanitized failure.
- UNAPPROVED genuine survivor — repair required vitest-766ecaa54205:44 packages/connectors/src/providers/anthropic/connector.ts:221 replacement `true` — Correct explicit queried date is rejected; assert a valid row with date equal to queried day succeeds.
- UNAPPROVED genuine survivor — repair required vitest-766ecaa54205:46 packages/connectors/src/providers/anthropic/connector.ts:221 replacement `validDate(item.date)` — Inverted validDate rejects correct explicit queried date; assert successful explicit exact-day row.
- @equivalent vitest-766ecaa54205:52 packages/connectors/src/providers/anthropic/connector.ts:565 replacement `true` — Extra record conversion for non-analytics endpoints is unused; original body still goes to unchanged cost parser.
- UNAPPROVED genuine survivor — repair required vitest-766ecaa54205:65 packages/connectors/src/providers/anthropic/connector.ts:566 replacement `false` — Provided has_more validation is removed; assert boolean disagreement with next_page rejects.
- UNAPPROVED genuine survivor — repair required vitest-766ecaa54205:67 packages/connectors/src/providers/anthropic/connector.ts:566 replacement `true` — Omitted documented-optional has_more is rejected; assert valid envelope with only data and next_page succeeds.
- UNAPPROVED genuine survivor — repair required vitest-766ecaa54205:68 packages/connectors/src/providers/anthropic/connector.ts:566 replacement `body.has_more === undefined` — Optional flag condition inversion rejects omission and bypasses supplied flags; assert omission success and inconsistent flag failure.
- UNAPPROVED genuine survivor — repair required vitest-766ecaa54205:70 packages/connectors/src/providers/anthropic/connector.ts:566 replacement `typeof body.has_more !== "boolean" && body.has_more !== (body.next_page !== null)` — Boolean but inconsistent has_more is accepted; assert false/non-null cursor and true/null cursor failures.
- @equivalent vitest-766ecaa54205:71 packages/connectors/src/providers/anthropic/connector.ts:566 replacement `false` — Strict inequality against boolean (next_page !== null) already rejects every nonboolean has_more.
- UNAPPROVED genuine survivor — repair required vitest-766ecaa54205:74 packages/connectors/src/providers/anthropic/connector.ts:567 replacement `false` — Boolean flag/cursor disagreement is accepted; assert inconsistent flag returns sanitized failure.
- @equivalent vitest-766ecaa54205:89 packages/connectors/src/providers/anthropic/connector.ts:692 replacement `false` — Null ID is never indexed in this single mutant; unguarded get(null) returns undefined.
- @equivalent vitest-766ecaa54205:92 packages/connectors/src/providers/anthropic/connector.ts:693 replacement `false` — Null email is never indexed in this single mutant; unguarded get(null) returns undefined.
- @equivalent vitest-766ecaa54205:100 packages/connectors/src/providers/anthropic/connector.ts:698 replacement `true` — Indexing null ID is unobservable because unchanged lookup explicitly skips null IDs.
- @equivalent vitest-766ecaa54205:103 packages/connectors/src/providers/anthropic/connector.ts:699 replacement `true` — Indexing null email is unobservable because unchanged lookup explicitly skips null emails.

### vitest-d6a5d66bfe0f exact residual classification

- @accepted vitest-d6a5d66bfe0f:3 packages/connectors/src/dispatch.ts:403 replacement `""` — Only records-envelope diagnostic wording changes; invalid envelope still rejects.
- UNAPPROVED genuine survivor — repair required vitest-d6a5d66bfe0f:2 packages/connectors/src/dispatch.ts:403 replacement `false` — Removing array guard allows empty cloneable typed-array records to normalize to success; assert records:new Uint8Array() rejects as nonarray.
- UNAPPROVED genuine survivor — repair required vitest-d6a5d66bfe0f:8 packages/connectors/src/dispatch.ts:405 replacement `false` — Removes identity validation while final date equality remains; assert invalid string email and numeric/blank provider ID with valid date reject.
- UNAPPROVED genuine survivor — repair required vitest-d6a5d66bfe0f:9 packages/connectors/src/dispatch.ts:405 replacement `(!record || typeof record !== "object" || !(record.email === null || typeof record.email === "string" && email.test(record.email)) || !(record.providerUserId === null || isMemberPageToken(record.providerUserId)) || typeof record.activityDate !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(record.activityDate)) && !Number.isFinite(new Date(record.activityDate + "T00:00:00Z").getTime())` — Conjoins identity guard with invalid-date guard; valid-date malformed identities escape; assert invalid string email/provider ID rejects.
- UNAPPROVED genuine survivor — repair required vitest-d6a5d66bfe0f:10 packages/connectors/src/dispatch.ts:405 replacement `false` — Removes identity/type/format guards; valid-date malformed identities escape; assert invalid string email/provider ID rejects.
- UNAPPROVED genuine survivor — repair required vitest-d6a5d66bfe0f:11 packages/connectors/src/dispatch.ts:405 replacement `(!record || typeof record !== "object" || !(record.email === null || typeof record.email === "string" && email.test(record.email)) || !(record.providerUserId === null || isMemberPageToken(record.providerUserId)) || typeof record.activityDate !== "string") && !/^\d{4}-\d{2}-\d{2}$/.test(record.activityDate)` — Conjoins identity/type guards with bad date format; valid-date malformed identities escape; assert invalid string email/provider ID rejects.
- UNAPPROVED genuine survivor — repair required vitest-d6a5d66bfe0f:12 packages/connectors/src/dispatch.ts:405 replacement `false` — Removes identity guards; assert invalid string email/provider ID on valid date rejects.
- UNAPPROVED genuine survivor — repair required vitest-d6a5d66bfe0f:13 packages/connectors/src/dispatch.ts:405 replacement `(!record || typeof record !== "object" || !(record.email === null || typeof record.email === "string" && email.test(record.email)) || !(record.providerUserId === null || isMemberPageToken(record.providerUserId))) && typeof record.activityDate !== "string"` — Conjoins identity guards with nonstring date; assert malformed identity on valid string date rejects.
- UNAPPROVED genuine survivor — repair required vitest-d6a5d66bfe0f:14 packages/connectors/src/dispatch.ts:405 replacement `false` — Removes identity guards; assert malformed email and provider ID with valid date rejects.
- UNAPPROVED genuine survivor — repair required vitest-d6a5d66bfe0f:15 packages/connectors/src/dispatch.ts:405 replacement `(!record || typeof record !== "object" || !(record.email === null || typeof record.email === "string" && email.test(record.email))) && !(record.providerUserId === null || isMemberPageToken(record.providerUserId))` — Conjoins email and ID failures; assert each malformed identity independently rejects with the other identity valid.
- UNAPPROVED genuine survivor — repair required vitest-d6a5d66bfe0f:16 packages/connectors/src/dispatch.ts:405 replacement `false` — Removes email validation; assert invalid email string on otherwise valid row rejects.
- UNAPPROVED genuine survivor — repair required vitest-d6a5d66bfe0f:17 packages/connectors/src/dispatch.ts:405 replacement `(!record || typeof record !== "object") && !(record.email === null || typeof record.email === "string" && email.test(record.email))` — Conjoins object failure and email failure; assert invalid email string on otherwise valid object rejects.
- @equivalent vitest-d6a5d66bfe0f:18 packages/connectors/src/dispatch.ts:405 replacement `false` — Null/nonobject records still reject through property access or remaining required field guards; rejected input contract is unchanged.
- @equivalent vitest-d6a5d66bfe0f:19 packages/connectors/src/dispatch.ts:405 replacement `!record && typeof record !== "object"` — Weakening object guard still rejects null/primitives through access/remaining required-field checks.
- @equivalent vitest-d6a5d66bfe0f:21 packages/connectors/src/dispatch.ts:405 replacement `false` — Nonobject values lack required valid fields and still reject; functions cannot survive preceding structuredClone.
- UNAPPROVED genuine survivor — repair required vitest-d6a5d66bfe0f:25 packages/connectors/src/dispatch.ts:406 replacement `true` — Disables email validation; assert malformed string email on valid row rejects.
- UNAPPROVED genuine survivor — repair required vitest-d6a5d66bfe0f:28 packages/connectors/src/dispatch.ts:406 replacement `false` — Rejects valid null email; assert exact successful canonical record for email:null.
- UNAPPROVED genuine survivor — repair required vitest-d6a5d66bfe0f:29 packages/connectors/src/dispatch.ts:406 replacement `record.email !== null` — Rejects null email and accepts invalid nonnull email; assert nullable identity success and malformed string failure.
- UNAPPROVED genuine survivor — repair required vitest-d6a5d66bfe0f:31 packages/connectors/src/dispatch.ts:406 replacement `typeof record.email === "string" || email.test(record.email)` — Any string email now bypasses regex; assert malformed string email rejects.
- UNAPPROVED genuine survivor — repair required vitest-d6a5d66bfe0f:32 packages/connectors/src/dispatch.ts:406 replacement `true` — Boxed String email can satisfy coercive regex and normalize despite wrong type; assert new String("a@example.test") rejects.
- UNAPPROVED genuine survivor — repair required vitest-d6a5d66bfe0f:36 packages/connectors/src/dispatch.ts:407 replacement `true` — Disables provider ID validation; assert numeric/blank/control-character provider IDs reject.
- UNAPPROVED genuine survivor — repair required vitest-d6a5d66bfe0f:39 packages/connectors/src/dispatch.ts:407 replacement `false` — Rejects valid null provider ID; assert canonical success with providerUserId:null.
- UNAPPROVED genuine survivor — repair required vitest-d6a5d66bfe0f:40 packages/connectors/src/dispatch.ts:407 replacement `record.providerUserId !== null` — Rejects null ID and bypasses nonnull ID validation; assert null success and malformed nonnull ID failure.
- @equivalent vitest-d6a5d66bfe0f:41 packages/connectors/src/dispatch.ts:408 replacement `false` — Final strict ISO date string equality rejects all nonstring activityDate values even without typeof guard.
- @equivalent vitest-d6a5d66bfe0f:45 packages/connectors/src/dispatch.ts:408 replacement `/\d{4}-\d{2}-\d{2}$/` — Final ISO slice equality prevents prefix/suffix/noncanonical dates despite relaxed regex.
- @equivalent vitest-d6a5d66bfe0f:46 packages/connectors/src/dispatch.ts:408 replacement `/^\d{4}-\d{2}-\d{2}/` — Final ISO slice equality prevents prefix/suffix/noncanonical dates despite relaxed regex.
- @equivalent vitest-d6a5d66bfe0f:54 packages/connectors/src/dispatch.ts:409 replacement `""` — Canonical YYYY-MM-DD parses as UTC without suffix; retained shape/ISO guards enforce the same day.
- @equivalent vitest-d6a5d66bfe0f:58 packages/connectors/src/dispatch.ts:410 replacement `""` — Canonical YYYY-MM-DD parses as UTC without suffix; retained shape/ISO guards enforce the same day.
- @accepted vitest-d6a5d66bfe0f:60 packages/connectors/src/dispatch.ts:411 replacement `""` — Only record-validation diagnostic wording changes; invalid records still reject.
- UNAPPROVED genuine survivor — repair required vitest-d6a5d66bfe0f:64 packages/connectors/src/dispatch.ts:413 replacement `record.email.toLowerCase` — Nullable email dereference throws; assert exact successful output for email:null.
- @accepted vitest-d6a5d66bfe0f:70 packages/connectors/src/dispatch.ts:420 replacement `""` — Only mixed-date diagnostic wording changes; mixed dates still reject.
- @equivalent vitest-d6a5d66bfe0f:73 packages/connectors/src/dispatch.ts:421 replacement `false` — Null IDs are never indexed; get(null) cannot return a previous record.
- UNAPPROVED genuine survivor — repair required vitest-d6a5d66bfe0f:75 packages/connectors/src/dispatch.ts:422 replacement `true` — Skips every email duplicate lookup; assert same normalized email/different provider IDs rejects.
- @equivalent vitest-d6a5d66bfe0f:76 packages/connectors/src/dispatch.ts:422 replacement `false` — Null emails are never indexed; get(null) cannot return a previous record.
- UNAPPROVED genuine survivor — repair required vitest-d6a5d66bfe0f:77 packages/connectors/src/dispatch.ts:422 replacement `record.email !== null` — Skips nonnull email duplicate lookup; assert same normalized email/different IDs rejects.
- UNAPPROVED genuine survivor — repair required vitest-d6a5d66bfe0f:81 packages/connectors/src/dispatch.ts:424 replacement `true` — Rejects equivalent duplicates; assert repeated same normalized row collapses to exactly one record.
- @accepted vitest-d6a5d66bfe0f:84 packages/connectors/src/dispatch.ts:424 replacement `""` — Only identity-conflict diagnostic wording changes; conflicting identities still reject.
- @equivalent vitest-d6a5d66bfe0f:85 packages/connectors/src/dispatch.ts:427 replacement `true` — Null-ID map insertion is unobservable because unchanged lookup skips null IDs.
- @equivalent vitest-d6a5d66bfe0f:88 packages/connectors/src/dispatch.ts:428 replacement `true` — Null-email map insertion is unobservable because unchanged lookup skips null emails.
- UNAPPROVED genuine survivor — repair required vitest-d6a5d66bfe0f:89 packages/connectors/src/dispatch.ts:428 replacement `false` — Omits email index; assert different IDs sharing normalized email reject.
- UNAPPROVED genuine survivor — repair required vitest-d6a5d66bfe0f:90 packages/connectors/src/dispatch.ts:428 replacement `record.email === null` — Only indexes null email, whose lookup is skipped; assert different IDs sharing normalized email reject.
