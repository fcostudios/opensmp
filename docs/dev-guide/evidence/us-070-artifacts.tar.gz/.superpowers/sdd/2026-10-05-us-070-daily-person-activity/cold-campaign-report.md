# US-070 authoritative cold diff campaign

**Runner PASS, independent residual sign-off pending.** Exactly one cache-cleared whole-diff campaign at source cutoff `e03e465e3e8be975bcaf8ca05662f0bf93bfb25a`, approved authority base `ed9ff60d9dda6aaf78fae5e9a61d189b1a8e4108`, work ID **US-070**, no shard selector. Source/test hashes match before/after; observed completion HEAD `e03e465e3e8be975bcaf8ca05662f0bf93bfb25a`. Outer invocation `2026-10-06T05:12:08.116Z–2026-10-06T05:24:18.160Z`, **730.044 seconds**; scored command started `2026-10-06T05:12:10.489Z`, exit **0**, **727.336 seconds** (12.1222667 minutes). Cache clear ran **once**, exit **0 /0.390 seconds**. No repeat campaign or evidence feedback/test_report was emitted.

Actual aggregate score **91.05914718019257% = 662 /727 ×100**. Native reports contain **727** mutants: **661 Killed**, **1 Timeout**, **61 Survived**, **4 NoCoverage**, **0 CompileError**, **0 RuntimeError**, **0 Ignored**. The runner scores only Killed/Timeout/Survived/NoCoverage, with Killed+Timeout detected; no excluded mutants in this campaign. Aggregate is weighted by native mutant counts, not an average of shard percentages. All seven shard thresholds passed.

| Shard | Native | Killed | Timeout | Survived | NoCoverage | Actual score | Result |
|---|---:|---:|---:|---:|---:|---:|---|
| schema-static-481df809eb04 | 12 | 11 | 0 | 1 | 0 | 91.666667% | passed |
| vitest-4a99c1dc33c5 | 69 | 61 | 0 | 8 | 0 | 88.405797% | passed |
| vitest-766ecaa54205 | 106 | 99 | 0 | 7 | 0 | 93.396226% | passed |
| vitest-7e4dfff580cb | 320 | 296 | 0 | 22 | 2 | 92.500000% | passed |
| vitest-d6a5d66bfe0f | 93 | 77 | 0 | 16 | 0 | 82.795699% | passed |
| vitest-e927482a8578 | 118 | 108 | 1 | 7 | 2 | 92.372881% | passed |
| vitest-f2d1787d45e2 | 9 | 9 | 0 | 0 | 0 | 100.000000% | passed |

Tool versions from the native campaign manifest: `{"node": "26.10.0", "pnpm": "9.15.0", "stryker": "9.6.1", "typescript": "5.9.3", "vitest": "4.1.10"}`. All shards executed cold; no mutation artifact was reused after the one cache clear. The manifest, reports and source hashes are preserved in `cold-campaign-results.json` /`cold-campaign-manifest.json`; native manifest SHA-256 `f7c83c8c6cc5ed5ab50ce15405aa1342bb9c10be622f6dcb5bdb4104590b1b7e`.

## Exact residual handoff

**65 residuals** (61 Survived +4 NoCoverage), each with exact shard/mutant/file/full location/replacement/status/native artifact hash. `cold-campaign-residuals.json` includes current-source preview matches: **65/65** match an existing preview native artifact by identical file source, full location and exact replacement. This is provenance for reviewer comparison, not final approval. Compact canonical table: `cold-campaign-residuals.md`.

- Residual JSON SHA-256 `ca9dd96c1e0f588e5250c4c3a4b5c9d0f2e8d3adb1428764dbaed23e504df183`.
- Residual table SHA-256 `c40a1682daee23ef01613d3fa162c1d5ab700f678e937e3a546c04fcbf7dc135`.
- The exact contracts null precheck residual `vitest-4a99c1dc33c5:29`, `packages/connectors/src/contracts.ts:202:9`, replacement `false`, remains a proposed **@accepted diagnostic difference** under Task1's narrower existing disposition; it must not be relabeled equivalent. No genuine/unapproved residual was self-approved. Independent reviewer owns final cold dispositions.

Timeout **`vitest-e927482a8578:116`**, `apps/worker/src/jobs/analytics-activity.ts:136:17–138:10`, replacement **`{}`**, removes the finally block containing **`client.release()`**. This is a detected resource-lifetime mutant, excluded from survivors. The native report records Timeout; the runner log does not supply a deeper timeout stack. No host sleep/wake event or ordinary cleanup failure was observed.

## Runtime and cleanup

Existing exports provisioned one owned shared PostgreSQL cluster and scoped committed-migration template. Default and `US070_MUTATION_DATABASE_*` owner/app pairs stayed in child env through the entire campaign; no URLs were logged. `SMP_TEST_POSTGRES_CLUSTER_URL` and shard/dry selectors were absent in the child. Fixture stop then cluster stop both succeeded in outer finally, with no nested errors. Immediate inventory briefly retained one ID; independent recheck proves **all owned IDs absent** and only the two preexisting nous containers running. No unrelated container was removed. Exact power window has **no Sleep/Wake/DarkWake events**, hash `e33bcf230e8a6b10e376801876e44f08f9d5a89939f74d0d9b6f4425146d1a46`; post-run snapshots are in `cold-campaign-after.json`. The idle guard does not promise prevention of thermal sleep.

## Commands and immutable native artifacts

- `rtk proxy node scripts/apply-migrations.mjs`: exit **0**, **0.545 seconds**; log `cold-campaign-fixture-apply.log`, SHA-256 `d94547ff57830639c06c9a0acff64c9e23d183af2c55a4f013fb10f0d366fd25`.
- `rtk pnpm mutation:cache:clear`: exit **0**, **0.39 seconds**; log `cold-campaign-cache-clear.log`, SHA-256 `02ef3f5df8d9b5048676c9e9e998ac0974a80671ef3a784a168ea72d9c4ca4cd`.
- `rtk proxy env MUTATION_BASE=ed9ff60d9dda6aaf78fae5e9a61d189b1a8e4108 MUTATION_WORK_ID=US-070 caffeinate -i pnpm test:mutation`: exit **0**, **727.336 seconds**; log `cold-campaign-run.log`, SHA-256 `6565900d3ce67be898b5ffd26127a70158a2939de59ab2771ce0fa4133c18ca6`.

- `cold-native-schema-static-481df809eb04.json`: SHA-256 `86585f1cd8fbfe3996f0fd728090c9f19a882589be1c67ba7b08fbaba45dfc82`.
- `cold-native-vitest-4a99c1dc33c5.json`: SHA-256 `d81f45d565810fc940b38cd915a2ccaa0a61d5898bc8fcdaf4c3f194a41eb621`.
- `cold-native-vitest-766ecaa54205.json`: SHA-256 `75156d058449c18b9fbe9a301e4024409379f94266ac4a68232740000c04393b`.
- `cold-native-vitest-7e4dfff580cb.json`: SHA-256 `2b22259539cf872ababdc69edcfdb5c24f86aa25bb6f93ad4b111518c36045c9`.
- `cold-native-vitest-d6a5d66bfe0f.json`: SHA-256 `058d20aadea72148a03a1285727d2fb5b34271adea9d99b5e363fedcdf980a96`.
- `cold-native-vitest-e927482a8578.json`: SHA-256 `4318deee1d8d7ce9402bd07cf8fa2f7e91199cb7bde13584553425ab05f4de97`.
- `cold-native-vitest-f2d1787d45e2.json`: SHA-256 `f0dc09328e4797a4bd7f51026e74a88296f99c2b2b25a29ef8871a6ea08cb706`.

No production/test/config/dependency edit, harness file change, residual approval, or second campaign occurred. Previous full gate and fresh independent migration evidence remain preserved. Closure waits for the independent exact cold residual reviewer.

Own `CODEX_THREAD_ID`: `01a10f8a-3a6a-7b00-b35d-789a5c95c49d`. Related filename-only rollout pointer: `/Users/fcolomas/.codex/sessions/2026/10/05/rollout-2026-10-05T23-47-59-01a10f8a-3a6a-7b00-b35d-789a5c95c49d.jsonl`. Token/cost totals are unavailable to this worker; controller may measure function/custom wrapper counters from that exact rollout. Local tool counts are not controller-session totals.
