# SDD ledger — plan: docs/superpowers/plans/2026-10-05-us-070-daily-person-activity.md

## Recovery state

- Item: US-070 only. Approved ready assessment: docs/readiness/US-070.json, 270 minutes.
- Design approved by Francisco, recorded as US070-DESIGN-20261005.
- Bound plan authority commit: ed9ff60. No implementation task dispatched yet.
- User selected fresh implementer per task with reviews. Sequential integration implementers/reviewers: gpt-6.1-sol; broad final reviewer: gpt-6-astra, as the SDD skill directs.
- Current checkout: /Users/fcolomas/Projects/smp, main, clean.
- Required pending input: isolated worktree consent or current checkout on a feature branch. Async question submitted; do not infer consent from elapsed time.
- When input arrives: create/reuse chosen workspace, copy this recovery ledger to that plan's ignored workspace, run install and baseline tests; record exact authority commit before Task 1. Native create_worktree tool is available and preferred, with ref ed9ff60.
- Work-state tools were sought in ALL_TOOLS; none are callable. This ledger preserves task state until those tools become available.

## Preflight consistency review

| Task/pair | Checked relationship | Finding |
|---|---|---|
| Task 1 | Additive common record/normalizer vs existing ActivitySnapshot; new schema and migration vs runtime grants; real-db assertions vs upsert semantics | Consistent: legacy snapshot untouched until Task 2; existing unique constraint mirrored only; column-limited UPDATE supports rerun. |
| Task 2 | New snapshot vs provider and dispatch fixtures; explicit counters vs nullable metrics; users-only endpoint vs no summary request | Consistent: contract, adapter and fixtures switch together; normalizer strips unknown fields and preserves null. |
| Task 3 | Resource-owning job vs deferred finally; mode filter vs provisioning independence; queried UTC date vs actual sync instant; warnings vs company scope | Consistent: job drain remains reusable, handler closes; scoped writes and global warnings have separate authority paths. |
| Task 1 / Task 2 | Shared contracts.ts and ActivityIngestionRecord/normalizeActivityCounters | Task 1 produces additive primitives; Task 2 changes only snapshot consumers and uses the same normalizer. Sequential edit/review avoids overlap. |
| Task 1 / Task 3 | ingestActivityBatch/resolveActivityScopes and ActivityBatchResult | Names/field shapes agree. Trusted company list comes from worker database enumeration; scoped caller receives no foreign identity data. Driver typing must compile for both current app client and worker transaction. |
| Task 2 / Task 3 | VendorConnector.syncActivity, ActivitySnapshot.records and Pact-backed transport | Worker consumes the same validated dated record contract; minimal identity and counters suffice for DB replay reconstruction. |
| Integration / all tasks | Committed-candidate previews, broad adversarial review, cold campaign ordering and evidence-only closure | Consistent: no implementation after authoritative campaign without invalidation; changed shards selected from post-task preflight; no US-071 execution. |

## Task state

- Task 1: todo — shared persistence/migration.
- Task 2: todo — provider contract correction.
- Task 3: todo — daily worker execution.
- Integration/adversarial/cold mutation/terminal actuals: todo.

No rulings or review findings yet. No worker baseline or implementation verification claimed.

Workspace consent received: Francisco said Go ahead, work until is completed tested and verified. Native worktree created at /Users/fcolomas/.codex/worktrees/us-070-activity/smp; feature/analytics/daily-person-activity. Authority base ed9ff60. Setup/baseline starting.

Baseline: install/test passed, 2714 passed/12 skipped (Turbo cached); Docker available. Task 1 doing, base ed9ff60; implementation phase 2026-10-06T01:39:01.026992+00:00.

Ruling: Task 1 seeds distinct globally unique Person emails and proves isolation with a foreign-only email passed to company A — the existing global uq_person_lower_email makes the planned same-email cross-company fixture impossible; preserve canonical identity schema — cost if wrong: isolation fixture rework, no production schema impact. Sent to implementer.

Task 1 RED observed: focused Vitest exit 1 for missing analytics-ingestion module, not infrastructure. Implementer proceeding to production.

Ruling: Task 1 may update only expected activity column grants in packages/db/scripts/verify-schema.mjs — the existing verifier hard-codes expected privileges and would otherwise reject the approved migration; preserve verifier logic — cost if wrong: grant-map rework and schema-gate rejection. Treat as required schema verification metadata, not new tooling. Add path to touched-preview discovery.

Task 1 implemented 446feb7403b654a9c8bfba10820adc498077ccb9; DB 301/301, focused 10/10, type checks pass. Preview pending; independent review pending. Focused verification starts 2026-10-06T01:58:09.929183+00:00.

Task 1 preview: initial preflight missing DB pair; corrected preflight succeeded, three touched shards. Schema-static preview 0/12 killed, 12 survived; contracts/ingestion not yet run. Original implementer repairing established schema.test.ts routing seam with real PostgreSQL differential oracle (no production/router change). Critical-path generated docs delivery bd151bd, pending broad review.

Task 1 oracle repair b13578cd0d42979b3c2e94439bdcc46264827b18: contracts direct seam3/3, ingestion15/15, type checks pass; production unchanged. Representative empty allowlist, missing UUID validation, missing Person lock RED demonstrated. Re-preview only contracts/ingestion; retain schema11/12 (91.67%), one equivalence proposal. Preview survivor classifications require independent approval.

Ruling: authorize private activity allowlist construction inside normalizeActivityCounters once static-mutant import ordering is evidenced — manual source replacement kills the tests but all20 import-time declaration mutants survive the runner activation seam; preserve public fields/behavior and change no harness/cache/lifecycle — cost if wrong: modest per-record construction overhead and refactor rework. Contracts59.42%; ingestion repaired92.43%; schema91.67% retained.

Task 1 preview gates pass at e4f62808f3f8a38d71e6b3bc89c52a3112a9f607: schema91.67%(11k/1s), contracts88.41%(61k/8s), ingestion92.43%(293k/22s/2NC); focusedDB15/15 after shared-helper change. Enter review 2026-10-06T02:50:39.715381+00:00. Independent task review including all survivor exceptions pending.

Task 1 review: Important I1 identity namespaces collide (email provider:x@example.test vs missing-email provider ID x@example.test); spec/quality Needs fixes. Fix round1/5 dispatched original /root/task1, base e4f62808f3f8a38d71e6b3bc89c52a3112a9f607. Reviewer approved24equivalent+9accepted current residuals incl2NoCoverage; task-1-review.md. Cross-task worker/provider/date/global-warning gates remain pending.

Task 1 fix round1/5 implemented9dea85ccb70185e112c1e4d1c81a979176494825: I1namespace tags;16/16ingestion/typespass, scoped ingestionpreview and re-review pending. Reviewfixbasee4f62808f3f8a38d71e6b3bc89c52a3112a9f607. Focusedverification 2026-10-06T02:56:23.253799+00:00.

Recovery handoff prepared controller-resume.md; green implementation/fix commits retained. Same US-070 controller work item continues with fresh bounded coordination context after ~150+ aggregate controller calls; no retired checkpoint event emitted. Task1preview/re-review still pending; do not skip or repeat implementation.

Task1 latest ingestion preview9dea85c PASS92.19% (295k/23s/2NC),4.71minutes; retained schema/contracts. Fresh scoped re-review/remapping in progress. Task boundary forecast approximately320minutes vs270; deviation emitted before Task2, scope unchanged.

Task1 fix round1 scoped review I1 ADDRESSED; no new fix breakage. Exact residual remapping identifies new genuine survivor137 email identity conditional false; targeted duplicate oracle repair dispatched original /root/task1 as fix round2/5. Previous33 approvals retained pending signed current table.

Task1 fix round2/5 candidate4b91e690b49980c016b1db5dc66cecf0f199ec12: test-only duplicate identity regression kills137 RED,17/17/types GREEN. One ingestion-only round6 dispatched to /root/baseline; repeated activation messages explicitly deduplicated. Re-review awaiting preview. Work_state tool discovery remains empty.

Task1: fix round2/5 (M1 addressed,0open; commits9dea85c..4b91e69). Round6 ingestion92.50%(296k/22s/2NC),4.905minutes. Reviewer signed current33residuals24equivalent9accepted0unapproved.
Task 1: complete (commits ed9ff60..4b91e69, review clean). Downstream-only warnings/provider/date requirements explicitly owned Task2/Task3/final review; not missing Task1 scope. Minor query-count lock diagnostic remains for final triage.
Task2: doing, base4b91e690b49980c016b1db5dc66cecf0f199ec12; remaining forecast unchanged320minutes total/deviation recorded.

Ruling: final broad reviewer uses available task-review rubric extended to approved whole-branch architecture/AC1..4 and deferred findings because referenced requesting-code-review/code-reviewer.md template is absent in both skill roots — review scope/model/diff/evidence gates remain binding — cost if wrong: reviewer-format rework, no production change.

Continuation controller cost provenance: own CODEX_THREAD_ID01a10f28-fa30-73d1-aeda-9aa032235911; own rollout /Users/fcolomas/.codex/sessions/2026/10/05/rollout-2026-10-05T22-01-46-01a10f28-fa30-73d1-aeda-9aa032235911.jsonl. Metadata-only inspection available: token_count event records, response_item function_call, turn_context; context metric = last_token_usage.input_tokens maximum/current peak, not cumulative total_input_tokens. Window258400; modelgpt-6.1-sol effortlow. Recompute at closure; tool wrappers may not equal nested calls, label convention.

Task2 implemented2db44d1cb74f3ba9c61ced55963a507ae25a80c3;310connector/Pact/dispatch+17DBingestion GREEN/typespass. Task2 preview2 preflight/touched shards active; task2_review code review then exact residual approval pending. Report concern has_more optional per official users contract judged independently by reviewer.

Task2 preview round1: ordinary preflight5expected/actual; touched contracts61k8s88.41%,Anthropic89k17s83.96%,dispatch52k41s55.91%thresholdFAIL,0NC.2.91125previewminutes,fixturecleaned.66residuals pending independent review/targeted oracle repair; unchanged ingestion/schema retained because contracts edit only type alias.

Task2 review needsfixes:35genuine missing-oracle residuals;23equivalent8accepted. Fixround1/5 resumed original /root/controller_resume/task2,base2db44d1,precise required boundary oracles in task-2-review.md. No production defect claimed. Minor dense formatting in dispatch test/providerpagination retained for broad triage. Count discrepancy dispatch40s1NC vs41s0NC reconciliation read-only pending; no rerun.

Correction Task2 dispatch exact retained JSON52Killed40Survived1NoCoverage (diagnostic mutant3line403); previous chat summary41Survived0NC was mislabeled. Report JSON/table already correct, verifier appended cutoff/hash reconciliation, no rerun;66residuals unchanged.

Task2 fixround1candidatecfcfe8d1821cb73b83bc47a379f63b8f35530d68 test-only,11representativebehavioralREDs/307affectedGREEN/typespass. Exact provider+dispatch test-seam re-preview round2 active;contracts retained. Scoped re-review checks35genuine categories and latest signed residuals.

Task2 fixround1/5 (35genuineprevioussurvivorsKilled,0open;commits2db44d1..cfcfe8d). Round2provider93.40%(99k7s),dispatch82.80%(77k16s),noNC;2rounds5.09827previewminutes. Reviewer signs31residuals23equivalent8accepted0unapproved.
Task 2: complete (commits4b91e69..cfcfe8d,reviewclean). Minor dense formatting stays broad review triage.
Task3: doing,basecfcfe8d1821cb73b83bc47a379f63b8f35530d68;forecast320minute total remains deviationreported.

Ruling: Task3 may correct only analytics-ingestion.ts relative imports to schema.js/system-ids.js — worker NodeNext type-check cannot consume delivered extensionless shared export, crossscope correction is necessary without semantic change — cost if wrong: import rework and ingestion preview minutes.
Ruling: Task3 uses existing two-role Anthropic credential composition and fixtures seed encrypted admin_scoped plus analytics credentials — existing dispatcher factory requires both, approved work reuses credential architecture and preserves endpoint keyseparation — cost if wrong: unnecessary credential coupling needs bounded connector follow-up; independent review assesses required analytics-only behavior.

Task3 implemented8f3d39370c8625f2465d089b6a80e6caf9ee7f97,worker11/11+types/DB17/17+activityPactGREEN,readinessvalid. Narrow .js sharedimportcorrectionincluded; noothercrossscopeedit. Task3preview3 exacttouchedpreviewsactive;fresh task3_review specquality+residualsignoffpending. Worker estimate7minutes not accepted as closedactuals; finalcontroller phases determine nonoverlap actuals.

Task3 preflight7actual vs5expected; named shardcountdeviationemitted,readinesspayloadunchanged. Only newjob/deferred/changedingestion previewsrunning.

Task3 Importanttransactiondefectfoundindependently: manualBEGIN+rootdrizzle(client) nestedsharedingestion issuesBEGIN/COMMIT notsavepoints; firstcompanycommitreleasesaccountmode locks andglobalwarningsoutsideoutertx. InstalledDrizzleroot/nestedtransaction implementation evidence in reviewerreportforthcoming. Do notaccept; fullfixround1 waits currentpreviewcompletion toavoidscoredtreemutation. Initialjobpreview79.51%(96Killed1Timeout20Survived5NC122total)thresholdFAIL;remainingdeferred/ingestionrunning.

Task3reviewNeedsfixes ImportantI1outertransaction/lifetime,I2nineteengenuineboundary/seamoracles;24equivalent11accepted54totalresiduals. Fixround1/5 originaltask3resumedbase8f3d393. Taskboundaryreassessment~190activechildminutesestimated+remaining90–110 -> forecast300–320, prior320deviationremainsconservative; exactclosedactualsphase-derived.
Task3previewcleanup: fixture.stopAggregateError launcherexit1; nestedcausesirrecoverablemessage-onlylog, roledependenciesfromtimeoutclient.release-removalleadinginferenceunproven. PrivatePGcontainerremovedprovenDockerinventory. No previewrerun/harnesschange. Nextscratchlauncher capturesanitizednestederrors; do notmislabelcleanupaspassed.

Task3 fixround1/5 committed927835e559d3b330f3c49436ca095939f3a21216,actualDrizzletx+nineteenboundaryoraclecontracts+formatting. RealDB2REDs reproduced I1;27focusedGREEN/types/diffpass. Previewround2/reviewNOTDISPATCHED yet, noactivegate. Fixbase8f3d393,currenthead927835e. Freshsameitemcontrollerhandoffprepared due154+calls/142kcontext; no retiredcheckpointfeedbackevent. Nextcontroller owns Task3round2worker+deferredonlypreviews,scopedrereview then broadACreview/gates/coldcampaign/closure.

Task3 round2 job/deferred-only previews and scoped re-review resumed by /root/controller_finish at 2026-10-06T04:09:23.437395+00:00. No scored mutation after927835e; retained earlier shards. Work-state tools still unavailable; durable ledger fallback.

Task3 fixround1/5 accepted927835e: I1/I2/M1 addressed, job92.37%(108k1timeout7s2NC), deferred100%(9k),2previewrounds11.859317minutes. Scoped reviewer signed33currenttouched/retained residuals24equivalent9accepted0unapproved.
Task 3: complete (commits cfcfe8d..927835e, spec AND quality approved).
Ruling: final verification scratch launcher owns a disposable shared PostgreSQL cluster plus scoped fixture, stopping fixture then owning cluster in outer finally — both private-preview helper DROP ROLE failures are observed2BP01 dependencies and container containment is proven; this uses existing exports without scored source/config/harness change — cost if wrong: bounded teardown repair and verification-stage infrastructure rework, never suppressed diagnostics.

Integration gates activated2026-10-06T04:16:27.116159+00:00 at927835e. Final gpt6-astra spawn failed agentthreadlimitreached; rootsupervisor notified; no alternate verdict/campaignclaimed.

Broad whole-branch gpt6-astra review: AC1..4PASS;0Critical/Important,2Minors. ONE bounded docs-only final fix wave active forM2;M1accepted explicitly. Standard-model fallback notused: highestcapable spawn succeeded after gate terminal.
Ruling: retain Minor M1 company-summary note omission as an explicit design discrepancy; do not add an account-level summary — independent whole-branch review verifies exact global warning detail persistence and existing globally authorized audit visibility satisfy canonical AC2, while company summaries correctly retain scoped counts in after — cost if wrong: bounded summary-note follow-up and operator discoverability rework; no warning evidence is lost.
Ruling: fix Minor M2 through normal Nous critical-path config preservation and generated-guide delivery, not production ambiguity behavior — approved interfaces and real atomic rejection assertions are binding, so generated warning prose is incorrect — cost if wrong: documentation/provenance rework only, no scored source change.
Ruling: classify the contracts null-guard residual as @accepted diagnostic difference, retaining Task1 narrower interpretation — removing the guard changes incidental Error subtype at Object.getPrototypeOf(null), so Task2 literal-equivalence label overstates its guarantee while acceptance/rejection stays tested — cost if wrong: exact residual annotation rework or targeted diagnostic oracle, never an unapproved genuine behavior waiver.

Taskboundaryforecast revised245–285min using recorded childphaseenvelope, excludingparentassessment/humanwait; prior320roughforecast was conservative, not measuredactual. Failedfullcheck17.7min retained, freshmigrationspassed, no coldattempts yet. Changedfile25v18deviation recorded.

Ruling: rerun one covering full pnpmcheck on unchanged scored code after the verified host suspension, without production/test/harness repairs — bounded pmset evidence records Dark Wake Thermal Emergency sleep997seconds matching unrelated993second test stalls and delayed timeout timers; it is an external execution interruption — cost if wrong: one additional gate run and deeper environment diagnosis, no weakened timeout/assertion/config.

Ruling: correct only the two existing worker-runtime oracles that still require the analytics deferred stub, preserving real queue/cron/vendor-account dedup assertions — full unchanged-code gate now reaches these tests and proves analytics success replaced generic/skipped stub logs; root authorized this bounded test adjustment within the ongoing final fix wave before its single combined scoped re-review — cost if wrong: focused queue contract rework and necessary selected-test preview, no production/harness weakening.

ONE combined final fix wave docsbc76f0c+teste03e465 accepted by gpt6-astra scoped re-review. Spec+qualityAPPROVED, M2fixed/M1accepted,0newfindings. Runtime oracle14GREEN/types/ownedcleanup. Coveringfinal pnpmcheck/preflight authorized; retained independent freshmigrations. No authoritativecampaign yet.
Correction: first runtimefailure was3expected skipped logs vs2actual, not generic-successcount; exactworkerreport supersedes earlier shorthand.

Ruling: retain all seven existing scoped previews and run zero touched previews after e03e465 — actual fixture-scoped ordinary preflight exits0 with7shards, runtime.integration.test.ts absent from every selected source/test seam, and production/dependencies/config unchanged; exact current manifest SHA2564375b68d388386f1fa721bc95a1ce69f431b7f7fc29168bc8a354fb5db6255a2 — cost if wrong: targeted affected-seam re-preview before cold, never blanket duplicate campaigns.
Post-finalfix preflight0.754s,0touchedpreviews, no extra preview round/mutationminutes; coveringfullcheckrunninge03e465.

Fullcovering pnpmcheck GREEN e03e465 exit0/202.404s: types9/9,lint8/8,tests15/15(tasks13cached;worker192pass8skip,DB309pass,webcached926pass3skip),build9/9(worker+Nextwebpackfresh). No powerevents, scopedfixture/ownedcluster clean andonly2nousrunning. Freshcommitted apply/verify/parity retained62checksums/32tables. ONEauthoritativecold nowauthorized exactbase/workID/no selector afteronecacheclear; verifier finishingreportthenstarting. No scoredchanges permitted aftercampaign.

Authoritativecold FIRSTattempt launched at e03e465, verifier/root/controller_finish/gate_diagnosis execsession16656. CacheclearONCE then full diff exactauthoritybase/workID/no selector. Actualdefault+US070 owner/app pairs alive; sourcehashes pinned; all7nativeartifacts will be preserved. DO NOTduplicate. Coldreport/independentsignoff/actuals/terminalevidencepending.
Boundedterminalclosure handoff controller-resume-3.md prepared afterfullgateGREEN/coldstart; sameitemcheckpointshape, allproduction/tests committedgreen. No retiredcheckpointevent.

Ruling: retain the independent cold reviewer’s narrower @accepted diagnostic classifications for dispatch residuals18/19 — both still reject unsupported inputs but may change Error to TypeError, so literal equivalence would overstate the guarantee — cost if wrong: residual annotation rework or a targeted typed-diagnostic oracle; no genuine behavior waiver.
Cold exact residual review APPROVED65/65:46equivalent19accepted0unapproved; source e03e465 unchanged. Terminal evidence closure only.
