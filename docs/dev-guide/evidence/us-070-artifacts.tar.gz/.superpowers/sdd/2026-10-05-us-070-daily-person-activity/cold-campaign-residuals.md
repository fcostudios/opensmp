| Shard | Mutant | File:line | Status | Exact replacement |
|---|---|---|---|---|
| schema-static-481df809eb04 | 5 | packages/db/src/schema.ts:479 | Survived | "\"\"" |
| vitest-4a99c1dc33c5 | 29 | packages/connectors/src/contracts.ts:202 | Survived | "false" |
| vitest-4a99c1dc33c5 | 37 | packages/connectors/src/contracts.ts:204 | Survived | "``" |
| vitest-4a99c1dc33c5 | 55 | packages/connectors/src/contracts.ts:213 | Survived | "false" |
| vitest-4a99c1dc33c5 | 56 | packages/connectors/src/contracts.ts:213 | Survived | "typeof metric !== \"number\" && !Number.isFinite(metric)" |
| vitest-4a99c1dc33c5 | 57 | packages/connectors/src/contracts.ts:213 | Survived | "false" |
| vitest-4a99c1dc33c5 | 66 | packages/connectors/src/contracts.ts:215 | Survived | "``" |
| vitest-4a99c1dc33c5 | 67 | packages/connectors/src/contracts.ts:218 | Survived | "``" |
| vitest-4a99c1dc33c5 | 68 | packages/connectors/src/contracts.ts:222 | Survived | "\"\"" |
| vitest-766ecaa54205 | 4 | packages/connectors/src/providers/anthropic/connector.ts:216 | Survived | "false" |
| vitest-766ecaa54205 | 52 | packages/connectors/src/providers/anthropic/connector.ts:565 | Survived | "true" |
| vitest-766ecaa54205 | 71 | packages/connectors/src/providers/anthropic/connector.ts:566 | Survived | "false" |
| vitest-766ecaa54205 | 89 | packages/connectors/src/providers/anthropic/connector.ts:692 | Survived | "false" |
| vitest-766ecaa54205 | 92 | packages/connectors/src/providers/anthropic/connector.ts:693 | Survived | "false" |
| vitest-766ecaa54205 | 100 | packages/connectors/src/providers/anthropic/connector.ts:698 | Survived | "true" |
| vitest-766ecaa54205 | 103 | packages/connectors/src/providers/anthropic/connector.ts:699 | Survived | "true" |
| vitest-7e4dfff580cb | 24 | packages/db/src/analytics-ingestion.ts:37 | Survived | "false" |
| vitest-7e4dfff580cb | 25 | packages/db/src/analytics-ingestion.ts:37 | Survived | "typeof value !== \"string\" && !/^\\d{4}-\\d{2}-\\d{2}$/.test(value)" |
| vitest-7e4dfff580cb | 26 | packages/db/src/analytics-ingestion.ts:37 | Survived | "false" |
| vitest-7e4dfff580cb | 30 | packages/db/src/analytics-ingestion.ts:37 | Survived | "/\\d{4}-\\d{2}-\\d{2}$/" |
| vitest-7e4dfff580cb | 31 | packages/db/src/analytics-ingestion.ts:37 | Survived | "/^\\d{4}-\\d{2}-\\d{2}/" |
| vitest-7e4dfff580cb | 75 | packages/db/src/analytics-ingestion.ts:51 | Survived | "true" |
| vitest-7e4dfff580cb | 79 | packages/db/src/analytics-ingestion.ts:51 | Survived | "value !== null" |
| vitest-7e4dfff580cb | 81 | packages/db/src/analytics-ingestion.ts:51 | Survived | "typeof value === \"object\"" |
| vitest-7e4dfff580cb | 82 | packages/db/src/analytics-ingestion.ts:51 | Survived | "\"\"" |
| vitest-7e4dfff580cb | 84 | packages/db/src/analytics-ingestion.ts:52 | Survived | "false" |
| vitest-7e4dfff580cb | 85 | packages/db/src/analytics-ingestion.ts:52 | NoCoverage | "``" |
| vitest-7e4dfff580cb | 86 | packages/db/src/analytics-ingestion.ts:52 | NoCoverage | "\"\"" |
| vitest-7e4dfff580cb | 88 | packages/db/src/analytics-ingestion.ts:53 | Survived | "Object.entries(value)" |
| vitest-7e4dfff580cb | 89 | packages/db/src/analytics-ingestion.ts:53 | Survived | "() => undefined" |
| vitest-7e4dfff580cb | 92 | packages/db/src/analytics-ingestion.ts:54 | Survived | "\"\"" |
| vitest-7e4dfff580cb | 149 | packages/db/src/analytics-ingestion.ts:75 | Survived | "false" |
| vitest-7e4dfff580cb | 163 | packages/db/src/analytics-ingestion.ts:81 | Survived | "true" |
| vitest-7e4dfff580cb | 166 | packages/db/src/analytics-ingestion.ts:87 | Survived | "true" |
| vitest-7e4dfff580cb | 228 | packages/db/src/analytics-ingestion.ts:134 | Survived | "{}" |
| vitest-7e4dfff580cb | 238 | packages/db/src/analytics-ingestion.ts:136 | Survived | "{}" |
| vitest-7e4dfff580cb | 245 | packages/db/src/analytics-ingestion.ts:139 | Survived | "{}" |
| vitest-7e4dfff580cb | 298 | packages/db/src/analytics-ingestion.ts:163 | Survived | "false" |
| vitest-7e4dfff580cb | 299 | packages/db/src/analytics-ingestion.ts:163 | Survived | "!current && current.syncedAt.getTime() < batch.syncedAt.getTime()" |
| vitest-7e4dfff580cb | 301 | packages/db/src/analytics-ingestion.ts:163 | Survived | "false" |
| vitest-d6a5d66bfe0f | 3 | packages/connectors/src/dispatch.ts:403 | Survived | "\"\"" |
| vitest-d6a5d66bfe0f | 18 | packages/connectors/src/dispatch.ts:405 | Survived | "false" |
| vitest-d6a5d66bfe0f | 19 | packages/connectors/src/dispatch.ts:405 | Survived | "!record && typeof record !== \"object\"" |
| vitest-d6a5d66bfe0f | 21 | packages/connectors/src/dispatch.ts:405 | Survived | "false" |
| vitest-d6a5d66bfe0f | 41 | packages/connectors/src/dispatch.ts:408 | Survived | "false" |
| vitest-d6a5d66bfe0f | 45 | packages/connectors/src/dispatch.ts:408 | Survived | "/\\d{4}-\\d{2}-\\d{2}$/" |
| vitest-d6a5d66bfe0f | 46 | packages/connectors/src/dispatch.ts:408 | Survived | "/^\\d{4}-\\d{2}-\\d{2}/" |
| vitest-d6a5d66bfe0f | 54 | packages/connectors/src/dispatch.ts:409 | Survived | "\"\"" |
| vitest-d6a5d66bfe0f | 58 | packages/connectors/src/dispatch.ts:410 | Survived | "\"\"" |
| vitest-d6a5d66bfe0f | 60 | packages/connectors/src/dispatch.ts:411 | Survived | "\"\"" |
| vitest-d6a5d66bfe0f | 70 | packages/connectors/src/dispatch.ts:420 | Survived | "\"\"" |
| vitest-d6a5d66bfe0f | 73 | packages/connectors/src/dispatch.ts:421 | Survived | "false" |
| vitest-d6a5d66bfe0f | 76 | packages/connectors/src/dispatch.ts:422 | Survived | "false" |
| vitest-d6a5d66bfe0f | 84 | packages/connectors/src/dispatch.ts:424 | Survived | "\"\"" |
| vitest-d6a5d66bfe0f | 85 | packages/connectors/src/dispatch.ts:427 | Survived | "true" |
| vitest-d6a5d66bfe0f | 88 | packages/connectors/src/dispatch.ts:428 | Survived | "true" |
| vitest-e927482a8578 | 39 | apps/worker/src/jobs/analytics-activity.ts:51 | Survived | "false" |
| vitest-e927482a8578 | 61 | apps/worker/src/jobs/analytics-activity.ts:61 | Survived | "options.kekFile" |
| vitest-e927482a8578 | 62 | apps/worker/src/jobs/analytics-activity.ts:61 | Survived | "options.kekFile.trim" |
| vitest-e927482a8578 | 65 | apps/worker/src/jobs/analytics-activity.ts:62 | Survived | "false" |
| vitest-e927482a8578 | 66 | apps/worker/src/jobs/analytics-activity.ts:63 | NoCoverage | "\"\"" |
| vitest-e927482a8578 | 91 | apps/worker/src/jobs/analytics-activity.ts:96 | Survived | "false" |
| vitest-e927482a8578 | 93 | apps/worker/src/jobs/analytics-activity.ts:96 | Survived | "\"\"" |
| vitest-e927482a8578 | 94 | apps/worker/src/jobs/analytics-activity.ts:97 | NoCoverage | "\"\"" |
| vitest-e927482a8578 | 99 | apps/worker/src/jobs/analytics-activity.ts:104 | Survived | "{}" |
