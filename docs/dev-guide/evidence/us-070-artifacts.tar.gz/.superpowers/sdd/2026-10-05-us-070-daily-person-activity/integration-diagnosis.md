# US-070 bounded integration diagnosis

Failed gate source: `927835e559d3b330f3c49436ca095939f3a21216`; observed HEAD: `bc76f0c3725920b211722806684ed8a39392310c`. The intervening diff contains generated guidance/provenance only; production/test/config/harness files were not edited in this diagnosis. No rerun was started.

## Single hypothesis and evidence

**The failed gate was interrupted by machine suspension, which let wall-clock test deadlines expire before JavaScript timers and workers could run.** The exact-window power log confirms sleep at `2026-10-05 23:18:01 -0500` (`2026-10-06 04:18:01 UTC`) due to `Dark Wake Thermal Emergency`, duration **997 seconds**, followed by DarkWake at `23:34:38 -0500` (`04:34:38 UTC`). This falls inside the gate `04:17:06.837–04:34:53.818 UTC`.

Independent failures match that interruption: approval-queue DOM test 993873 ms; operational-alert DB test 993468 ms; fixture hook suites about 1000 seconds despite 120–150-second timeouts; fork-worker response timeout. The DOM test has no PostgreSQL dependency. This establishes a host interruption rather than evidence of a common database deadlock or changed-code assertion failure. The locale undefined cleanup client remains a secondary consequence of incomplete setup; its teardown is not certified correct.

## Delivered runtime comparison

The scratch launcher sets `SMP_TEST_POSTGRES_CLUSTER_URL` for all package test tasks. Delivered `smp-web:test` calls `run-with-shared-postgres.ts`, whose setup owns a package cluster only when that env is absent; DB and worker invoke plain Vitest and both set `fileParallelism: false`. Fixtures on the supplied cluster create isolated databases with shared cluster roles. This scratch composition differs from ordinary package ownership, but no connection/lock evidence implicates it, and it cannot explain the independent DOM timer discontinuity. Stdout/stderr were written directly to a file descriptor, so no captured-output pipe backpressure was introduced.

## Smallest covering rerun proposal

After confirming the machine is awake and no other gate/campaign is running, run **delivered `pnpm test`, then `pnpm build`**, preserving default package runtime ownership (do not inject the scratch-wide shared-cluster URL). Record separate exits, wall durations, source cutoff, log hashes, sanitized resource snapshots, and bounded sleep/wake events before/after. Existing green type-check/lint and fresh committed-migration evidence remain valid for the unchanged scored tree; this pair covers the failed and unreached constituents. If closure requires the exact full command identity, use one `pnpm check` instead; do not first run this pair and then duplicate the full suite. An idle-sleep assertion such as `caffeinate -i` can guard idle suspension but **does not prevent thermal-emergency sleep**. Do not adjust source, timeouts, workers, config, harness, cache, or test oracles on this evidence. This proposal awaits controller authorization.

## Evidence pointers and limits

- `integration-power-window.log`: SHA-256 `08924f7617d41ef6e2db072cbe488c31183e3677382ebf508f3cddcabb517233`; contains only Sleep/DarkWake events from the authorized failed window.
- `integration-pnpm-check.log`: SHA-256 `27a6033721961e485bef7accf393f2c2d48030d9d635dbdb47ad0a1b6d03043a`; detailed failures at lines 635–919.
- `integration-results.json`: failed check exit 1 /1062.456 seconds; type-check/lint passed, tests failed, build unreached; fresh apply/verify/parity passed; owned containers absent on recheck.
- Earlier post-run memory/process counters do not measure pressure during the gate. Initial `docker ps -aq` included stopped IDs and does not prove they were running; no unrelated deletion or ownership attribution was made.
- Diagnosis tool calls: 8 `functions.exec` calls through this report write, 17 nested shell commands. Token/session cost metadata is unavailable; these local counters are not controller totals.
