# Task 1 non-authoritative preview

Candidate: 446feb7403b654a9c8bfba10820adc498077ccb9. Authority base: ed9ff60d9dda6aaf78fae5e9a61d189b1a8e4108.
Start (log creation): 2026-10-06T01:58:35.568463+00:00; end: 2026-10-06T01:59:24.907594+00:00. Elapsed: 0.82 minutes (includes diagnosis).

Command: `MUTATION_BASE=ed9ff60 MUTATION_WORK_ID=US-070 pnpm mutation:preflight` (via rtk). Exit 1. Discovery found 8 changed files, 3 mutatable sources, 5 ranges, 3 schema-static ranges; generated manifest has three intersecting Task 1 shards:

- schema-static-481df809eb04: packages/db/src/schema.ts
- vitest-79bcc0c40c4f: packages/connectors/src/contracts.ts
- vitest-7e4dfff580cb: packages/db/src/analytics-ingestion.ts

Root cause: `mutation-scope: runtime-profile-unavailable`. The database-backed runtime profile requires a migrated PostgreSQL template and both DATABASE_ADMIN_URL (ledger_owner) and DATABASE_URL (ledger_app), or one unambiguous USNNN_MUTATION_DATABASE_* pair. This preview command did not have that pair; Docker daemon reachability alone is insufficient. Source: scripts/mutation-scope.mjs defaultRuntimeProfile, especially missing-pair guard at line 2025. No credentials printed.

Stopped on the first nonzero error as requested; zero exact-shard previews executed. Killed/survived/score: unavailable (no mutants run). Surviving mutant locations/diffs: none generated. No campaign cache clearing, test_report, production/test/feedback edits, or broad rerun.

Next prerequisite: provision and migrate an isolated owner/app template, verify its schema, and pass its in-memory URL pair to the preview child environment. The shared-cluster env by itself does not satisfy runtime-profile identity.

Log: task-1-preflight.log. Discovery manifest: .tmp/stryker-shards/manifest.json.

## Corrected fixture attempt

Start: 2026-10-06T02:00:29.671Z; end: 2026-10-06T02:00:49.581Z. Total elapsed: 0.33 minutes; preview execution 0.265 minutes. Existing createPostgresFixture provisioned a private pinned cluster and migrated the template; URLs remained inside child env. Both default owner/app and US070 mutation owner/app pairs were set; fixture cleanup ran in finally. Corrected preflight exit 0 (0.018 minutes): three discovered Task 1 shards; expected full-story shards 5 vs current Task 1 shards 3 (mismatch=true; implementation is partial).

One non-authoritative preview round executed. `MUTATION_BASE=ed9ff60 MUTATION_WORK_ID=US-070 MUTATION_SHARD=schema-static-481df809eb04 pnpm test:mutation` exited 1: 0 killed, 12 survived, 0 timeout/no-coverage/errors; score 0%, below threshold 80%. This is oracle evidence, not the prior missing-pair infrastructure failure. Stopped on this next concrete failure; contracts and analytics-ingestion shards were not run. Cache was not cleared; no authoritative test_report emitted.

Surviving mutants:

- 0 packages/db/src/schema.ts:469:40 StringLiteral: `export const ingestion_source = pgEnum("ingestion_source", ["api", "csv_import", "manual"]);` → replacement `""`
- 1 packages/db/src/schema.ts:469:60 ArrayDeclaration: `export const ingestion_source = pgEnum("ingestion_source", ["api", "csv_import", "manual"]);` → replacement `[]`
- 2 packages/db/src/schema.ts:469:61 StringLiteral: `export const ingestion_source = pgEnum("ingestion_source", ["api", "csv_import", "manual"]);` → replacement `""`
- 3 packages/db/src/schema.ts:469:68 StringLiteral: `export const ingestion_source = pgEnum("ingestion_source", ["api", "csv_import", "manual"]);` → replacement `""`
- 4 packages/db/src/schema.ts:469:82 StringLiteral: `export const ingestion_source = pgEnum("ingestion_source", ["api", "csv_import", "manual"]);` → replacement `""`
- 5 packages/db/src/schema.ts:479:28 StringLiteral: `source: ingestion_source("source").default("api").notNull(),` → replacement `""`
- 6 packages/db/src/schema.ts:479:46 StringLiteral: `source: ingestion_source("source").default("api").notNull(),` → replacement `""`
- 7 packages/db/src/schema.ts:480:4 ArrowFunction: `}, (table) => ({
  naturalKey: unique("uq_activity_record_vendor_account_id_person_id_activity_date")
    .on(table.vendorAccountId, table.personId, table.activityDate),
}));` → replacement `() => undefined`
- 8 packages/db/src/schema.ts:480:16 ObjectLiteral: `}, (table) => ({
  naturalKey: unique("uq_activity_record_vendor_account_id_person_id_activity_date")
    .on(table.vendorAccountId, table.personId, table.activityDate),
}));` → replacement `{}`
- 9 packages/db/src/schema.ts:481:22 StringLiteral: `naturalKey: unique("uq_activity_record_vendor_account_id_person_id_activity_date")` → replacement `""`
- 10 packages/db/src/schema.ts:526:35 StringLiteral: `ingestionMode: ingestion_source("ingestion_mode").default("manual").notNull(),` → replacement `""`
- 11 packages/db/src/schema.ts:526:61 StringLiteral: `ingestionMode: ingestion_source("ingestion_mode").default("manual").notNull(),` → replacement `""`

JSON report: `reports/mutation/schema-static-481df809eb04-49452-1791252034360-479bfd4de0f9f.json`. Logs: task-1-corrected-preflight.log, task-1-preview-schema-static-481df809eb04.log. Launcher execution metadata: task-1-preview-execution.json.

## Schema repair and remaining initial previews (round 2)

Candidate repair: fa59f97d4a6d0a47ec9eec35421edbf00d56c193. Start 2026-10-06T02:06:59.627Z; end 2026-10-06T02:17:06.657Z. Successful execution round with score failures collected across independent shards; fixture cleaned up. Preflight exit 0; schema re-preview justified by changed schema.test.ts oracle, contracts/ingestion initial previews. No unrelated shards or cache clearing.

Exact child command prefix: `rtk proxy pnpm`; child env `MUTATION_BASE=ed9ff60 MUTATION_WORK_ID=US-070` plus migrated in-memory default and US070 owner/app URL pairs, DB_DRIVER=pg. Preflight `mutation:preflight`; each preview `MUTATION_SHARD=<id> pnpm test:mutation`. Preview execution total 10.067 minutes.

### schema-static-481df809eb04

Sources: packages/db/src/schema.ts. Exit 0; 0.254 minutes. Score 91.67%; counts {'Killed': 11, 'Survived': 1}. JSON: `reports/mutation/schema-static-481df809eb04-65896-1791252422897-b0bad50397f1f.json`. Log: `task-1-preview-schema-static-481df809eb04-round2.log`.

- 5 packages/db/src/schema.ts:479:28 Survived StringLiteral: `source: ingestion_source("source").default("api").notNull(),` → `""`

### vitest-79bcc0c40c4f

Sources: packages/connectors/src/contracts.ts. Exit 1; 3.481 minutes. Score 0.00%; counts {'NoCoverage': 49, 'Survived': 20}. JSON: `reports/mutation/vitest-79bcc0c40c4f-66320-1791252438185-1996f2af1bd1a8.json`. Log: `task-1-preview-vitest-79bcc0c40c4f-round2.log`.

- 20 packages/connectors/src/contracts.ts:200:70 NoCoverage BlockStatement: `export function normalizeActivityCounters(value: unknown): JsonValue {
  function normalize(input: unknown, shape: CounterShape, path: string): JsonValue {
    if (input === null || typeof input !== "object" || Array.isArray(input)
      || ![Object.prototype, null].includes(Object.getPrototypeOf(input))) {
      throw new Error(`Invalid activity metric object: ${path}`);
    }
    const object = input as Record<string, unknown>;
    const result: Record<string, JsonValue> = {};
    for (const [key, nested] of Object.entries(shape)) {
      if (!Object.hasOwn(object, key)) continue;
      const metric = object[key];
      if (metric === null) result[key] = null;
      else if (nested === true) {
        if (typeof metric !== "number" || !Number.isFinite(metric)
          || !Number.isInteger(metric) || metric < 0) {
          throw new Error(`Invalid activity count: ${path}.${key}`);
        }
        result[key] = metric;
      } else result[key] = normalize(metric, nested, `${path}.${key}`);
    }
    return result;
  }
  return normalize(value, activityCounterShape, "counters");
}` → `{}`
- 21 packages/connectors/src/contracts.ts:201:84 NoCoverage BlockStatement: `function normalize(input: unknown, shape: CounterShape, path: string): JsonValue {
    if (input === null || typeof input !== "object" || Array.isArray(input)
      || ![Object.prototype, null].includes(Object.getPrototypeOf(input))) {
      throw new Error(`Invalid activity metric object: ${path}`);
    }
    const object = input as Record<string, unknown>;
    const result: Record<string, JsonValue> = {};
    for (const [key, nested] of Object.entries(shape)) {
      if (!Object.hasOwn(object, key)) continue;
      const metric = object[key];
      if (metric === null) result[key] = null;
      else if (nested === true) {
        if (typeof metric !== "number" || !Number.isFinite(metric)
          || !Number.isInteger(metric) || metric < 0) {
          throw new Error(`Invalid activity count: ${path}.${key}`);
        }
        result[key] = metric;
      } else result[key] = normalize(metric, nested, `${path}.${key}`);
    }
    return result;
  }` → `{}`
- 22 packages/connectors/src/contracts.ts:202:9 NoCoverage ConditionalExpression: `if (input === null || typeof input !== "object" || Array.isArray(input)
      || ![Object.prototype, null].includes(Object.getPrototypeOf(input))) {` → `true`
- 23 packages/connectors/src/contracts.ts:202:9 NoCoverage ConditionalExpression: `if (input === null || typeof input !== "object" || Array.isArray(input)
      || ![Object.prototype, null].includes(Object.getPrototypeOf(input))) {` → `false`
- 24 packages/connectors/src/contracts.ts:202:9 NoCoverage LogicalOperator: `if (input === null || typeof input !== "object" || Array.isArray(input)
      || ![Object.prototype, null].includes(Object.getPrototypeOf(input))) {` → `(input === null || typeof input !== "object" || Array.isArray(input)) && ![Object.prototype, null].includes(Object.getPrototypeOf(input))`
- 25 packages/connectors/src/contracts.ts:202:9 NoCoverage ConditionalExpression: `if (input === null || typeof input !== "object" || Array.isArray(input)` → `false`
- 26 packages/connectors/src/contracts.ts:202:9 NoCoverage LogicalOperator: `if (input === null || typeof input !== "object" || Array.isArray(input)` → `(input === null || typeof input !== "object") && Array.isArray(input)`
- 27 packages/connectors/src/contracts.ts:202:9 NoCoverage ConditionalExpression: `if (input === null || typeof input !== "object" || Array.isArray(input)` → `false`
- 28 packages/connectors/src/contracts.ts:202:9 NoCoverage LogicalOperator: `if (input === null || typeof input !== "object" || Array.isArray(input)` → `input === null && typeof input !== "object"`
- 29 packages/connectors/src/contracts.ts:202:9 NoCoverage ConditionalExpression: `if (input === null || typeof input !== "object" || Array.isArray(input)` → `false`
- 30 packages/connectors/src/contracts.ts:202:9 NoCoverage EqualityOperator: `if (input === null || typeof input !== "object" || Array.isArray(input)` → `input !== null`
- 31 packages/connectors/src/contracts.ts:202:27 NoCoverage ConditionalExpression: `if (input === null || typeof input !== "object" || Array.isArray(input)` → `false`
- 32 packages/connectors/src/contracts.ts:202:27 NoCoverage EqualityOperator: `if (input === null || typeof input !== "object" || Array.isArray(input)` → `typeof input === "object"`
- 33 packages/connectors/src/contracts.ts:202:44 NoCoverage StringLiteral: `if (input === null || typeof input !== "object" || Array.isArray(input)` → `""`
- 34 packages/connectors/src/contracts.ts:203:10 NoCoverage BooleanLiteral: `|| ![Object.prototype, null].includes(Object.getPrototypeOf(input))) {` → `[Object.prototype, null].includes(Object.getPrototypeOf(input))`
- 35 packages/connectors/src/contracts.ts:203:11 NoCoverage ArrayDeclaration: `|| ![Object.prototype, null].includes(Object.getPrototypeOf(input))) {` → `[]`
- 36 packages/connectors/src/contracts.ts:203:76 NoCoverage BlockStatement: `|| ![Object.prototype, null].includes(Object.getPrototypeOf(input))) {
      throw new Error(`Invalid activity metric object: ${path}`);
    }` → `{}`
- 37 packages/connectors/src/contracts.ts:204:23 NoCoverage StringLiteral: `throw new Error(`Invalid activity metric object: ${path}`);` → ````
- 38 packages/connectors/src/contracts.ts:208:56 NoCoverage BlockStatement: `for (const [key, nested] of Object.entries(shape)) {
      if (!Object.hasOwn(object, key)) continue;
      const metric = object[key];
      if (metric === null) result[key] = null;
      else if (nested === true) {
        if (typeof metric !== "number" || !Number.isFinite(metric)
          || !Number.isInteger(metric) || metric < 0) {
          throw new Error(`Invalid activity count: ${path}.${key}`);
        }
        result[key] = metric;
      } else result[key] = normalize(metric, nested, `${path}.${key}`);
    }` → `{}`
- 39 packages/connectors/src/contracts.ts:209:11 NoCoverage BooleanLiteral: `if (!Object.hasOwn(object, key)) continue;` → `Object.hasOwn(object, key)`
- 40 packages/connectors/src/contracts.ts:209:11 NoCoverage ConditionalExpression: `if (!Object.hasOwn(object, key)) continue;` → `true`
- 41 packages/connectors/src/contracts.ts:209:11 NoCoverage ConditionalExpression: `if (!Object.hasOwn(object, key)) continue;` → `false`
- 42 packages/connectors/src/contracts.ts:211:11 NoCoverage ConditionalExpression: `if (metric === null) result[key] = null;` → `true`
- 43 packages/connectors/src/contracts.ts:211:11 NoCoverage ConditionalExpression: `if (metric === null) result[key] = null;` → `false`
- 44 packages/connectors/src/contracts.ts:211:11 NoCoverage EqualityOperator: `if (metric === null) result[key] = null;` → `metric !== null`
- 45 packages/connectors/src/contracts.ts:212:16 NoCoverage ConditionalExpression: `else if (nested === true) {` → `true`
- 46 packages/connectors/src/contracts.ts:212:16 NoCoverage ConditionalExpression: `else if (nested === true) {` → `false`
- 47 packages/connectors/src/contracts.ts:212:16 NoCoverage EqualityOperator: `else if (nested === true) {` → `nested !== true`
- 48 packages/connectors/src/contracts.ts:212:27 NoCoverage BooleanLiteral: `else if (nested === true) {` → `false`
- 49 packages/connectors/src/contracts.ts:212:33 NoCoverage BlockStatement: `else if (nested === true) {
        if (typeof metric !== "number" || !Number.isFinite(metric)
          || !Number.isInteger(metric) || metric < 0) {
          throw new Error(`Invalid activity count: ${path}.${key}`);
        }
        result[key] = metric;
      } else result[key] = normalize(metric, nested, `${path}.${key}`);` → `{}`
- 50 packages/connectors/src/contracts.ts:213:13 NoCoverage ConditionalExpression: `if (typeof metric !== "number" || !Number.isFinite(metric)
          || !Number.isInteger(metric) || metric < 0) {` → `true`
- 51 packages/connectors/src/contracts.ts:213:13 NoCoverage ConditionalExpression: `if (typeof metric !== "number" || !Number.isFinite(metric)
          || !Number.isInteger(metric) || metric < 0) {` → `false`
- 52 packages/connectors/src/contracts.ts:213:13 NoCoverage LogicalOperator: `if (typeof metric !== "number" || !Number.isFinite(metric)
          || !Number.isInteger(metric) || metric < 0) {` → `(typeof metric !== "number" || !Number.isFinite(metric) || !Number.isInteger(metric)) && metric < 0`
- 53 packages/connectors/src/contracts.ts:213:13 NoCoverage ConditionalExpression: `if (typeof metric !== "number" || !Number.isFinite(metric)
          || !Number.isInteger(metric) || metric < 0) {` → `false`
- 54 packages/connectors/src/contracts.ts:213:13 NoCoverage LogicalOperator: `if (typeof metric !== "number" || !Number.isFinite(metric)
          || !Number.isInteger(metric) || metric < 0) {` → `(typeof metric !== "number" || !Number.isFinite(metric)) && !Number.isInteger(metric)`
- 55 packages/connectors/src/contracts.ts:213:13 NoCoverage ConditionalExpression: `if (typeof metric !== "number" || !Number.isFinite(metric)` → `false`
- 56 packages/connectors/src/contracts.ts:213:13 NoCoverage LogicalOperator: `if (typeof metric !== "number" || !Number.isFinite(metric)` → `typeof metric !== "number" && !Number.isFinite(metric)`
- 57 packages/connectors/src/contracts.ts:213:13 NoCoverage ConditionalExpression: `if (typeof metric !== "number" || !Number.isFinite(metric)` → `false`
- 58 packages/connectors/src/contracts.ts:213:13 NoCoverage EqualityOperator: `if (typeof metric !== "number" || !Number.isFinite(metric)` → `typeof metric === "number"`
- 59 packages/connectors/src/contracts.ts:213:31 NoCoverage StringLiteral: `if (typeof metric !== "number" || !Number.isFinite(metric)` → `""`
- 60 packages/connectors/src/contracts.ts:213:43 NoCoverage BooleanLiteral: `if (typeof metric !== "number" || !Number.isFinite(metric)` → `Number.isFinite(metric)`
- 61 packages/connectors/src/contracts.ts:214:14 NoCoverage BooleanLiteral: `|| !Number.isInteger(metric) || metric < 0) {` → `Number.isInteger(metric)`
- 62 packages/connectors/src/contracts.ts:214:43 NoCoverage ConditionalExpression: `|| !Number.isInteger(metric) || metric < 0) {` → `false`
- 63 packages/connectors/src/contracts.ts:214:43 NoCoverage EqualityOperator: `|| !Number.isInteger(metric) || metric < 0) {` → `metric <= 0`
- 64 packages/connectors/src/contracts.ts:214:43 NoCoverage EqualityOperator: `|| !Number.isInteger(metric) || metric < 0) {` → `metric >= 0`
- 65 packages/connectors/src/contracts.ts:214:55 NoCoverage BlockStatement: `|| !Number.isInteger(metric) || metric < 0) {
          throw new Error(`Invalid activity count: ${path}.${key}`);
        }` → `{}`
- 66 packages/connectors/src/contracts.ts:215:27 NoCoverage StringLiteral: `throw new Error(`Invalid activity count: ${path}.${key}`);` → ````
- 67 packages/connectors/src/contracts.ts:218:54 NoCoverage StringLiteral: `} else result[key] = normalize(metric, nested, `${path}.${key}`);` → ````
- 68 packages/connectors/src/contracts.ts:222:49 NoCoverage StringLiteral: `return normalize(value, activityCounterShape, "counters");` → `""`
- 0 packages/connectors/src/contracts.ts:179:22 Survived StringLiteral: `const chatCounters = "connectors_used_count distinct_artifacts_created_count distinct_connectors_used_count distinct_conversation_count distinct_files_uploaded_count distinct_projects_created_count distinct_projects_used_count distinct_shared_artifacts_viewed_count distinct_skills_used_count message_count shared_conversations_viewed_count thinking_message_count";` → `""`
- 1 packages/connectors/src/contracts.ts:180:24 Survived StringLiteral: `const coworkCounters = "action_count artifacts_created_count connectors_used_count dispatch_turn_count distinct_connectors_used_count distinct_session_count distinct_skills_used_count message_count skills_used_count distinct_plugins_used_count edit_tool_count file_edit_count multi_edit_tool_count notebook_edit_tool_count plugins_used_count sessions_with_file_edits_count write_tool_count";` → `""`
- 2 packages/connectors/src/contracts.ts:181:50 Survived BlockStatement: `function countShape(names: string): CounterShape {
  return Object.fromEntries(names.split(" ").map(name => [name, true]));
}` → `{}`
- 3 packages/connectors/src/contracts.ts:182:41 Survived StringLiteral: `return Object.fromEntries(names.split(" ").map(name => [name, true]));` → `""`
- 4 packages/connectors/src/contracts.ts:182:50 Survived ArrowFunction: `return Object.fromEntries(names.split(" ").map(name => [name, true]));` → `() => undefined`
- 5 packages/connectors/src/contracts.ts:182:58 Survived ArrayDeclaration: `return Object.fromEntries(names.split(" ").map(name => [name, true]));` → `[]`
- 6 packages/connectors/src/contracts.ts:182:65 Survived BooleanLiteral: `return Object.fromEntries(names.split(" ").map(name => [name, true]));` → `false`
- 7 packages/connectors/src/contracts.ts:184:44 Survived ObjectLiteral: `const activityCounterShape: CounterShape = {
  chat_metrics: countShape(chatCounters),
  claude_code_metrics: {
    core_metrics: {
      ...countShape("artifacts_created_count commit_count distinct_session_count pull_request_count"),
      lines_of_code: countShape("added_count removed_count"),
    },
    tool_actions: Object.fromEntries(
      ["edit_tool", "multi_edit_tool", "notebook_edit_tool", "write_tool"]
        .map(name => [name, countShape("accepted_count rejected_count")]),
    ),
  },
  cowork_metrics: countShape(coworkCounters),
};` → `{}`
- 8 packages/connectors/src/contracts.ts:186:24 Survived ObjectLiteral: `claude_code_metrics: {
    core_metrics: {
      ...countShape("artifacts_created_count commit_count distinct_session_count pull_request_count"),
      lines_of_code: countShape("added_count removed_count"),
    },
    tool_actions: Object.fromEntries(
      ["edit_tool", "multi_edit_tool", "notebook_edit_tool", "write_tool"]
        .map(name => [name, countShape("accepted_count rejected_count")]),
    ),
  },` → `{}`
- 9 packages/connectors/src/contracts.ts:187:19 Survived ObjectLiteral: `core_metrics: {
      ...countShape("artifacts_created_count commit_count distinct_session_count pull_request_count"),
      lines_of_code: countShape("added_count removed_count"),
    },` → `{}`
- 10 packages/connectors/src/contracts.ts:188:21 Survived StringLiteral: `...countShape("artifacts_created_count commit_count distinct_session_count pull_request_count"),` → `""`
- 11 packages/connectors/src/contracts.ts:189:33 Survived StringLiteral: `lines_of_code: countShape("added_count removed_count"),` → `""`
- 12 packages/connectors/src/contracts.ts:192:7 Survived ArrayDeclaration: `["edit_tool", "multi_edit_tool", "notebook_edit_tool", "write_tool"]` → `[]`
- 13 packages/connectors/src/contracts.ts:192:8 Survived StringLiteral: `["edit_tool", "multi_edit_tool", "notebook_edit_tool", "write_tool"]` → `""`
- 14 packages/connectors/src/contracts.ts:192:21 Survived StringLiteral: `["edit_tool", "multi_edit_tool", "notebook_edit_tool", "write_tool"]` → `""`
- 15 packages/connectors/src/contracts.ts:192:40 Survived StringLiteral: `["edit_tool", "multi_edit_tool", "notebook_edit_tool", "write_tool"]` → `""`
- 16 packages/connectors/src/contracts.ts:192:62 Survived StringLiteral: `["edit_tool", "multi_edit_tool", "notebook_edit_tool", "write_tool"]` → `""`
- 17 packages/connectors/src/contracts.ts:193:14 Survived ArrowFunction: `.map(name => [name, countShape("accepted_count rejected_count")]),` → `() => undefined`
- 18 packages/connectors/src/contracts.ts:193:22 Survived ArrayDeclaration: `.map(name => [name, countShape("accepted_count rejected_count")]),` → `[]`
- 19 packages/connectors/src/contracts.ts:193:40 Survived StringLiteral: `.map(name => [name, countShape("accepted_count rejected_count")]),` → `""`

### vitest-7e4dfff580cb

Sources: packages/db/src/analytics-ingestion.ts. Exit 1; 6.331 minutes. Score 71.29%; counts {'NoCoverage': 13, 'Survived': 78, 'Killed': 226}. JSON: `reports/mutation/vitest-7e4dfff580cb-79448-1791252647224-95d995ccc2515.json`. Log: `task-1-preview-vitest-7e4dfff580cb-round2.log`.

- 38 packages/db/src/analytics-ingestion.ts:37:88 NoCoverage StringLiteral: `if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) throw new Error("ACTIVITY_INVALID_DATE");` → `""`
- 56 packages/db/src/analytics-ingestion.ts:43:50 NoCoverage StringLiteral: `if (typeof value !== "string") throw new Error("ACTIVITY_INVALID_EMAIL");` → `""`
- 85 packages/db/src/analytics-ingestion.ts:52:36 NoCoverage StringLiteral: `if (Array.isArray(value)) return `[${value.map(canonical).join(",")}]`;` → ````
- 86 packages/db/src/analytics-ingestion.ts:52:66 NoCoverage StringLiteral: `if (Array.isArray(value)) return `[${value.map(canonical).join(",")}]`;` → `""`
- 97 packages/db/src/analytics-ingestion.ts:58:48 NoCoverage StringLiteral: `if (!Array.isArray(records)) throw new Error("ACTIVITY_INVALID_RECORDS");` → `""`
- 107 packages/db/src/analytics-ingestion.ts:63:62 NoCoverage StringLiteral: `if (!input || typeof input !== "object") throw new Error("ACTIVITY_INVALID_RECORD");` → `""`
- 135 packages/db/src/analytics-ingestion.ts:70:119 NoCoverage StringLiteral: `if (providerIds.has(record.providerUserId) && providerIds.get(record.providerUserId) !== email) throw new Error("ACTIVITY_IDENTITY_CONFLICT");` → `""`
- 172 packages/db/src/analytics-ingestion.ts:91:43 NoCoverage StringLiteral: `if (matches.length > 1) throw new Error("ACTIVITY_AMBIGUOUS_IDENTITY");` → `""`
- 190 packages/db/src/analytics-ingestion.ts:108:50 NoCoverage StringLiteral: `if (scope !== undefined) throw new Error("ACTIVITY_AMBIGUOUS_IDENTITY");` → `""`
- 234 packages/db/src/analytics-ingestion.ts:135:75 NoCoverage StringLiteral: `if (!account || account.identityMatching !== "email") throw new Error("ACTIVITY_ACCOUNT_UNSUPPORTED");` → `""`
- 240 packages/db/src/analytics-ingestion.ts:137:35 NoCoverage StringLiteral: `if (!company) throw new Error("ACTIVITY_COMPANY_NOT_FOUND");` → `""`
- 246 packages/db/src/analytics-ingestion.ts:140:163 NoCoverage StringLiteral: `.where(and(eq(schema.userAccount.id, actorId), actorId === SYSTEM_USER_ID ? eq(schema.userAccount.email, SYSTEM_USER_EMAIL) : eq(schema.userAccount.status, "active"))).for("share");` → `""`
- 251 packages/db/src/analytics-ingestion.ts:141:33 NoCoverage StringLiteral: `if (!actor) throw new Error("ACTIVITY_ACTOR_NOT_FOUND");` → `""`
- 0 packages/db/src/analytics-ingestion.ts:31:64 Survived BlockStatement: `function validateUuid(value: unknown): asserts value is string {
  if (typeof value !== "string" || !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(value)) {
    throw new Error("ACTIVITY_INVALID_UUID");
  }
}` → `{}`
- 2 packages/db/src/analytics-ingestion.ts:32:7 Survived ConditionalExpression: `if (typeof value !== "string" || !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(value)) {` → `false`
- 3 packages/db/src/analytics-ingestion.ts:32:7 Survived LogicalOperator: `if (typeof value !== "string" || !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(value)) {` → `typeof value !== "string" && !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(value)`
- 4 packages/db/src/analytics-ingestion.ts:32:7 Survived ConditionalExpression: `if (typeof value !== "string" || !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(value)) {` → `false`
- 8 packages/db/src/analytics-ingestion.ts:32:37 Survived Regex: `if (typeof value !== "string" || !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(value)) {` → `/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i`
- 9 packages/db/src/analytics-ingestion.ts:32:37 Survived Regex: `if (typeof value !== "string" || !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(value)) {` → `/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i`
- 20 packages/db/src/analytics-ingestion.ts:32:116 Survived BlockStatement: `if (typeof value !== "string" || !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(value)) {
    throw new Error("ACTIVITY_INVALID_UUID");
  }` → `{}`
- 21 packages/db/src/analytics-ingestion.ts:33:21 Survived StringLiteral: `throw new Error("ACTIVITY_INVALID_UUID");` → `""`
- 22 packages/db/src/analytics-ingestion.ts:36:64 Survived BlockStatement: `function validateDate(value: unknown): asserts value is string {
  if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) throw new Error("ACTIVITY_INVALID_DATE");
  const date = new Date(`${value}T00:00:00Z`);
  if (!Number.isFinite(date.getTime()) || date.toISOString().slice(0, 10) !== value) throw new Error("ACTIVITY_INVALID_DATE");
}` → `{}`
- 24 packages/db/src/analytics-ingestion.ts:37:7 Survived ConditionalExpression: `if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) throw new Error("ACTIVITY_INVALID_DATE");` → `false`
- 25 packages/db/src/analytics-ingestion.ts:37:7 Survived LogicalOperator: `if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) throw new Error("ACTIVITY_INVALID_DATE");` → `typeof value !== "string" && !/^\d{4}-\d{2}-\d{2}$/.test(value)`
- 26 packages/db/src/analytics-ingestion.ts:37:7 Survived ConditionalExpression: `if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) throw new Error("ACTIVITY_INVALID_DATE");` → `false`
- 30 packages/db/src/analytics-ingestion.ts:37:37 Survived Regex: `if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) throw new Error("ACTIVITY_INVALID_DATE");` → `/\d{4}-\d{2}-\d{2}$/`
- 31 packages/db/src/analytics-ingestion.ts:37:37 Survived Regex: `if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) throw new Error("ACTIVITY_INVALID_DATE");` → `/^\d{4}-\d{2}-\d{2}/`
- 41 packages/db/src/analytics-ingestion.ts:39:7 Survived ConditionalExpression: `if (!Number.isFinite(date.getTime()) || date.toISOString().slice(0, 10) !== value) throw new Error("ACTIVITY_INVALID_DATE");` → `false`
- 42 packages/db/src/analytics-ingestion.ts:39:7 Survived LogicalOperator: `if (!Number.isFinite(date.getTime()) || date.toISOString().slice(0, 10) !== value) throw new Error("ACTIVITY_INVALID_DATE");` → `!Number.isFinite(date.getTime()) && date.toISOString().slice(0, 10) !== value`
- 44 packages/db/src/analytics-ingestion.ts:39:43 Survived ConditionalExpression: `if (!Number.isFinite(date.getTime()) || date.toISOString().slice(0, 10) !== value) throw new Error("ACTIVITY_INVALID_DATE");` → `false`
- 47 packages/db/src/analytics-ingestion.ts:39:102 Survived StringLiteral: `if (!Number.isFinite(date.getTime()) || date.toISOString().slice(0, 10) !== value) throw new Error("ACTIVITY_INVALID_DATE");` → `""`
- 53 packages/db/src/analytics-ingestion.ts:43:7 Survived ConditionalExpression: `if (typeof value !== "string") throw new Error("ACTIVITY_INVALID_EMAIL");` → `false`
- 61 packages/db/src/analytics-ingestion.ts:45:7 Survived ConditionalExpression: `if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new Error("ACTIVITY_INVALID_EMAIL");` → `false`
- 62 packages/db/src/analytics-ingestion.ts:45:8 Survived Regex: `if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new Error("ACTIVITY_INVALID_EMAIL");` → `/[^\s@]+@[^\s@]+\.[^\s@]+$/`
- 63 packages/db/src/analytics-ingestion.ts:45:8 Survived Regex: `if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new Error("ACTIVITY_INVALID_EMAIL");` → `/^[^\s@]+@[^\s@]+\.[^\s@]+/`
- 73 packages/db/src/analytics-ingestion.ts:45:66 Survived StringLiteral: `if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new Error("ACTIVITY_INVALID_EMAIL");` → `""`
- 75 packages/db/src/analytics-ingestion.ts:51:7 Survived ConditionalExpression: `if (value === null || typeof value !== "object") return JSON.stringify(value);` → `true`
- 78 packages/db/src/analytics-ingestion.ts:51:7 Survived ConditionalExpression: `if (value === null || typeof value !== "object") return JSON.stringify(value);` → `false`
- 79 packages/db/src/analytics-ingestion.ts:51:7 Survived EqualityOperator: `if (value === null || typeof value !== "object") return JSON.stringify(value);` → `value !== null`
- 81 packages/db/src/analytics-ingestion.ts:51:25 Survived EqualityOperator: `if (value === null || typeof value !== "object") return JSON.stringify(value);` → `typeof value === "object"`
- 82 packages/db/src/analytics-ingestion.ts:51:42 Survived StringLiteral: `if (value === null || typeof value !== "object") return JSON.stringify(value);` → `""`
- 84 packages/db/src/analytics-ingestion.ts:52:7 Survived ConditionalExpression: `if (Array.isArray(value)) return `[${value.map(canonical).join(",")}]`;` → `false`
- 88 packages/db/src/analytics-ingestion.ts:53:14 Survived MethodExpression: `return `{${Object.entries(value).sort(([a], [b]) => a.localeCompare(b))` → `Object.entries(value)`
- 89 packages/db/src/analytics-ingestion.ts:53:41 Survived ArrowFunction: `return `{${Object.entries(value).sort(([a], [b]) => a.localeCompare(b))` → `() => undefined`
- 92 packages/db/src/analytics-ingestion.ts:54:77 Survived StringLiteral: `.map(([key, item]) => `${JSON.stringify(key)}:${canonical(item)}`).join(",")}}`;` → `""`
- 96 packages/db/src/analytics-ingestion.ts:58:7 Survived ConditionalExpression: `if (!Array.isArray(records)) throw new Error("ACTIVITY_INVALID_RECORDS");` → `false`
- 101 packages/db/src/analytics-ingestion.ts:63:9 Survived ConditionalExpression: `if (!input || typeof input !== "object") throw new Error("ACTIVITY_INVALID_RECORD");` → `false`
- 102 packages/db/src/analytics-ingestion.ts:63:9 Survived LogicalOperator: `if (!input || typeof input !== "object") throw new Error("ACTIVITY_INVALID_RECORD");` → `!input && typeof input !== "object"`
- 104 packages/db/src/analytics-ingestion.ts:63:19 Survived ConditionalExpression: `if (!input || typeof input !== "object") throw new Error("ACTIVITY_INVALID_RECORD");` → `false`
- 115 packages/db/src/analytics-ingestion.ts:65:76 Survived StringLiteral: `if (date !== undefined && input.activityDate !== date) throw new Error("ACTIVITY_DATE_MISMATCH");` → `""`
- 117 packages/db/src/analytics-ingestion.ts:67:9 Survived ConditionalExpression: `if (input.providerUserId !== null && typeof input.providerUserId !== "string") throw new Error("ACTIVITY_INVALID_PROVIDER_ID");` → `false`
- 119 packages/db/src/analytics-ingestion.ts:67:9 Survived ConditionalExpression: `if (input.providerUserId !== null && typeof input.providerUserId !== "string") throw new Error("ACTIVITY_INVALID_PROVIDER_ID");` → `true`
- 120 packages/db/src/analytics-ingestion.ts:67:9 Survived EqualityOperator: `if (input.providerUserId !== null && typeof input.providerUserId !== "string") throw new Error("ACTIVITY_INVALID_PROVIDER_ID");` → `input.providerUserId === null`
- 124 packages/db/src/analytics-ingestion.ts:67:100 Survived StringLiteral: `if (input.providerUserId !== null && typeof input.providerUserId !== "string") throw new Error("ACTIVITY_INVALID_PROVIDER_ID");` → `""`
- 126 packages/db/src/analytics-ingestion.ts:69:9 Survived ConditionalExpression: `if (record.providerUserId !== null) {` → `true`
- 127 packages/db/src/analytics-ingestion.ts:69:9 Survived ConditionalExpression: `if (record.providerUserId !== null) {` → `false`
- 128 packages/db/src/analytics-ingestion.ts:69:9 Survived EqualityOperator: `if (record.providerUserId !== null) {` → `record.providerUserId === null`
- 129 packages/db/src/analytics-ingestion.ts:69:41 Survived BlockStatement: `if (record.providerUserId !== null) {
      if (providerIds.has(record.providerUserId) && providerIds.get(record.providerUserId) !== email) throw new Error("ACTIVITY_IDENTITY_CONFLICT");
      providerIds.set(record.providerUserId, email);
    }` → `{}`
- 131 packages/db/src/analytics-ingestion.ts:70:11 Survived ConditionalExpression: `if (providerIds.has(record.providerUserId) && providerIds.get(record.providerUserId) !== email) throw new Error("ACTIVITY_IDENTITY_CONFLICT");` → `false`
- 138 packages/db/src/analytics-ingestion.ts:73:32 Survived ConditionalExpression: `const identity = email ?? (record.providerUserId === null ? null : `provider:${record.providerUserId}`);` → `false`
- 140 packages/db/src/analytics-ingestion.ts:73:72 Survived StringLiteral: `const identity = email ?? (record.providerUserId === null ? null : `provider:${record.providerUserId}`);` → ````
- 142 packages/db/src/analytics-ingestion.ts:74:17 Survived ConditionalExpression: `const key = identity === null ? null : `${identity}:${record.activityDate}`;` → `false`
- 146 packages/db/src/analytics-ingestion.ts:75:22 Survived ConditionalExpression: `const previous = key === null ? undefined : emails.get(key);` → `false`
- 158 packages/db/src/analytics-ingestion.ts:77:155 Survived StringLiteral: `if (previous.record.providerUserId !== record.providerUserId || canonical(previous.record.counters) !== canonical(record.counters)) throw new Error("ACTIVITY_DUPLICATE_CONFLICT");` → `""`
- 160 packages/db/src/analytics-ingestion.ts:81:9 Survived ConditionalExpression: `if (key !== null) emails.set(key, indexed);` → `true`
- 163 packages/db/src/analytics-ingestion.ts:87:88 Survived BooleanLiteral: `async function matchPerson(database: Matcher, companyId: string, email: string, lock = false) {` → `true`
- 169 packages/db/src/analytics-ingestion.ts:91:7 Survived ConditionalExpression: `if (matches.length > 1) throw new Error("ACTIVITY_AMBIGUOUS_IDENTITY");` → `false`
- 188 packages/db/src/analytics-ingestion.ts:108:13 Survived ConditionalExpression: `if (scope !== undefined) throw new Error("ACTIVITY_AMBIGUOUS_IDENTITY");` → `false`
- 204 packages/db/src/analytics-ingestion.ts:124:7 Survived ConditionalExpression: `if (batch.actorUserAccountId !== null) validateUuid(batch.actorUserAccountId);` → `false`
- 208 packages/db/src/analytics-ingestion.ts:126:7 Survived ConditionalExpression: `if (!["api", "csv_import", "manual"].includes(batch.source)) throw new Error("ACTIVITY_INVALID_SOURCE");` → `false`
- 213 packages/db/src/analytics-ingestion.ts:126:80 Survived StringLiteral: `if (!["api", "csv_import", "manual"].includes(batch.source)) throw new Error("ACTIVITY_INVALID_SOURCE");` → `""`
- 215 packages/db/src/analytics-ingestion.ts:127:7 Survived ConditionalExpression: `if (!(batch.syncedAt instanceof Date) || !Number.isFinite(batch.syncedAt.getTime())) throw new Error("ACTIVITY_INVALID_SYNC_TIME");` → `false`
- 216 packages/db/src/analytics-ingestion.ts:127:7 Survived LogicalOperator: `if (!(batch.syncedAt instanceof Date) || !Number.isFinite(batch.syncedAt.getTime())) throw new Error("ACTIVITY_INVALID_SYNC_TIME");` → `!(batch.syncedAt instanceof Date) && !Number.isFinite(batch.syncedAt.getTime())`
- 219 packages/db/src/analytics-ingestion.ts:127:104 Survived StringLiteral: `if (!(batch.syncedAt instanceof Date) || !Number.isFinite(batch.syncedAt.getTime())) throw new Error("ACTIVITY_INVALID_SYNC_TIME");` → `""`
- 225 packages/db/src/analytics-ingestion.ts:134:21 Survived ObjectLiteral: `.for("share", { of: [schema.vendorAccount, schema.vendor] });` → `{}`
- 228 packages/db/src/analytics-ingestion.ts:135:9 Survived ConditionalExpression: `if (!account || account.identityMatching !== "email") throw new Error("ACTIVITY_ACCOUNT_UNSUPPORTED");` → `false`
- 229 packages/db/src/analytics-ingestion.ts:135:9 Survived LogicalOperator: `if (!account || account.identityMatching !== "email") throw new Error("ACTIVITY_ACCOUNT_UNSUPPORTED");` → `!account && account.identityMatching !== "email"`
- 231 packages/db/src/analytics-ingestion.ts:135:21 Survived ConditionalExpression: `if (!account || account.identityMatching !== "email") throw new Error("ACTIVITY_ACCOUNT_UNSUPPORTED");` → `false`
- 235 packages/db/src/analytics-ingestion.ts:136:39 Survived ObjectLiteral: `const [company] = await tx.select({ id: schema.company.id }).from(schema.company).where(eq(schema.company.id, batch.companyId)).for("share");` → `{}`
- 239 packages/db/src/analytics-ingestion.ts:137:9 Survived ConditionalExpression: `if (!company) throw new Error("ACTIVITY_COMPANY_NOT_FOUND");` → `false`
- 242 packages/db/src/analytics-ingestion.ts:139:37 Survived ObjectLiteral: `const [actor] = await tx.select({ id: schema.userAccount.id }).from(schema.userAccount)` → `{}`
- 243 packages/db/src/analytics-ingestion.ts:140:54 Survived ConditionalExpression: `.where(and(eq(schema.userAccount.id, actorId), actorId === SYSTEM_USER_ID ? eq(schema.userAccount.email, SYSTEM_USER_EMAIL) : eq(schema.userAccount.status, "active"))).for("share");` → `true`
- 250 packages/db/src/analytics-ingestion.ts:141:9 Survived ConditionalExpression: `if (!actor) throw new Error("ACTIVITY_ACTOR_NOT_FOUND");` → `false`
- 268 packages/db/src/analytics-ingestion.ts:148:75 Survived BooleanLiteral: `const holder = await matchPerson(tx, batch.companyId, record.email, true);` → `false`
- 295 packages/db/src/analytics-ingestion.ts:163:13 Survived ConditionalExpression: `if (!current || current.syncedAt.getTime() < batch.syncedAt.getTime()` → `false`
- 296 packages/db/src/analytics-ingestion.ts:163:13 Survived LogicalOperator: `if (!current || current.syncedAt.getTime() < batch.syncedAt.getTime()` → `!current && current.syncedAt.getTime() < batch.syncedAt.getTime()`
- 298 packages/db/src/analytics-ingestion.ts:163:25 Survived ConditionalExpression: `if (!current || current.syncedAt.getTime() < batch.syncedAt.getTime()` → `false`
- 306 packages/db/src/analytics-ingestion.ts:164:112 Survived StringLiteral: `|| (current.syncedAt.getTime() === batch.syncedAt.getTime() && !current.equivalent)) throw new Error("ACTIVITY_REPLAY_CONFLICT");` → `""`
- 310 packages/db/src/analytics-ingestion.ts:168:148 Survived StringLiteral: `for (const item of warnings) await tx.insert(schema.auditLog).values({ actorUserId: actorId, action: "analytics_activity_warning", entityType: "VendorAccount",` → `""`
- 311 packages/db/src/analytics-ingestion.ts:169:75 Survived ObjectLiteral: `entityId: batch.vendorAccountId, companyId: batch.companyId, after: { vendorAccountId: batch.vendorAccountId, activityDate: batch.activityDate, source: batch.source, ...item }, occurredAt: batch.syncedAt });` → `{}`
- 314 packages/db/src/analytics-ingestion.ts:170:116 Survived StringLiteral: `await tx.insert(schema.auditLog).values({ actorUserId: actorId, action: "analytics_activity_sync", entityType: "VendorAccount", entityId: batch.vendorAccountId,` → `""`

## Test-only contracts/ingestion repair (round 3)

Repair candidate b13578cd0d42979b3c2e94439bdcc46264827b18. Start 2026-10-06T02:34:11.276Z; end 2026-10-06T02:43:13.767Z. Preflight exit 0. Only contracts/ingestion source-mapped shards selected from regenerated manifest; schema not repeated and retains 91.67%. Fixture cleaned up. Preview rounds total 3; this round preview minutes 8.986; cumulative preview minutes across executed rounds retained in execution metadata.

Exact child commands: `rtk proxy pnpm mutation:preflight`, then `rtk proxy pnpm test:mutation` with `MUTATION_BASE=ed9ff60 MUTATION_WORK_ID=US-070 MUTATION_SHARD=<id>` and in-memory migrated owner/app URL pairs. No cache clear or test_report.

### vitest-7e4dfff580cb

Sources: packages/db/src/analytics-ingestion.ts. Selected tests: packages/db/src/analytics-ingestion.integration.test.ts. Exit 0; 5.959 minutes. Score 92.43%; counts {'NoCoverage': 2, 'Killed': 293, 'Survived': 22}. JSON: `reports/mutation/vitest-7e4dfff580cb-37004-1791254054884-9aebed5135fe7.json`. Log: `task-1-preview-vitest-7e4dfff580cb-round3.log`.

- 85 packages/db/src/analytics-ingestion.ts:52:36 NoCoverage StringLiteral: `if (Array.isArray(value)) return `[${value.map(canonical).join(",")}]`;` → ````
- 86 packages/db/src/analytics-ingestion.ts:52:66 NoCoverage StringLiteral: `if (Array.isArray(value)) return `[${value.map(canonical).join(",")}]`;` → `""`
- 24 packages/db/src/analytics-ingestion.ts:37:7 Survived ConditionalExpression: `if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) throw new Error("ACTIVITY_INVALID_DATE");` → `false`
- 25 packages/db/src/analytics-ingestion.ts:37:7 Survived LogicalOperator: `if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) throw new Error("ACTIVITY_INVALID_DATE");` → `typeof value !== "string" && !/^\d{4}-\d{2}-\d{2}$/.test(value)`
- 26 packages/db/src/analytics-ingestion.ts:37:7 Survived ConditionalExpression: `if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) throw new Error("ACTIVITY_INVALID_DATE");` → `false`
- 30 packages/db/src/analytics-ingestion.ts:37:37 Survived Regex: `if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) throw new Error("ACTIVITY_INVALID_DATE");` → `/\d{4}-\d{2}-\d{2}$/`
- 31 packages/db/src/analytics-ingestion.ts:37:37 Survived Regex: `if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) throw new Error("ACTIVITY_INVALID_DATE");` → `/^\d{4}-\d{2}-\d{2}/`
- 75 packages/db/src/analytics-ingestion.ts:51:7 Survived ConditionalExpression: `if (value === null || typeof value !== "object") return JSON.stringify(value);` → `true`
- 79 packages/db/src/analytics-ingestion.ts:51:7 Survived EqualityOperator: `if (value === null || typeof value !== "object") return JSON.stringify(value);` → `value !== null`
- 81 packages/db/src/analytics-ingestion.ts:51:25 Survived EqualityOperator: `if (value === null || typeof value !== "object") return JSON.stringify(value);` → `typeof value === "object"`
- 82 packages/db/src/analytics-ingestion.ts:51:42 Survived StringLiteral: `if (value === null || typeof value !== "object") return JSON.stringify(value);` → `""`
- 84 packages/db/src/analytics-ingestion.ts:52:7 Survived ConditionalExpression: `if (Array.isArray(value)) return `[${value.map(canonical).join(",")}]`;` → `false`
- 88 packages/db/src/analytics-ingestion.ts:53:14 Survived MethodExpression: `return `{${Object.entries(value).sort(([a], [b]) => a.localeCompare(b))` → `Object.entries(value)`
- 89 packages/db/src/analytics-ingestion.ts:53:41 Survived ArrowFunction: `return `{${Object.entries(value).sort(([a], [b]) => a.localeCompare(b))` → `() => undefined`
- 92 packages/db/src/analytics-ingestion.ts:54:77 Survived StringLiteral: `.map(([key, item]) => `${JSON.stringify(key)}:${canonical(item)}`).join(",")}}`;` → `""`
- 146 packages/db/src/analytics-ingestion.ts:75:22 Survived ConditionalExpression: `const previous = key === null ? undefined : emails.get(key);` → `false`
- 160 packages/db/src/analytics-ingestion.ts:81:9 Survived ConditionalExpression: `if (key !== null) emails.set(key, indexed);` → `true`
- 163 packages/db/src/analytics-ingestion.ts:87:88 Survived BooleanLiteral: `async function matchPerson(database: Matcher, companyId: string, email: string, lock = false) {` → `true`
- 225 packages/db/src/analytics-ingestion.ts:134:21 Survived ObjectLiteral: `.for("share", { of: [schema.vendorAccount, schema.vendor] });` → `{}`
- 235 packages/db/src/analytics-ingestion.ts:136:39 Survived ObjectLiteral: `const [company] = await tx.select({ id: schema.company.id }).from(schema.company).where(eq(schema.company.id, batch.companyId)).for("share");` → `{}`
- 242 packages/db/src/analytics-ingestion.ts:139:37 Survived ObjectLiteral: `const [actor] = await tx.select({ id: schema.userAccount.id }).from(schema.userAccount)` → `{}`
- 295 packages/db/src/analytics-ingestion.ts:163:13 Survived ConditionalExpression: `if (!current || current.syncedAt.getTime() < batch.syncedAt.getTime()` → `false`
- 296 packages/db/src/analytics-ingestion.ts:163:13 Survived LogicalOperator: `if (!current || current.syncedAt.getTime() < batch.syncedAt.getTime()` → `!current && current.syncedAt.getTime() < batch.syncedAt.getTime()`
- 298 packages/db/src/analytics-ingestion.ts:163:25 Survived ConditionalExpression: `if (!current || current.syncedAt.getTime() < batch.syncedAt.getTime()` → `false`

### vitest-ae209c3d8c87

Sources: packages/connectors/src/contracts.ts. Selected tests: packages/connectors/src/contracts.test.ts, packages/connectors/src/dispatch.test.ts, packages/connectors/src/providers/anthropic/connector.test.ts. Exit 1; 3.027 minutes. Score 59.42%; counts {'Killed': 41, 'Survived': 28}. JSON: `reports/mutation/vitest-ae209c3d8c87-42973-1791254412647-d21b65085a3318.json`. Log: `task-1-preview-vitest-ae209c3d8c87-round3.log`.

- 29 packages/connectors/src/contracts.ts:202:9 Survived ConditionalExpression: `if (input === null || typeof input !== "object" || Array.isArray(input)` → `false`
- 37 packages/connectors/src/contracts.ts:204:23 Survived StringLiteral: `throw new Error(`Invalid activity metric object: ${path}`);` → ````
- 55 packages/connectors/src/contracts.ts:213:13 Survived ConditionalExpression: `if (typeof metric !== "number" || !Number.isFinite(metric)` → `false`
- 56 packages/connectors/src/contracts.ts:213:13 Survived LogicalOperator: `if (typeof metric !== "number" || !Number.isFinite(metric)` → `typeof metric !== "number" && !Number.isFinite(metric)`
- 57 packages/connectors/src/contracts.ts:213:13 Survived ConditionalExpression: `if (typeof metric !== "number" || !Number.isFinite(metric)` → `false`
- 66 packages/connectors/src/contracts.ts:215:27 Survived StringLiteral: `throw new Error(`Invalid activity count: ${path}.${key}`);` → ````
- 67 packages/connectors/src/contracts.ts:218:54 Survived StringLiteral: `} else result[key] = normalize(metric, nested, `${path}.${key}`);` → ````
- 68 packages/connectors/src/contracts.ts:222:49 Survived StringLiteral: `return normalize(value, activityCounterShape, "counters");` → `""`
- 0 packages/connectors/src/contracts.ts:179:22 Survived StringLiteral: `const chatCounters = "connectors_used_count distinct_artifacts_created_count distinct_connectors_used_count distinct_conversation_count distinct_files_uploaded_count distinct_projects_created_count distinct_projects_used_count distinct_shared_artifacts_viewed_count distinct_skills_used_count message_count shared_conversations_viewed_count thinking_message_count";` → `""`
- 1 packages/connectors/src/contracts.ts:180:24 Survived StringLiteral: `const coworkCounters = "action_count artifacts_created_count connectors_used_count dispatch_turn_count distinct_connectors_used_count distinct_session_count distinct_skills_used_count message_count skills_used_count distinct_plugins_used_count edit_tool_count file_edit_count multi_edit_tool_count notebook_edit_tool_count plugins_used_count sessions_with_file_edits_count write_tool_count";` → `""`
- 2 packages/connectors/src/contracts.ts:181:50 Survived BlockStatement: `function countShape(names: string): CounterShape {
  return Object.fromEntries(names.split(" ").map(name => [name, true]));
}` → `{}`
- 3 packages/connectors/src/contracts.ts:182:41 Survived StringLiteral: `return Object.fromEntries(names.split(" ").map(name => [name, true]));` → `""`
- 4 packages/connectors/src/contracts.ts:182:50 Survived ArrowFunction: `return Object.fromEntries(names.split(" ").map(name => [name, true]));` → `() => undefined`
- 5 packages/connectors/src/contracts.ts:182:58 Survived ArrayDeclaration: `return Object.fromEntries(names.split(" ").map(name => [name, true]));` → `[]`
- 6 packages/connectors/src/contracts.ts:182:65 Survived BooleanLiteral: `return Object.fromEntries(names.split(" ").map(name => [name, true]));` → `false`
- 7 packages/connectors/src/contracts.ts:184:44 Survived ObjectLiteral: `const activityCounterShape: CounterShape = {
  chat_metrics: countShape(chatCounters),
  claude_code_metrics: {
    core_metrics: {
      ...countShape("artifacts_created_count commit_count distinct_session_count pull_request_count"),
      lines_of_code: countShape("added_count removed_count"),
    },
    tool_actions: Object.fromEntries(
      ["edit_tool", "multi_edit_tool", "notebook_edit_tool", "write_tool"]
        .map(name => [name, countShape("accepted_count rejected_count")]),
    ),
  },
  cowork_metrics: countShape(coworkCounters),
};` → `{}`
- 8 packages/connectors/src/contracts.ts:186:24 Survived ObjectLiteral: `claude_code_metrics: {
    core_metrics: {
      ...countShape("artifacts_created_count commit_count distinct_session_count pull_request_count"),
      lines_of_code: countShape("added_count removed_count"),
    },
    tool_actions: Object.fromEntries(
      ["edit_tool", "multi_edit_tool", "notebook_edit_tool", "write_tool"]
        .map(name => [name, countShape("accepted_count rejected_count")]),
    ),
  },` → `{}`
- 9 packages/connectors/src/contracts.ts:187:19 Survived ObjectLiteral: `core_metrics: {
      ...countShape("artifacts_created_count commit_count distinct_session_count pull_request_count"),
      lines_of_code: countShape("added_count removed_count"),
    },` → `{}`
- 10 packages/connectors/src/contracts.ts:188:21 Survived StringLiteral: `...countShape("artifacts_created_count commit_count distinct_session_count pull_request_count"),` → `""`
- 11 packages/connectors/src/contracts.ts:189:33 Survived StringLiteral: `lines_of_code: countShape("added_count removed_count"),` → `""`
- 12 packages/connectors/src/contracts.ts:192:7 Survived ArrayDeclaration: `["edit_tool", "multi_edit_tool", "notebook_edit_tool", "write_tool"]` → `[]`
- 13 packages/connectors/src/contracts.ts:192:8 Survived StringLiteral: `["edit_tool", "multi_edit_tool", "notebook_edit_tool", "write_tool"]` → `""`
- 14 packages/connectors/src/contracts.ts:192:21 Survived StringLiteral: `["edit_tool", "multi_edit_tool", "notebook_edit_tool", "write_tool"]` → `""`
- 15 packages/connectors/src/contracts.ts:192:40 Survived StringLiteral: `["edit_tool", "multi_edit_tool", "notebook_edit_tool", "write_tool"]` → `""`
- 16 packages/connectors/src/contracts.ts:192:62 Survived StringLiteral: `["edit_tool", "multi_edit_tool", "notebook_edit_tool", "write_tool"]` → `""`
- 17 packages/connectors/src/contracts.ts:193:14 Survived ArrowFunction: `.map(name => [name, countShape("accepted_count rejected_count")]),` → `() => undefined`
- 18 packages/connectors/src/contracts.ts:193:22 Survived ArrayDeclaration: `.map(name => [name, countShape("accepted_count rejected_count")]),` → `[]`
- 19 packages/connectors/src/contracts.ts:193:40 Survived StringLiteral: `.map(name => [name, countShape("accepted_count rejected_count")]),` → `""`

## Activation correction contracts-only preview (round 4)

Candidate e4f62808f3f8a38d71e6b3bc89c52a3112a9f607. Start 2026-10-06T02:48:50.971Z; end 2026-10-06T02:49:34.601Z. Focused integration passed (15 tests), ordinary preflight passed. Fixture cleaned up. Retain schema91.67% and ingestion92.43%; neither rerun. Preview rounds total 4.

Commands/timing:
- `rtk proxy pnpm --filter @smp/db exec vitest run src/analytics-ingestion.integration.test.ts`; exit 0; 0.039 minutes.
- `rtk proxy pnpm mutation:preflight`; exit 0; 0.012 minutes.
- `rtk proxy pnpm test:mutation`; exit 0; 0.642 minutes.

Environment: MUTATION_BASE=ed9ff60 MUTATION_WORK_ID=US-070; preview adds MUTATION_SHARD=<post-task contracts ID>. Default and US070 owner/app pairs were supplied in memory, DB_DRIVER=pg. No cache clear/test_report.

### vitest-ae209c3d8c87

Sources: packages/connectors/src/contracts.ts. Tests: packages/connectors/src/contracts.test.ts, packages/connectors/src/dispatch.test.ts, packages/connectors/src/providers/anthropic/connector.test.ts. Exit 0; 0.642 minutes. Score 88.41%; counts {'Killed': 61, 'Survived': 8}. JSON: `reports/mutation/vitest-ae209c3d8c87-57729-1791254936417-7be08c8dfc70f8.json`. Log: `task-1-preview-vitest-ae209c3d8c87-round4.log`.

- 29 packages/connectors/src/contracts.ts:202:9 Survived ConditionalExpression: `if (input === null || typeof input !== "object" || Array.isArray(input)` → `false`
- 37 packages/connectors/src/contracts.ts:204:23 Survived StringLiteral: `throw new Error(`Invalid activity metric object: ${path}`);` → ````
- 55 packages/connectors/src/contracts.ts:213:13 Survived ConditionalExpression: `if (typeof metric !== "number" || !Number.isFinite(metric)` → `false`
- 56 packages/connectors/src/contracts.ts:213:13 Survived LogicalOperator: `if (typeof metric !== "number" || !Number.isFinite(metric)` → `typeof metric !== "number" && !Number.isFinite(metric)`
- 57 packages/connectors/src/contracts.ts:213:13 Survived ConditionalExpression: `if (typeof metric !== "number" || !Number.isFinite(metric)` → `false`
- 66 packages/connectors/src/contracts.ts:215:27 Survived StringLiteral: `throw new Error(`Invalid activity count: ${path}.${key}`);` → ````
- 67 packages/connectors/src/contracts.ts:218:54 Survived StringLiteral: `} else result[key] = normalize(metric, nested, `${path}.${key}`);` → ````
- 68 packages/connectors/src/contracts.ts:222:49 Survived StringLiteral: `return normalize(value, activityCounterShape, "counters");` → `""`

## Duplicate identity namespace fix (round 5)

Candidate 9dea85ccb70185e112c1e4d1c81a979176494825. Start 2026-10-06T02:56:27.667Z; end 2026-10-06T03:01:13.269Z. Preflight passed; only ingestion source shard selected. Fixture cleaned up. Schema91.67% and contracts88.41% retained. Preview rounds total5.

- `rtk proxy pnpm mutation:preflight`; exit 0; 0.012 minutes.
- `rtk proxy pnpm test:mutation`; exit 0; 4.714 minutes.

Env MUTATION_BASE=ed9ff60 MUTATION_WORK_ID=US-070; preview MUTATION_SHARD=vitest-7e4dfff580cb; in-memory migrated owner/app pairs. Score 92.19%; counts {'NoCoverage': 2, 'Killed': 295, 'Survived': 23}. Sources ['packages/db/src/analytics-ingestion.ts']; selected tests ['packages/db/src/analytics-ingestion.integration.test.ts']. JSON `reports/mutation/vitest-7e4dfff580cb-64362-1791255390742-3a81a796526b18.json`; log `task-1-preview-vitest-7e4dfff580cb-round5.log`. No cache clear or test_report.

- 85 packages/db/src/analytics-ingestion.ts:52:36 NoCoverage StringLiteral: `if (Array.isArray(value)) return `[${value.map(canonical).join(",")}]`;` → ````
- 86 packages/db/src/analytics-ingestion.ts:52:66 NoCoverage StringLiteral: `if (Array.isArray(value)) return `[${value.map(canonical).join(",")}]`;` → `""`
- 24 packages/db/src/analytics-ingestion.ts:37:7 Survived ConditionalExpression: `if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) throw new Error("ACTIVITY_INVALID_DATE");` → `false`
- 25 packages/db/src/analytics-ingestion.ts:37:7 Survived LogicalOperator: `if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) throw new Error("ACTIVITY_INVALID_DATE");` → `typeof value !== "string" && !/^\d{4}-\d{2}-\d{2}$/.test(value)`
- 26 packages/db/src/analytics-ingestion.ts:37:7 Survived ConditionalExpression: `if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) throw new Error("ACTIVITY_INVALID_DATE");` → `false`
- 30 packages/db/src/analytics-ingestion.ts:37:37 Survived Regex: `if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) throw new Error("ACTIVITY_INVALID_DATE");` → `/\d{4}-\d{2}-\d{2}$/`
- 31 packages/db/src/analytics-ingestion.ts:37:37 Survived Regex: `if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) throw new Error("ACTIVITY_INVALID_DATE");` → `/^\d{4}-\d{2}-\d{2}/`
- 75 packages/db/src/analytics-ingestion.ts:51:7 Survived ConditionalExpression: `if (value === null || typeof value !== "object") return JSON.stringify(value);` → `true`
- 79 packages/db/src/analytics-ingestion.ts:51:7 Survived EqualityOperator: `if (value === null || typeof value !== "object") return JSON.stringify(value);` → `value !== null`
- 81 packages/db/src/analytics-ingestion.ts:51:25 Survived EqualityOperator: `if (value === null || typeof value !== "object") return JSON.stringify(value);` → `typeof value === "object"`
- 82 packages/db/src/analytics-ingestion.ts:51:42 Survived StringLiteral: `if (value === null || typeof value !== "object") return JSON.stringify(value);` → `""`
- 84 packages/db/src/analytics-ingestion.ts:52:7 Survived ConditionalExpression: `if (Array.isArray(value)) return `[${value.map(canonical).join(",")}]`;` → `false`
- 88 packages/db/src/analytics-ingestion.ts:53:14 Survived MethodExpression: `return `{${Object.entries(value).sort(([a], [b]) => a.localeCompare(b))` → `Object.entries(value)`
- 89 packages/db/src/analytics-ingestion.ts:53:41 Survived ArrowFunction: `return `{${Object.entries(value).sort(([a], [b]) => a.localeCompare(b))` → `() => undefined`
- 92 packages/db/src/analytics-ingestion.ts:54:77 Survived StringLiteral: `.map(([key, item]) => `${JSON.stringify(key)}:${canonical(item)}`).join(",")}}`;` → `""`
- 137 packages/db/src/analytics-ingestion.ts:73:22 Survived ConditionalExpression: `const identity = email !== null ? `email:${email}` : (record.providerUserId === null ? null : `provider:${record.providerUserId}`);` → `false`
- 149 packages/db/src/analytics-ingestion.ts:75:22 Survived ConditionalExpression: `const previous = key === null ? undefined : emails.get(key);` → `false`
- 163 packages/db/src/analytics-ingestion.ts:81:9 Survived ConditionalExpression: `if (key !== null) emails.set(key, indexed);` → `true`
- 166 packages/db/src/analytics-ingestion.ts:87:88 Survived BooleanLiteral: `async function matchPerson(database: Matcher, companyId: string, email: string, lock = false) {` → `true`
- 228 packages/db/src/analytics-ingestion.ts:134:21 Survived ObjectLiteral: `.for("share", { of: [schema.vendorAccount, schema.vendor] });` → `{}`
- 238 packages/db/src/analytics-ingestion.ts:136:39 Survived ObjectLiteral: `const [company] = await tx.select({ id: schema.company.id }).from(schema.company).where(eq(schema.company.id, batch.companyId)).for("share");` → `{}`
- 245 packages/db/src/analytics-ingestion.ts:139:37 Survived ObjectLiteral: `const [actor] = await tx.select({ id: schema.userAccount.id }).from(schema.userAccount)` → `{}`
- 298 packages/db/src/analytics-ingestion.ts:163:13 Survived ConditionalExpression: `if (!current || current.syncedAt.getTime() < batch.syncedAt.getTime()` → `false`
- 299 packages/db/src/analytics-ingestion.ts:163:13 Survived LogicalOperator: `if (!current || current.syncedAt.getTime() < batch.syncedAt.getTime()` → `!current && current.syncedAt.getTime() < batch.syncedAt.getTime()`
- 301 packages/db/src/analytics-ingestion.ts:163:25 Survived ConditionalExpression: `if (!current || current.syncedAt.getTime() < batch.syncedAt.getTime()` → `false`

## Email conditional oracle repair (round 6)

Candidate 4b91e690b49980c016b1db5dc66cecf0f199ec12. Named #137 regression justifies this test-only re-preview. Start 2026-10-06T03:05:48.697Z; end 2026-10-06T03:10:45.848Z. Preflight passed; ingestion-only preview passed; fixture cleanup finished. Schema91.67% and contracts88.41% retained. Preview rounds total6.

- `rtk proxy pnpm mutation:preflight`; exit 0; 0.013 minutes.
- `rtk proxy pnpm test:mutation`; exit 0; 4.905 minutes.

Env MUTATION_BASE=ed9ff60d9dda6aaf78fae5e9a61d189b1a8e4108 MUTATION_WORK_ID=US-070; preview MUTATION_SHARD=vitest-7e4dfff580cb; in-memory migrated owner/app pairs. Score 92.50%; counts {'NoCoverage': 2, 'Killed': 296, 'Survived': 22}. Sources ['packages/db/src/analytics-ingestion.ts']; selected tests ['packages/db/src/analytics-ingestion.integration.test.ts']. JSON `reports/mutation/vitest-7e4dfff580cb-76617-1791255951894-7891b26d808e3.json`; log `task-1-preview-vitest-7e4dfff580cb-round6.log`. No cold campaign/cache clear/config/router/test_report or feedback edits.

Current exact residuals:

- 85 packages/db/src/analytics-ingestion.ts:52:36 NoCoverage StringLiteral: `if (Array.isArray(value)) return `[${value.map(canonical).join(",")}]`;` → ````
- 86 packages/db/src/analytics-ingestion.ts:52:66 NoCoverage StringLiteral: `if (Array.isArray(value)) return `[${value.map(canonical).join(",")}]`;` → `""`
- 24 packages/db/src/analytics-ingestion.ts:37:7 Survived ConditionalExpression: `if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) throw new Error("ACTIVITY_INVALID_DATE");` → `false`
- 25 packages/db/src/analytics-ingestion.ts:37:7 Survived LogicalOperator: `if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) throw new Error("ACTIVITY_INVALID_DATE");` → `typeof value !== "string" && !/^\d{4}-\d{2}-\d{2}$/.test(value)`
- 26 packages/db/src/analytics-ingestion.ts:37:7 Survived ConditionalExpression: `if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) throw new Error("ACTIVITY_INVALID_DATE");` → `false`
- 30 packages/db/src/analytics-ingestion.ts:37:37 Survived Regex: `if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) throw new Error("ACTIVITY_INVALID_DATE");` → `/\d{4}-\d{2}-\d{2}$/`
- 31 packages/db/src/analytics-ingestion.ts:37:37 Survived Regex: `if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) throw new Error("ACTIVITY_INVALID_DATE");` → `/^\d{4}-\d{2}-\d{2}/`
- 75 packages/db/src/analytics-ingestion.ts:51:7 Survived ConditionalExpression: `if (value === null || typeof value !== "object") return JSON.stringify(value);` → `true`
- 79 packages/db/src/analytics-ingestion.ts:51:7 Survived EqualityOperator: `if (value === null || typeof value !== "object") return JSON.stringify(value);` → `value !== null`
- 81 packages/db/src/analytics-ingestion.ts:51:25 Survived EqualityOperator: `if (value === null || typeof value !== "object") return JSON.stringify(value);` → `typeof value === "object"`
- 82 packages/db/src/analytics-ingestion.ts:51:42 Survived StringLiteral: `if (value === null || typeof value !== "object") return JSON.stringify(value);` → `""`
- 84 packages/db/src/analytics-ingestion.ts:52:7 Survived ConditionalExpression: `if (Array.isArray(value)) return `[${value.map(canonical).join(",")}]`;` → `false`
- 88 packages/db/src/analytics-ingestion.ts:53:14 Survived MethodExpression: `return `{${Object.entries(value).sort(([a], [b]) => a.localeCompare(b))` → `Object.entries(value)`
- 89 packages/db/src/analytics-ingestion.ts:53:41 Survived ArrowFunction: `return `{${Object.entries(value).sort(([a], [b]) => a.localeCompare(b))` → `() => undefined`
- 92 packages/db/src/analytics-ingestion.ts:54:77 Survived StringLiteral: `.map(([key, item]) => `${JSON.stringify(key)}:${canonical(item)}`).join(",")}}`;` → `""`
- 149 packages/db/src/analytics-ingestion.ts:75:22 Survived ConditionalExpression: `const previous = key === null ? undefined : emails.get(key);` → `false`
- 163 packages/db/src/analytics-ingestion.ts:81:9 Survived ConditionalExpression: `if (key !== null) emails.set(key, indexed);` → `true`
- 166 packages/db/src/analytics-ingestion.ts:87:88 Survived BooleanLiteral: `async function matchPerson(database: Matcher, companyId: string, email: string, lock = false) {` → `true`
- 228 packages/db/src/analytics-ingestion.ts:134:21 Survived ObjectLiteral: `.for("share", { of: [schema.vendorAccount, schema.vendor] });` → `{}`
- 238 packages/db/src/analytics-ingestion.ts:136:39 Survived ObjectLiteral: `const [company] = await tx.select({ id: schema.company.id }).from(schema.company).where(eq(schema.company.id, batch.companyId)).for("share");` → `{}`
- 245 packages/db/src/analytics-ingestion.ts:139:37 Survived ObjectLiteral: `const [actor] = await tx.select({ id: schema.userAccount.id }).from(schema.userAccount)` → `{}`
- 298 packages/db/src/analytics-ingestion.ts:163:13 Survived ConditionalExpression: `if (!current || current.syncedAt.getTime() < batch.syncedAt.getTime()` → `false`
- 299 packages/db/src/analytics-ingestion.ts:163:13 Survived LogicalOperator: `if (!current || current.syncedAt.getTime() < batch.syncedAt.getTime()` → `!current && current.syncedAt.getTime() < batch.syncedAt.getTime()`
- 301 packages/db/src/analytics-ingestion.ts:163:25 Survived ConditionalExpression: `if (!current || current.syncedAt.getTime() < batch.syncedAt.getTime()` → `false`
