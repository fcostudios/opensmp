# US-070 final generated critical-path correction

Documentation-only final-review M2 correction. Scored code cutoff remains `927835e559d3b330f3c49436ca095939f3a21216`; no production, tests, configuration files, harness, migrations or application gates changed/run.

## Authoritative config and preservation

Normal `nous_trace.py config show --project fcostudios__smp` snapshots: `/tmp/us070-final-doc-config-before.json` and `/tmp/us070-final-doc-config-after.json`. Config version **38 → 39**, record ID **71**. Queried current array first and submitted the entire two-row array via normal `config patch --project fcostudios__smp --key testing.critical_paths --value <full JSON array>` (exit 0). Array snapshot `/tmp/us070-final-doc-critical-path-array.json`. Exact invitation row retained; every other character of the US-070 row retained.

Before: `unmatched or ambiguous identities produce durable warnings.`

After: `unmatched or null-email identities produce durable warnings; ambiguous identities reject the batch atomically.`

Patch/query validation proves the after array equals the preserved before array with exactly that clause replacement. No force/adopt or other authoritative config mutation.

## Normal generation and bounded delivery

All shell calls after the initial brief/RTK read used `rtk`; the initial combined read inadvertently lacked that prefix. CLI subprocess calls were orchestrated through `rtk proxy python3`.

1. `./infra/scripts/sync-from-nous.sh --dry-run -c agent_files sprint_plan`: exit **1**, full output `final-doc-preview.log`. Normal dry-run categories ran, but the wrapper Ledger invariant preview rejects the already-delivered TESTING/critical-paths hashes as unknown generated guidance states. No wrapper/harness correction attempted.
2. Scratch copy excludes `.git`, `node_modules`, `.next`, `.tmp`, `.nous-feedback.jsonl`. Scratch path: `/var/folders/lc/1n1k0ggd2qn4p8lhmc0wp90m0000gn/T/us070-final-doc-delivery-hjnyil_z`.
3. `python3 /Users/fcolomas/Projects/nous/Nous/System/nous_package.py sync --target <scratch> --project fcostudios__smp --no-pull --no-drift -c agent_files sprint_plan`: exit **0**, full output `final-doc-generation.log`; patch output `final-doc-config-patch.log`. No feedback pull or BI drift rerun.
4. Official `package_templates.provenance.provenance_state` reports **verified** on both generated guides. Official trailer-free `split` bodies equal the prior bodies with only the intended clause replacement. Generator manifest hashes match the first 16 characters of full-file SHA256. Copied only these two guides, their two exact generated `.nous-sync.json` entries, and clean generator `.nous-provenance.json`. All unrelated manifest entries and global metadata, including synced_at, preserved.

Normal clean substrate provenance changed `0b48fe959bed → d57caf92a342`; `.nous-provenance.json` is copied verbatim from scratch. Preexisting AGENTS divergence was refused by normal generation; AGENTS and other outputs remain untouched. Other story/guide outputs stay scratch-only.

Validation correction: first validation compared the full digest with a 16-character manifest digest and failed before any copy. Corrected comparison uses the documented manifest prefix and passes. Subsequent substrate-identity assertion detected the new clean substrate revision after guide delivery; clean normal provenance was then copied and reported rather than assuming it unchanged.

## Hashes and validation

- `docs/dev-guide/TESTING.md`: SHA256 `44fb3e16f68abeda8e497f54bb5d8f2510b1c08b32ee13919e3bbf23c4d24452`; emitted body `fbed082a88e9216f`; manifest `44fb3e16f68abeda`, source emitted.
- `testing/critical-paths.md`: SHA256 `486e9d536fb1b016d89b36987ac76d84f31aa7816e499f2ef0974dba7b163c26`; emitted body `eee94d278f5ded66`; manifest `486e9d536fb1b016`, source generated.

Scoped diff/body/provenance/manifest preservation checks PASS. `git diff --check` PASS. No broad suite or cold campaign: documentation-only correction does not invalidate the scored tree. Full functional gate failure remains independently controller-owned. Existing feedback and untracked reports/evidence are excluded from this commit.

## Commit and seat metadata

Exact scoped commit: `bc76f0c3725920b211722806684ed8a39392310c`. Range: `927835e559d3b330f3c49436ca095939f3a21216..bc76f0c3725920b211722806684ed8a39392310c`. Commit includes only the two generated guides plus `.nous-sync.json` and `.nous-provenance.json`; this worker report/logs are ignored SDD artifacts, retained on disk. Commit hook passed. Own rollout pointer is unavailable in this bounded worker context; no unrelated transcript inspected. Independent scoped review follows.
