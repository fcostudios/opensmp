# Task 3 scoped review — 8f3d393

## Spec compliance

**Issues found.** I1 breaks the required post-fetch exclusion boundary for global warnings. Other task-scoped requirements are implemented: trusted active-company enumeration (analytics-activity.ts:49–50), precredential SQL exclusion (:33–44), UTC calendar subtraction (:47), actual prefetch freshness (:55), successfulJob/finally cleanup (deferred.ts:42–47), full snapshot before persistence (:64–71), and explicit failure metadata (:67). All supplied global constraints bind this assessment.

⚠️ Controller-owned: committed migration/parity and broad build gates, schedules unchanged outside diff, terminal forecast/cost provenance and final campaign. Missing/nullable metrics, natural-key uniqueness, equal-time contradiction and tenant matching come from previous tasks; focused shared-boundary inspection and integration assertions support their use here, rather than this diff independently implementing them.

## Strengths

Real ledger_app fixtures assert independent Person IDs and counters, stable IDs/newer freshness, two null-company warning reasons, mode exclusion without KEK/credentials, UTC leap/year/timezone boundaries, stale concurrent completion and provider retry metadata (analytics-activity.integration.test.ts:27–115). No owned-module mocks. No arbitrary company assignment or raw credential persistence was introduced. Narrow shared .js import fixes are justified by the NodeNext consumer and change no semantics.

## Issues

### Important I1 — outer transaction is accidentally committed by the first shared batch

analytics-activity.ts:71–82 constructs a root drizzle(client) after manually issuing BEGIN, then passes that root to ingestActivityBatch. The shared helper calls database.transaction (analytics-ingestion.ts:128). Installed Drizzle NodePgSession.transaction issues BEGIN/COMMIT (node-postgres/session.js:137–147); only NodePgTransaction.transaction issues SAVEPOINT (:163–179). Consequently the first company batch commits the outer account transaction and releases its account/vendor locks. Later batches and global warnings are outside that boundary. Disabling after the first batch can leave warnings from an excluded attempt, contrary to Step 3; warning failure cannot roll back the already committed first batch, contradicting the report's whole-account atomicity claim. PostgreSQL also emits nested-BEGIN/no-transaction notices. Existing revoke-INSERT test fails on the first batch audit, so does not establish rollback after a successful company batch.

Fix with one actual Drizzle transaction callback and pass its transaction object to routing, shared ingestion and global warning insertions, preserving a single owned client/session. Add a real DB adversarial oracle observing account/vendor locks after first batch and triggering failure specifically at a later global warning (e.g. narrowly scoped real PostgreSQL trigger), proving the intended boundary and cleanup. Do not mock owned ingestion or rerun broad suites.

### Important I2 — genuine surviving worker/deferred boundary mutants

Exact dispositions below identify behavior without an effective oracle. In particular raw BEGIN/COMMIT removal survives because I1 already neutralizes the intended boundary; these are not equivalent. Deferred preview testFiles is exactly [apps/worker/src/jobs/deferred.test.ts], mutation ranges :15 and :42–47. Its five residuals bypass/delete services-backed execution and cleanup. Move/reuse the existing real-DB services-backed integration assertions through the established deferred.test.ts test seam (or a bounded test import relationship), without router/config/harness changes, duplicated domain logic or owned mocks. Preserve direct reusable-job tests in their relevant seam.

### Minor M1 — compressed source/test formatting

analytics-activity.ts:14–85 and analytics-activity.integration.test.ts:13–115 compress transaction ownership, SQL and assertions into long lines. Format these touched additions consistently; the current layout obscures the I1 lifetime boundary.

## Named outside checks and limits

One supplied diff read; no git regeneration and no test suite rerun. Named risks: shared matcher/transaction ownership checked analytics-ingestion.ts:87–176; lazy observation pool ownership checked connector-call-observations.ts:38–80; actual factory/credential coupling checked connector-composition.ts and Anthropic credentials.ts:87–144 plus connector.ts:399–430, :681–704; reporter compatibility checked runtime.ts:497–534. Concrete transaction-driver ambiguity checked installed Drizzle session.js:137–179. The shared source outside the tiny import hunk was inspected only for this matcher/transaction risk.

Existing two-role composition requires admin_scoped plus analytics and selects analytics for analytics endpoints. Reusing it matches the task's explicit factory instruction and avoids fabricating secrets. Analytics-only enablement remains a cross-task architectural limitation for broad review, not a new Task3 requirement invented here. Provider unsupported-result branch is unreachable through the currently fixed shipped Anthropic rest implementation; targeted unsupported account eligibility remains independently required.

## Assessment

**Task quality: Needs fixes.** I1 is a concrete locking/transaction defect; I2 prevents mutation closure. No Critical finding. Minor formatting remains for broad triage.

## Exact residual dispositions

Reviewer task3_review signs only the @equivalent/@accepted lines below. Every genuine entry remains unapproved; IDs are report-local and must be remapped after the fix. Final preview cutoff read: task-3-preview-report.md, authority ed9ff60, HEAD 8f3d393. Three touched previews took 8.006550 minutes. Worker 96 Killed/1 Timeout/20 Survived/5 NoCoverage, 79.51% FAIL; deferred 4 Killed/1 Survived/4 NoCoverage, 44.44% FAIL; ingestion 296 Killed/22 Survived/2 NoCoverage, 92.50% PASS. Exactly 54 residuals: 24 equivalent, 11 accepted, 19 genuine unapproved. Worker 5 equivalent/6 accepted/14 unapproved; deferred 5 unapproved; retained ingestion 19 equivalent/5 accepted. Survived 43, NoCoverage 11; every residual receives an independent disposition below.

Evidence: reports/mutation/vitest-3ff43baf3f6d-23093-1791258344528-1ab2290fec8a58.json

14 apps/worker/src/jobs/analytics-activity.ts:31:93 NoCoverage replacement='""' @accepted: Untyped invalid-time prose diagnostic is not a provider/runtime discriminant; rejection remains.

33 apps/worker/src/jobs/analytics-activity.ts:32:159 NoCoverage replacement='""' @accepted: Untyped invalid-account prose diagnostic is not a provider/runtime discriminant; rejection remains.

60 apps/worker/src/jobs/analytics-activity.ts:44:33 NoCoverage replacement='{}' @unapproved: Global unsupported-only zero result becomes {}, violating processed contract; exact successful zero oracle needed.

66 apps/worker/src/jobs/analytics-activity.ts:46:31 NoCoverage replacement='""' @accepted: Missing KEK still rejects; this untyped prose diagnostic is not specified.

94 apps/worker/src/jobs/analytics-activity.ts:66:59 NoCoverage replacement='""' @equivalent: Fixed rest implementation only returns provider/capacity failures or success; unsupported result cannot reach this branch.

3 apps/worker/src/jobs/analytics-activity.ts:26:23 Survived replacement='() => undefined' @unapproved: Injected limiter clock is load-bearing under throttling/retries; add deterministic Pact-backed rate-limit/retry observation with real clock seam.

10 apps/worker/src/jobs/analytics-activity.ts:31:8 Survived replacement='false' @unapproved: Explicit invalid scheduled-time boundary is removed; assert invalid Date rejects before transport/credential work.

11 apps/worker/src/jobs/analytics-activity.ts:31:8 Survived replacement='!(input.at instanceof Date) && !Number.isFinite(input.at.getTime())' @unapproved: Invalid Date instance escapes guard; assert invalid Date rejects at the intended boundary.

16 apps/worker/src/jobs/analytics-activity.ts:32:8 Survived replacement='false' @unapproved: UUID input guard is removed; assert malformed target fails before provider/credential work.

21 apps/worker/src/jobs/analytics-activity.ts:32:48 Survived replacement='/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i' @unapproved: Prefix UUID junk bypasses anchor; exact malformed target oracle needed.

22 apps/worker/src/jobs/analytics-activity.ts:32:48 Survived replacement='/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i' @unapproved: Suffix UUID junk bypasses anchor; exact malformed target oracle needed.

39 apps/worker/src/jobs/analytics-activity.ts:38:8 Survived replacement='false' @equivalent: Empty account rows produce empty eligible rows, and the unchanged eligible-length return still exits before KEK/credentials.

46 apps/worker/src/jobs/analytics-activity.ts:40:23 Survived replacement='true' @unapproved: Non-rest API protocol becomes eligible; assert targeted unsupported protocol rejects and global run skips before KEK/network.

59 apps/worker/src/jobs/analytics-activity.ts:44:8 Survived replacement='false' @unapproved: Global unsupported-only account set no longer returns successful zero before KEK; assert excluded global run with no KEK.

61 apps/worker/src/jobs/analytics-activity.ts:45:17 Survived replacement='options.kekFile' @accepted: Whitespace-padded KEK paths change acceptance only; the declared configuration does not promise whitespace normalization and valid file paths retain behavior.

62 apps/worker/src/jobs/analytics-activity.ts:45:17 Survived replacement='options.kekFile.trim' @accepted: Absent KEK configuration still rejects; removing optional access changes only untyped failure diagnostics.

65 apps/worker/src/jobs/analytics-activity.ts:46:8 Survived replacement='false' @accepted: Absent or empty KEK path still rejects inside the real readKekFile validation; the prose diagnostic is not specified.

91 apps/worker/src/jobs/analytics-activity.ts:66:10 Survived replacement='false' @equivalent: Shipped fixed Anthropic rest syncActivity never produces unsupported, leaving identical provider-failure conversion.

93 apps/worker/src/jobs/analytics-activity.ts:66:28 Survived replacement='""' @equivalent: Shipped fixed Anthropic rest syncActivity never produces unsupported, so this comparison remains false.

99 apps/worker/src/jobs/analytics-activity.ts:71:25 Survived replacement='""' @unapproved: Removing outer BEGIN weakens intended postfetch lock lifetime; I1 currently conceals this.

106 apps/worker/src/jobs/analytics-activity.ts:75:54 Survived replacement='""' @unapproved: Excluded attempt leaves transaction open on reusable pooled client; assert real session idle-without-transaction/lock cleanup before close.

107 apps/worker/src/jobs/analytics-activity.ts:76:33 Survived replacement='{}' @equivalent: Only explicit table query builders are used; schema-less Drizzle preserves select/insert/transaction behavior because no relational db.query API is used.

113 apps/worker/src/jobs/analytics-activity.ts:80:166 Survived replacement='""' @unapproved: Global warning loses VendorAccount entity attribution; assert durable entity_type/entity_id/actor/account-day metadata.

116 apps/worker/src/jobs/analytics-activity.ts:81:25 Survived replacement='""' @unapproved: Removing outer COMMIT changes intended durable account transaction; I1 currently conceals this.

119 apps/worker/src/jobs/analytics-activity.ts:82:42 Survived replacement='""' @unapproved: Failure rollback is omitted; assert real session transaction/lock cleanup after later warning failure before close.


Evidence: reports/mutation/vitest-4795ff5a0847-27108-1791258526217-280e55c97652b8.json

5 apps/worker/src/jobs/deferred.ts:44:46 NoCoverage replacement='{}' @unapproved: Services-backed real DB execution/processed result and finally cleanup are absent from selected deferred.test.ts seam; restore via bounded real integration test relationship.

6 apps/worker/src/jobs/deferred.ts:45:11 NoCoverage replacement='{}' @unapproved: Services-backed real DB execution/processed result and finally cleanup are absent from selected deferred.test.ts seam; restore via bounded real integration test relationship.

7 apps/worker/src/jobs/deferred.ts:45:51 NoCoverage replacement='{}' @unapproved: Services-backed real DB execution/processed result and finally cleanup are absent from selected deferred.test.ts seam; restore via bounded real integration test relationship.

8 apps/worker/src/jobs/deferred.ts:46:15 NoCoverage replacement='{}' @unapproved: Services-backed real DB execution/processed result and finally cleanup are absent from selected deferred.test.ts seam; restore via bounded real integration test relationship.

2 apps/worker/src/jobs/deferred.ts:43:11 Survived replacement='true' @unapproved: Services-backed real DB execution/processed result and finally cleanup are absent from selected deferred.test.ts seam; restore via bounded real integration test relationship.


Current ingestion evidence: reports/mutation/vitest-7e4dfff580cb-27541-1791258541448-ff881367b8e1e.json

Independently matched report IDs/status/location/replacement against retained Task1 table; .js import extensions preserve all retained semantics. No new ingestion residual.

85 packages/db/src/analytics-ingestion.ts:52:36 NoCoverage replacement="``" @equivalent: array canonical representation is unreachable for normalized allowlisted nullable integer/object counters.

86 packages/db/src/analytics-ingestion.ts:52:66 NoCoverage replacement="\"\"" @equivalent: array separator is unreachable because normalized counter trees contain no arrays.

24 packages/db/src/analytics-ingestion.ts:37:7 Survived replacement="false" @accepted: Exact ISO roundtrip preserves rejection and acceptance for JSON date inputs; malformed non-JSON Symbol/coercion values can change diagnostics, which the date contract does not specify. This is narrowly accepted, not literal equivalence.

25 packages/db/src/analytics-ingestion.ts:37:7 Survived replacement="typeof value !== \"string\" && !/^\\d{4}-\\d{2}-\\d{2}$/.test(value)" @accepted: Exact ISO roundtrip preserves rejection and acceptance for JSON date inputs; malformed non-JSON Symbol/coercion values can change diagnostics, which the date contract does not specify. This is narrowly accepted, not literal equivalence.

26 packages/db/src/analytics-ingestion.ts:37:7 Survived replacement="false" @accepted: Exact ISO roundtrip preserves rejection and acceptance for JSON date inputs; malformed non-JSON Symbol/coercion values can change diagnostics, which the date contract does not specify. This is narrowly accepted, not literal equivalence.

30 packages/db/src/analytics-ingestion.ts:37:37 Survived replacement="/\\d{4}-\\d{2}-\\d{2}$/" @equivalent: removing the regex start anchor cannot bypass exact ISO-date equality against the whole original string.

31 packages/db/src/analytics-ingestion.ts:37:37 Survived replacement="/^\\d{4}-\\d{2}-\\d{2}/" @equivalent: removing the regex end anchor cannot bypass exact ISO-date equality against the whole original string.

75 packages/db/src/analytics-ingestion.ts:51:7 Survived replacement="true" @equivalent: duplicate counters were reconstructed in deterministic allowlist key order; JSON.stringify of that complete tree has the same equality relation as recursive canonical encoding.

79 packages/db/src/analytics-ingestion.ts:51:7 Survived replacement="value !== null" @equivalent: normalized counter roots are nonnull objects, so this mutation serializes the complete deterministically ordered tree and preserves duplicate equality.

81 packages/db/src/analytics-ingestion.ts:51:25 Survived replacement="typeof value === \"object\"" @equivalent: serializing the complete normalized object tree preserves all nullable integer values and duplicate equality because reconstruction fixes key order.

82 packages/db/src/analytics-ingestion.ts:51:42 Survived replacement="\"\"" @equivalent: replacing the object type string makes the root serialize directly; normalized key order and full-tree duplicate equality remain deterministic.

84 packages/db/src/analytics-ingestion.ts:52:7 Survived replacement="false" @equivalent: counter normalization rejects arrays on every known path, so canonical never receives an array.

88 packages/db/src/analytics-ingestion.ts:53:14 Survived replacement="Object.entries(value)" @equivalent: normalization reconstructs every object in a fixed allowlist order, so removing canonical sorting cannot change duplicate equality.

89 packages/db/src/analytics-ingestion.ts:53:41 Survived replacement="() => undefined" @equivalent: retaining the reconstructed object order instead of sorting preserves deterministic equality for supported counter trees.

92 packages/db/src/analytics-ingestion.ts:54:77 Survived replacement="\"\"" @equivalent: removing the canonical object comma remains injective for fixed quoted allowlisted keys and nullable integer/object values; this encoding is used only for equality and is never persisted.

149 packages/db/src/analytics-ingestion.ts:75:22 Survived replacement="false" @equivalent: null duplicate keys are never stored in emails, so emails.get(null) still yields undefined.

163 packages/db/src/analytics-ingestion.ts:81:9 Survived replacement="true" @equivalent: storing an unused null Map key is unobservable because lookup explicitly skips null keys and the local Map is not returned.

166 packages/db/src/analytics-ingestion.ts:87:88 Survived replacement="true" @accepted: defaulting global read matching to shared locks preserves identity decisions and scope safety but may add contention; stronger locking is permitted and no latency/read-lock contract is specified.

228 packages/db/src/analytics-ingestion.ts:134:21 Survived replacement="{}" @equivalent: FOR SHARE without OF locks all relations in this two-table account/vendor query, the same set as its explicit OF list.

238 packages/db/src/analytics-ingestion.ts:136:39 Survived replacement="{}" @equivalent: company selection is consumed only as row existence; selecting an empty object preserves that existence result and row lock.

245 packages/db/src/analytics-ingestion.ts:139:37 Survived replacement="{}" @equivalent: actor selection is consumed only as row existence; its selected ID is never used, so empty-object selection preserves actor verification and lock.

298 packages/db/src/analytics-ingestion.ts:163:13 Survived replacement="false" @equivalent: a suppressed conditional upsert holds the existing key row with synced_at >= incoming; Person scope is locked, so the follow-up current row exists and cannot be older.

299 packages/db/src/analytics-ingestion.ts:163:13 Survived replacement="!current && current.syncedAt.getTime() < batch.syncedAt.getTime()" @equivalent: PostgreSQL conflict row locking plus the upsert timestamp predicate guarantee current exists and is at least as new, leaving the equal-contradiction check unchanged.

301 packages/db/src/analytics-ingestion.ts:163:25 Survived replacement="false" @equivalent: current.synced_at < incoming is unreachable after this upsert returns no row under the held conflict-row lock.


## Final evidence limitations and bounded repair contracts

⚠️ Preview fixture shutdown produced AggregateError “PostgreSQL fixture cleanup failed”; isolated container removal is verified in the preview report but underlying cleanup errors are not exposed. Controller must retain/diagnose this infrastructure evidence before terminal gates; it is not a passing cleanup result. Preflight expected5/actual7 shard mismatch is an explicit deviation for controller readiness/cost closure. No rerun was performed by this reviewer.

Additional named check: KEK-path diagnostic acceptance checked real credential-crypto.ts:37–45: undefined path rejects through resolve(path); it cannot reach provider execution. Whitespace acceptance is a configuration convenience outside the declared task contract, explicitly accepted rather than claimed equivalent.

Repair I1 using a genuine root Drizzle transaction and nested transaction handle, preserving the account/vendor lock through global warnings. Deterministic real-DB tests should assert lock retention after the first company write, failure on a later warning, and no open transaction after failed/excluded drains; a real SQL trigger/constraint may inject the later database failure without owned mocks. Inspect actual warnings/notices rather than discarding transaction warnings.

Repair I2 with bounded real oracles: invalid Date and prefix/suffix invalid UUID reject before credentials/network; targeted unsupported protocol rejects and unsupported-only global invocation returns exactly processed0 without KEK; limiter clock affects real retry/backoff behavior; global warning entity attribution persists; transaction commit/rollback/cleanup properties survive repeated resource reuse. The deferred test seam must execute the real services-backed handler, assert exact successfulJob processed and resource close after success and failure, and reject a bypassed drain. Existing integration assertions can be reused through test imports without duplicated owned implementation, router changes or configuration changes. The 19 genuine entries must be killed or explicitly reassessed on their exact new locations after repair; no broad coverage-only tests are requested.

**Final spec verdict: Issues found. Final task-quality verdict: Needs fixes.** Two Important findings (one runtime defect, one mutation-oracle closure), one Minor formatting finding, zero Critical. Reviewer task3_review; report-only mutation, no production/index/HEAD changes, no new test run.
