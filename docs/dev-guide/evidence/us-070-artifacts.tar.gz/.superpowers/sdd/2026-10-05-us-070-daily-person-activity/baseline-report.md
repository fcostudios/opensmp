# US-070 baseline verification

Worktree: /Users/fcolomas/.codex/worktrees/us-070-activity/smp

- Docker prerequisite: daemon reachable, server 29.7.2; exit 0.
- Frozen install: `pnpm install --frozen-lockfile`; exit 0; 871 packages installed. Optional cpu-features install reported `node-gyp: command not found`; install still succeeded.
- Baseline command: `pnpm test`, executed once; exit 0.
- Turbo: 15 successful tasks, all 15 cache hits (shared worktree cache); no fresh test execution. Cached logs originate from the prior smp-chg067 worktree.
- Replayed test totals: 206 passed files and 3 skipped files; 2714 passed tests and 12 skipped tests. Config package has no test files and exits 0.
- Named code failures: none reported. Infrastructure failures: none reported; Docker fixture execution was not exercised because every task was cached.
- No production/test edits, environment configuration, or duplicate gates performed.

Full install and baseline output: `baseline.log` alongside this report.

## Own agent cost provenance

CODEX_THREAD_ID: 01a10edb-d11d-7561-98f3-1a66f4e82385
Own rollout file: /Users/fcolomas/.codex/sessions/2026/10/05/rollout-2026-10-05T20-37-29-01a10edb-d11d-7561-98f3-1a66f4e82385.jsonl
Measured tool-call/output/context-window metadata: unavailable from an independently identified own-agent transcript. Shared parent transcript was not read; no measurements invented.
