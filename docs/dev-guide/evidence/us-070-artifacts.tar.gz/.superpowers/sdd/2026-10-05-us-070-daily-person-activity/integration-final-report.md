# US-070 final covering gate

**PASS.** One authorized full `pnpm check` at `e03e465e3e8be975bcaf8ca05662f0bf93bfb25a` (idle guard `caffeinate -i`), mutation base `ed9ff60d9dda6aaf78fae5e9a61d189b1a8e4108`, work ID **US-070**. Check exit **0**, **202.404 seconds**; fixture-owning invocation **205.375 seconds**, `2026-10-06T05:05:17.135Z–2026-10-06T05:08:42.510Z`.

Stale-container/preflight passed. Type-check **9/9** (8 cached), lint **8/8** (8 cached), test tasks **15/15** (13 cached), build **9/9** (7 cached) passed. Constituent durations were not separately instrumented, except Turbo reports build **17.873 seconds**. Fresh worker and web build completed; Next.js used **`next build --webpack`**, compiled in **4.9 seconds**, and generated the production route output.

| Suite | Files | Tests | Execution |
|---|---|---|---|
| worker | 18 passed /2 skipped | 192 passed /8 skipped | fresh |
| db | 24 passed | 309 passed | fresh |
| web | 120 passed | 926 passed /3 skipped | cached |
| ui | 9 passed | 35 passed | cached |
| contracts | 12 passed | 127 passed | cached |
| domain | 11 passed | 530 passed | cached |
| connectors | 12 passed | 644 passed | cached |
| notifications | 3 passed /1 skipped | 21 passed /1 skipped | cached |

Current ordinary fixture-scoped preflight exit **0 /0.754 seconds** confirms the exact **seven** prior shards. `apps/worker/src/runtime.integration.test.ts` appears in **none** of their sources or selected `testFiles`; thus **0 touched source/test-seam previews**, **0 preview minutes** for the runtime-only fix, and **all seven previous shards retained**. No blanket re-preview was run. The expected5/actual7 mismatch remains visible for controller reconciliation; it was not hidden or used to drop shards. Authoritative current manifest: `integration-final-current-preflight-manifest.json`, SHA-256 `4375b68d388386f1fa721bc95a1ce69f431b7f7fc29168bc8a354fb5db6255a2`. Two earlier standalone diagnostic probes were non-authoritative (one omitted the pinned base; one lacked the fixture runtime profile); only the successful fixture-scoped manifest supports this result.

Runtime composition matches the delivered commands: child `SMP_TEST_POSTGRES_CLUSTER_URL` absent, web wrapper owns its package test cluster, DB/worker use delivered Vitest defaults. Check/build owner/app URLs came from one scoped fixture on an owned cluster. The fixture setup committed-migration apply passed **0 /0.547 seconds**. Independent prior fresh apply/verify/parity evidence remains in `integration-results.json` and was preserved, not repeated.

**Cleanup verified:** scoped fixture and owned cluster stops succeeded; immediate inventory briefly retained one ID, independent recheck confirms **all owned IDs absent**. Only the two preexisting nous containers run. No unrelated container was removed. Exact-window power log contains **no Sleep/Wake/DarkWake events**; before/after snapshots are retained. Idle protection does not imply prevention of thermal emergency sleep.

Evidence:

- `integration-final-check-db-apply.log`: exit 0 /0.547 seconds; SHA-256 `d94547ff57830639c06c9a0acff64c9e23d183af2c55a4f013fb10f0d366fd25`.
- `integration-final-preflight.log`: exit 0 /0.754 seconds; SHA-256 `76a6a03a35d870a32774e6f2e1ca916b6b3295052a71e227ad5de500501732db`.
- `integration-final-pnpm-check.log`: exit 0 /202.404 seconds; SHA-256 `966904686dd5a04edcbe3003f1b5cffffe59e2647a64fc1013306a96887fba8c`.
- `integration-final-results.json`: exact cutoff, stages, scope, suite/build counts, ownership and power results.
- `integration-final-before.json` /`integration-final-after.json`: bounded resource snapshots.
- `integration-final-power-window.log`: SHA-256 `940ae0c0e1c04c3ee5a51f7c708717e07d9d13c34e551fb7ac2e7bbdc245f6dd`.
- Earlier failure reports and logs are preserved unchanged.

No source/test/config/harness edits, cache clear, cold campaign, or additional gate rerun occurred. The one authoritative cold campaign awaits separate controller authorization after this green gate.

Own metadata: `CODEX_THREAD_ID` `01a10f8a-3a6a-7b00-b35d-789a5c95c49d`; filename-only rollout pointer `/Users/fcolomas/.codex/sessions/2026/10/05/rollout-2026-10-05T23-47-59-01a10f8a-3a6a-7b00-b35d-789a5c95c49d.jsonl`. Token/cost metadata is unavailable to the agent. This covering turn through report write used **12 functions.exec calls +3 functions.wait calls**, **11 nested exec_command calls +3 write_stdin calls**; local counts are not controller-session totals.
