 and file ownership

Task 1 adds shared contract primitives without changing the existing `ActivitySnapshot` yet, keeping that commit independently green. Task 2 switches the snapshot and provider/dispatch together. Task 3 consumes both. `contracts.ts` is the only shared edit across implementation tasks; reviews are sequential.

The common fields and names are binding. Database driver types must accept the existing Drizzle application client and worker PostgreSQL transaction; infer the narrow common type from Drizzle rather than creating a second connection or using type assertions to hide incompatibility.

```ts
export type IngestionSource = "api" | "csv_import" | "manual";
export type ActivityIngestionRecord = Readonly<{
  email: string | null;
  providerUserId: string | null;
  activityDate: string;
  counters: JsonValue;
}>;
export type ActivityIdentityWarning = Readonly<{
  recordIndex: number;
  reason: "missing_email" | "unmatched_email";
  email: string | null;
  providerUserId: string | null;
}>;
export type ActivityBatch = Readonly<{
  companyId: string;
  vendorAccountId: string;
  activityDate: string;
  source: IngestionSource;
  syncedAt: Date;
  actorUserAccountId: string | null;
  records: readonly ActivityIngestionRecord[];
}>;
export type ActivityBatchResult = Readonly<{
  written: number;
  ignored: number;
  warnings: readonly ActivityIdentityWarning[];
}>;
// db parameter: the narrow common Drizzle database/transaction type described above.
// ingestActivityBatch(db, batch: ActivityBatch): Promise<ActivityBatchResult>
// resolveActivityScopes(db, companyIds: readonly string[], records: readonly ActivityIngestionRecord[]):
//   Promise<{ batches: readonly { companyId: string; records: readonly ActivityIngestionRecord[] }[];
//             warnings: readonly ActivityIdentityWarning[] }>
// normalizeActivityCounters(value: unknown): JsonValue
```

`resolveActivityScopes` is an internal scheduled-worker helper receiving trusted company IDs, never public caller input. Every Person query contains a `company_id` predicate. It matches each record once and reports warnings only after checking all authorized scopes. `ingestActivityBatch` never searches outside its one company. Both use the same email normalizer/matcher. Reject multiple matches/conflicting identities instead of choosing collection order. It is permissible to lock/recheck Person scope during transactional persistence so movement cannot cause a foreign-company write.

Replay is reconstructed by the database boundary as `{version:1,vendorAccountId,activityDate,source,identity:{email,providerUserId},counters}`. Never accept an arbitrary caller replay blob. The snapshot contains validated identity/counters sufficient to reconstruct this payload, rather than a second independently mutable raw representation.

