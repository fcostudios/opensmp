**Important I1 — duplicate key namespace collision** — ADDRESSED. `packages/db/src/analytics-ingestion.ts:73` tags emails with `email:` and provider-only identities with `provider:`. Their distinct prefixes cannot collide; the date suffix has fixed validated ISO format. Regression `analytics-ingestion.integration.test.ts:259` asserts both consumers, missing warning, independent routing, persisted counters/Person scope and warning audit.

## New breakage in the fix diff

None.

## Important remaining mutation oracle gap M1

New survivor #137, `analytics-ingestion.ts:73:22`, replacement `false`, is NOT equivalent or accepted. It forces all identities through provider fallback. Same-email/date records with null provider IDs become unkeyed, so equivalent duplicates cease to collapse in resolveActivityScopes and contradictory duplicates cease to reject during validation. Distinct provider IDs with the same email produce separate keys and evade ACTIVITY_DUPLICATE_CONFLICT. The providerIds map at lines69–71 cannot recover email deduplication. This requires a bounded oracle; it is not a defect in the ordinary fixed code. No test was added or repeated.

## Out-of-scope observations

None newly observed; the prior minor polling-bound observation remains non-blocking.

## Checks and verdict

Read supplied diff once, brief, fix report, prior review, latest preview and constraints.md (controller corrected requested global-constraints.md name). Actual focused GREEN log confirms one file,16/16 passed,3.58s; the report identifies namespace RED and covering ingestion GREEN. Diff supports these claims. No production/index/HEAD mutations or suite reruns.

**Fix round:** all findings addressed, no new Critical/Important code breakage. **Mutation closure NOT APPROVED:** Important M1 remains open.

## Current exact residual annotations

Current ingestion JSON: reports/mutation/vitest-7e4dfff580cb-64362-1791255390742-3a81a796526b18.json. Independently matched each retained ingestion ID to current exact location/status/replacement. Re-evaluated semantics: normalized fixed-order counter trees, null-map behavior, stronger locks, query existence and conflict-row guarantees are unchanged by namespace prefixes. Schema/contracts approvals retained as directed. The two identical false replacements at line37 are distinct whole-expression/typeof-term mutants, retained individually.

**Counts:**34 residuals:24 equivalent,9 accepted,1 unapproved. Ingestion25:19 equivalent,5 accepted,1 unapproved (23 Survived/2 NoCoverage). Schema1 equivalent. Contracts8:4 equivalent,4 accepted.

5 packages/db/src/schema.ts:479:28 Survived replacement="\"\"" @equivalent: Drizzle ColumnBuilder.setName replaces an empty name with the source property key; mapping and generated SQL remain source.

85 packages/db/src/analytics-ingestion.ts:52:36 NoCoverage replacement="``" @equivalent: array canonical representation is unreachable for normalized allowlisted nullable integer/object counters.

86 packages/db/src/analytics-ingestion.ts:52:66 NoCoverage replacement="\"\"" @equivalent: array separator is unreachable because normalized counter trees contain no arrays.

24 packages/db/src/analytics-ingestion.ts:37:7 Survived replacement="false" @accepted: Exact ISO roundtrip preserves rejection and acceptance for JSON date inputs; malformed non-JSON Symbol/coercion values can change diagnostics, which the date contract does not specify. This is narrowly accepted, not literal equivalence.

25 packages/db/src/analytics-ingestion.ts:37:7 Survived replacement="typeof value !== \"string\" && !/^\\d{4}-\\d{2}-\\d{2}$/.test(value)" @accepted: Exact ISO roundtrip preserves rejection and acceptance for JSON date inputs; malformed non-JSON Symbol/coercion values can change diagnostics, which the date contract does not specify. This is narrowly accepted, not literal equivalence.

26 packages/db/src/analytics-ingestion.ts:37:7 Survived replacement="false" @accepted: Exact ISO roundtrip preserves rejection and acceptance for JSON date inputs; malformed non-JSON Symbol/coercion values can change diagnostics, which the date contract does not specify. This is narrowly accepted, not literal equivalence.

30 packages/db/src/analytics-ingestion.ts:37:37 Survived replacement="/\\d{4}-\\d{2}-\\d{2}$/" @equivalent: removing the regex start anchor cannot bypass exact ISO-date equality against the whole original string.

31 packages/db/src/analytics-ingestion.ts:37:37 Survived replacement="/^\\d{4}-\\d{2}-\\d{2}/" @equivalent: removing the regex end anchor cannot bypass exact ISO-date equality against the whole original string.

75 packages/db/src/analytics-ingestion.ts:51:7 Survived replacement="true" @equivalent: duplicate counters were reconstructed in deterministic allowlist key order; JSON.stringify of that complete tree has the same equality relation as recursive canonical encoding.

79 packages/db/src/analytics-ingestion.ts:51:7 Survived replacement="value !== null" @equivalent: normalized counter roots are nonnull objects, so this mutation serializes the complete deterministically ordered tree and preserves duplicate equality.

81 packages/db/src/analytics-ingestion.ts:51:25 Survived replacement="typeof value === \"object\"" @equivalent: serializing the complete normalized object tree preserves all nullable integer values and duplicate equality because reconstruction fixes key order.

82 packages/db/src/analytics-ingestion.ts:51:42 Survived replacement="\"\"" @equivalent: replacing the object type string makes the root serialize directly; normalized key order and full-tree duplicate equality remain deterministic.

84 packages/db/src/analytics-ingestion.ts:52:7 Survived replacement="false" @equivalent: counter normalization rejects arrays on every known path, so canonical never receives an array.

88 packages/db/src/analytics-ingestion.ts:53:14 Survived replacement="Object.entries(value)" @equivalent: normalization reconstructs every object in a fixed allowlist order, so removing canonical sorting cannot change duplicate equality.

89 packages/db/src/analytics-ingestion.ts:53:41 Survived replacement="() => undefined" @equivalent: retaining the reconstructed object order instead of sorting preserves deterministic equality for supported counter trees.

92 packages/db/src/analytics-ingestion.ts:54:77 Survived replacement="\"\"" @equivalent: removing the canonical object comma remains injective for fixed quoted allowlisted keys and nullable integer/object values; this encoding is used only for equality and is never persisted.

149 packages/db/src/analytics-ingestion.ts:75:22 Survived replacement="false" @equivalent: null duplicate keys are never stored in emails, so emails.get(null) still yields undefined.

163 packages/db/src/analytics-ingestion.ts:81:9 Survived replacement="true" @equivalent: storing an unused null Map key is unobservable because lookup explicitly skips null keys and the local Map is not returned.

166 packages/db/src/analytics-ingestion.ts:87:88 Survived replacement="true" @accepted: defaulting global read matching to shared locks preserves identity decisions and scope safety but may add contention; stronger locking is permitted and no latency/read-lock contract is specified.

228 packages/db/src/analytics-ingestion.ts:134:21 Survived replacement="{}" @equivalent: FOR SHARE without OF locks all relations in this two-table account/vendor query, the same set as its explicit OF list.

238 packages/db/src/analytics-ingestion.ts:136:39 Survived replacement="{}" @equivalent: company selection is consumed only as row existence; selecting an empty object preserves that existence result and row lock.

245 packages/db/src/analytics-ingestion.ts:139:37 Survived replacement="{}" @equivalent: actor selection is consumed only as row existence; its selected ID is never used, so empty-object selection preserves actor verification and lock.

298 packages/db/src/analytics-ingestion.ts:163:13 Survived replacement="false" @equivalent: a suppressed conditional upsert holds the existing key row with synced_at >= incoming; Person scope is locked, so the follow-up current row exists and cannot be older.

299 packages/db/src/analytics-ingestion.ts:163:13 Survived replacement="!current && current.syncedAt.getTime() < batch.syncedAt.getTime()" @equivalent: PostgreSQL conflict row locking plus the upsert timestamp predicate guarantee current exists and is at least as new, leaving the equal-contradiction check unchanged.

301 packages/db/src/analytics-ingestion.ts:163:25 Survived replacement="false" @equivalent: current.synced_at < incoming is unreachable after this upsert returns no row under the held conflict-row lock.

29 packages/connectors/src/contracts.ts:202:9 Survived replacement="false" @accepted: removing the null precheck still rejects root null via Object.getPrototypeOf(null); only Error subtype/diagnostic changes, and the normalizer contract specifies rejection without a typed error payload.

37 packages/connectors/src/contracts.ts:204:23 Survived replacement="``" @accepted: invalid known objects still reject; the shared normalizer promises validation, not this prose diagnostic, and no production caller branches on its text.

55 packages/connectors/src/contracts.ts:213:13 Survived replacement="false" @equivalent: Number.isInteger alone rejects all nonnumber/nonfinite values, so removing the preceding typeof/finite disjunction preserves accepted counters and the same rejection path.

56 packages/connectors/src/contracts.ts:213:13 Survived replacement="typeof metric !== \"number\" && !Number.isFinite(metric)" @equivalent: changing typeof/finite OR to AND cannot admit extra values: unchanged Number.isInteger rejects every nonnumber, NaN and infinity; unchanged metric<0 rejects negative integers.

57 packages/connectors/src/contracts.ts:213:13 Survived replacement="false" @equivalent: Number.isFinite and Number.isInteger reject nonnumbers without coercion, preserving the same count rejection when the typeof term is removed.

66 packages/connectors/src/contracts.ts:215:27 Survived replacement="``" @accepted: malformed counts still reject at the same boundary; the untyped prose diagnostic is not a provider or ingestion failure discriminant.

67 packages/connectors/src/contracts.ts:218:54 Survived replacement="``" @accepted: recursive path text feeds only validation diagnostics; supported output and rejection behavior stay unchanged, and no caller branches on the path.

68 packages/connectors/src/contracts.ts:222:49 Survived replacement="\"\"" @accepted: initial counters path label affects only untyped validation diagnostics, not accepted metrics or rejection decisions.

137 packages/db/src/analytics-ingestion.ts:73:22 Survived replacement="false" @unapproved: provider fallback bypasses same-email duplicate collapse/conflict; Important M1.

## Fix round 2 — 9dea85c..4b91e690b49980c016b1db5dc66cecf0f199ec12

**Important M1 — email-key conditional survivor #137** — ADDRESSED by the bounded regression at `packages/db/src/analytics-ingestion.integration.test.ts:259–273`. Exact one-record normalized routing constrains duplicate collapse with null provider IDs; two rejection cases require ACTIVITY_DUPLICATE_CONFLICT for differing counters and distinct provider IDs through both consumers, with empty activity/audit rows. Actual `/tmp/us070-email-dedup-red.log` shows mutant #137 returns an extra routed record; `/tmp/us070-email-dedup-green.log` confirms17/17 passed in3.37s after restoration. Report names DB type-check pass. No tests rerun.

**New breakage:** None in the17-line test-only diff. Authorized A/B fixture scopes and real DB oracle retained; no production change. **Out-of-scope observations:** None new.

**Code review verdict:** all findings addressed, no new Critical/Important breakage. Current mutation confirmation pending controller round6 preview; previous round1 residual list above is historical until confirmed below.

## Round 2 final mutation confirmation and signed approval

Candidate4b91e690b49980c016b1db5dc66cecf0f199ec12. Independently read round6 JSON `reports/mutation/vitest-7e4dfff580cb-76617-1791255951894-7891b26d808e3.json`:296 Killed,22 Survived,2 NoCoverage,320 total;92.50%. Exact #137 is Killed. Current24 ingestion residual IDs, locations, statuses and replacements exactly match the remapped approved entries below; no new survivor. Prior equivalence/acceptance reasoning remains valid because this round changes only the covering regression. Schema/contracts approvals remain retained.

**Final verdict: Task1 spec and quality APPROVED.** I1 and M1 addressed; no open Critical/Important finding. All33 current residuals approved:24 equivalent,9 accepted,0 unapproved (ingestion19 equivalent/5 accepted; schema1 equivalent; contracts4 equivalent/4 accepted). Historical round1 #137 unapproved entry above is superseded by its confirmed Killed status. Controller owns authoritative campaign and broader application gates.

**Reviewer:** task1_rereview; signed scoped review of supplied fix and current residual evidence, no test reruns or production/index/HEAD changes.

### Final current annotation table (all33)

5 packages/db/src/schema.ts:479:28 Survived replacement="\"\"" @equivalent: Drizzle ColumnBuilder.setName replaces an empty name with the source property key; mapping and generated SQL remain source.

85 packages/db/src/analytics-ingestion.ts:52:36 NoCoverage replacement="``" @equivalent: array canonical representation is unreachable for normalized allowlisted nullable integer/object counters.

86 packages/db/src/analytics-ingestion.ts:52:66 NoCoverage replacement="\"\"" @equivalent: array separator is unreachable because normalized counter trees contain no arrays.

24 packages/db/src/analytics-ingestion.ts:37:7 Survived replacement="false" @accepted: Exact ISO roundtrip preserves rejection and acceptance for JSON date inputs; malformed non-JSON Symbol/coercion values can change diagnostics, which the date contract does not specify. This is narrowly accepted, not literal equivalence.

25 packages/db/src/analytics-ingestion.ts:37:7 Survived replacement="typeof value !== \"string\" && !/^\\d{4}-\\d{2}-\\d{2}$/.test(value)" @accepted: Exact ISO roundtrip preserves rejection and acceptance for JSON date inputs; malformed non-JSON Symbol/coercion values can change diagnostics, which the date contract does not specify. This is narrowly accepted, not literal equivalence.

26 packages/db/src/analytics-ingestion.ts:37:7 Survived replacement="false" @accepted: Exact ISO roundtrip preserves rejection and acceptance for JSON date inputs; malformed non-JSON Symbol/coercion values can change diagnostics, which the date contract does not specify. This is narrowly accepted, not literal equivalence.

30 packages/db/src/analytics-ingestion.ts:37:37 Survived replacement="/\\d{4}-\\d{2}-\\d{2}$/" @equivalent: removing the regex start anchor cannot bypass exact ISO-date equality against the whole original string.

31 packages/db/src/analytics-ingestion.ts:37:37 Survived replacement="/^\\d{4}-\\d{2}-\\d{2}/" @equivalent: removing the regex end anchor cannot bypass exact ISO-date equality against the whole original string.

75 packages/db/src/analytics-ingestion.ts:51:7 Survived replacement="true" @equivalent: duplicate counters were reconstructed in deterministic allowlist key order; JSON.stringify of that complete tree has the same equality relation as recursive canonical encoding.

79 packages/db/src/analytics-ingestion.ts:51:7 Survived replacement="value !== null" @equivalent: normalized counter roots are nonnull objects, so this mutation serializes the complete deterministically ordered tree and preserves duplicate equality.

81 packages/db/src/analytics-ingestion.ts:51:25 Survived replacement="typeof value === \"object\"" @equivalent: serializing the complete normalized object tree preserves all nullable integer values and duplicate equality because reconstruction fixes key order.

82 packages/db/src/analytics-ingestion.ts:51:42 Survived replacement="\"\"" @equivalent: replacing the object type string makes the root serialize directly; normalized key order and full-tree duplicate equality remain deterministic.

84 packages/db/src/analytics-ingestion.ts:52:7 Survived replacement="false" @equivalent: counter normalization rejects arrays on every known path, so canonical never receives an array.

88 packages/db/src/analytics-ingestion.ts:53:14 Survived replacement="Object.entries(value)" @equivalent: normalization reconstructs every object in a fixed allowlist order, so removing canonical sorting cannot change duplicate equality.

89 packages/db/src/analytics-ingestion.ts:53:41 Survived replacement="() => undefined" @equivalent: retaining the reconstructed object order instead of sorting preserves deterministic equality for supported counter trees.

92 packages/db/src/analytics-ingestion.ts:54:77 Survived replacement="\"\"" @equivalent: removing the canonical object comma remains injective for fixed quoted allowlisted keys and nullable integer/object values; this encoding is used only for equality and is never persisted.

149 packages/db/src/analytics-ingestion.ts:75:22 Survived replacement="false" @equivalent: null duplicate keys are never stored in emails, so emails.get(null) still yields undefined.

163 packages/db/src/analytics-ingestion.ts:81:9 Survived replacement="true" @equivalent: storing an unused null Map key is unobservable because lookup explicitly skips null keys and the local Map is not returned.

166 packages/db/src/analytics-ingestion.ts:87:88 Survived replacement="true" @accepted: defaulting global read matching to shared locks preserves identity decisions and scope safety but may add contention; stronger locking is permitted and no latency/read-lock contract is specified.

228 packages/db/src/analytics-ingestion.ts:134:21 Survived replacement="{}" @equivalent: FOR SHARE without OF locks all relations in this two-table account/vendor query, the same set as its explicit OF list.

238 packages/db/src/analytics-ingestion.ts:136:39 Survived replacement="{}" @equivalent: company selection is consumed only as row existence; selecting an empty object preserves that existence result and row lock.

245 packages/db/src/analytics-ingestion.ts:139:37 Survived replacement="{}" @equivalent: actor selection is consumed only as row existence; its selected ID is never used, so empty-object selection preserves actor verification and lock.

298 packages/db/src/analytics-ingestion.ts:163:13 Survived replacement="false" @equivalent: a suppressed conditional upsert holds the existing key row with synced_at >= incoming; Person scope is locked, so the follow-up current row exists and cannot be older.

299 packages/db/src/analytics-ingestion.ts:163:13 Survived replacement="!current && current.syncedAt.getTime() < batch.syncedAt.getTime()" @equivalent: PostgreSQL conflict row locking plus the upsert timestamp predicate guarantee current exists and is at least as new, leaving the equal-contradiction check unchanged.

301 packages/db/src/analytics-ingestion.ts:163:25 Survived replacement="false" @equivalent: current.synced_at < incoming is unreachable after this upsert returns no row under the held conflict-row lock.

29 packages/connectors/src/contracts.ts:202:9 Survived replacement="false" @accepted: removing the null precheck still rejects root null via Object.getPrototypeOf(null); only Error subtype/diagnostic changes, and the normalizer contract specifies rejection without a typed error payload.

37 packages/connectors/src/contracts.ts:204:23 Survived replacement="``" @accepted: invalid known objects still reject; the shared normalizer promises validation, not this prose diagnostic, and no production caller branches on its text.

55 packages/connectors/src/contracts.ts:213:13 Survived replacement="false" @equivalent: Number.isInteger alone rejects all nonnumber/nonfinite values, so removing the preceding typeof/finite disjunction preserves accepted counters and the same rejection path.

56 packages/connectors/src/contracts.ts:213:13 Survived replacement="typeof metric !== \"number\" && !Number.isFinite(metric)" @equivalent: changing typeof/finite OR to AND cannot admit extra values: unchanged Number.isInteger rejects every nonnumber, NaN and infinity; unchanged metric<0 rejects negative integers.

57 packages/connectors/src/contracts.ts:213:13 Survived replacement="false" @equivalent: Number.isFinite and Number.isInteger reject nonnumbers without coercion, preserving the same count rejection when the typeof term is removed.

66 packages/connectors/src/contracts.ts:215:27 Survived replacement="``" @accepted: malformed counts still reject at the same boundary; the untyped prose diagnostic is not a provider or ingestion failure discriminant.

67 packages/connectors/src/contracts.ts:218:54 Survived replacement="``" @accepted: recursive path text feeds only validation diagnostics; supported output and rejection behavior stay unchanged, and no caller branches on the path.

68 packages/connectors/src/contracts.ts:222:49 Survived replacement="\"\"" @accepted: initial counters path label affects only untyped validation diagnostics, not accepted metrics or rejection decisions.
