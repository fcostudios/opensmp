# Task 1 survivor candidates for independent review

IDs below are from the round-2 shard reports. These are unapproved candidates; the controller's next preview determines the residual set. New tests target the other observable survivors. No error text is classified as strictly equivalent when its diagnostic changes.

5 packages/db/src/schema.ts:479 @equivalent: Drizzle ColumnBuilder.setName replaces an empty name with the source property key; mapping and generated SQL remain source.
29 packages/connectors/src/contracts.ts:202 @accepted: removing the null precheck still rejects root null via Object.getPrototypeOf(null); only Error subtype/diagnostic changes, and the normalizer contract specifies rejection without a typed error payload.
37 packages/connectors/src/contracts.ts:204 @accepted: invalid known objects still reject; the shared normalizer promises validation, not this prose diagnostic, and no production caller branches on its text.
55 packages/connectors/src/contracts.ts:213 @equivalent: Number.isInteger alone rejects all nonnumber/nonfinite values, so removing the preceding typeof/finite disjunction preserves accepted counters and the same rejection path.
57 packages/connectors/src/contracts.ts:213 @equivalent: Number.isFinite and Number.isInteger reject nonnumbers without coercion, preserving the same count rejection when the typeof term is removed.
66 packages/connectors/src/contracts.ts:215 @accepted: malformed counts still reject at the same boundary; the untyped prose diagnostic is not a provider or ingestion failure discriminant.
67 packages/connectors/src/contracts.ts:218 @accepted: recursive path text feeds only validation diagnostics; supported output and rejection behavior stay unchanged, and no caller branches on the path.
68 packages/connectors/src/contracts.ts:222 @accepted: initial counters path label affects only untyped validation diagnostics, not accepted metrics or rejection decisions.
24 packages/db/src/analytics-ingestion.ts:37 @equivalent: the finite-date ISO roundtrip subsequently enforces exact YYYY-MM-DD string equality and the same ACTIVITY_INVALID_DATE rejection for malformed JSON date values.
25 packages/db/src/analytics-ingestion.ts:37 @equivalent: changing the format/type precheck to AND cannot admit a malformed JSON date because the following finite ISO roundtrip must equal the original string.
26 packages/db/src/analytics-ingestion.ts:37 @equivalent: the following ISO roundtrip independently rejects noncanonical JSON dates with ACTIVITY_INVALID_DATE.
30 packages/db/src/analytics-ingestion.ts:37 @equivalent: removing the regex start anchor cannot bypass exact ISO-date equality against the whole original string.
31 packages/db/src/analytics-ingestion.ts:37 @equivalent: removing the regex end anchor cannot bypass exact ISO-date equality against the whole original string.
75 packages/db/src/analytics-ingestion.ts:51 @equivalent: duplicate counters were reconstructed in deterministic allowlist key order; JSON.stringify of that complete tree has the same equality relation as recursive canonical encoding.
79 packages/db/src/analytics-ingestion.ts:51 @equivalent: normalized counter roots are nonnull objects, so this mutation serializes the complete deterministically ordered tree and preserves duplicate equality.
81 packages/db/src/analytics-ingestion.ts:51 @equivalent: serializing the complete normalized object tree preserves all nullable integer values and duplicate equality because reconstruction fixes key order.
82 packages/db/src/analytics-ingestion.ts:51 @equivalent: replacing the object type string makes the root serialize directly; normalized key order and full-tree duplicate equality remain deterministic.
84 packages/db/src/analytics-ingestion.ts:52 @equivalent: counter normalization rejects arrays on every known path, so canonical never receives an array.
85 packages/db/src/analytics-ingestion.ts:52 @equivalent: array canonical representation is unreachable for normalized allowlisted nullable integer/object counters.
86 packages/db/src/analytics-ingestion.ts:52 @equivalent: array separator is unreachable because normalized counter trees contain no arrays.
88 packages/db/src/analytics-ingestion.ts:53 @equivalent: normalization reconstructs every object in a fixed allowlist order, so removing canonical sorting cannot change duplicate equality.
89 packages/db/src/analytics-ingestion.ts:53 @equivalent: retaining the reconstructed object order instead of sorting preserves deterministic equality for supported counter trees.
92 packages/db/src/analytics-ingestion.ts:54 @equivalent: removing the canonical object comma remains injective for fixed quoted allowlisted keys and nullable integer/object values; this encoding is used only for equality and is never persisted.
146 packages/db/src/analytics-ingestion.ts:75 @equivalent: null duplicate keys are never stored in emails, so emails.get(null) still yields undefined.
160 packages/db/src/analytics-ingestion.ts:81 @equivalent: storing an unused null Map key is unobservable because lookup explicitly skips null keys and the local Map is not returned.
163 packages/db/src/analytics-ingestion.ts:87 @accepted: defaulting global read matching to shared locks preserves identity decisions and scope safety but may add contention; stronger locking is permitted and no latency/read-lock contract is specified.
225 packages/db/src/analytics-ingestion.ts:134 @equivalent: FOR SHARE without OF locks all relations in this two-table account/vendor query, the same set as its explicit OF list.
235 packages/db/src/analytics-ingestion.ts:136 @equivalent: company selection is consumed only as row existence; selecting an empty object preserves that existence result and row lock.
242 packages/db/src/analytics-ingestion.ts:139 @equivalent: actor selection is consumed only as row existence; its selected ID is never used, so empty-object selection preserves actor verification and lock.
295 packages/db/src/analytics-ingestion.ts:163 @equivalent: a suppressed conditional upsert holds the existing key row with synced_at >= incoming; Person scope is locked, so the follow-up current row exists and cannot be older.
296 packages/db/src/analytics-ingestion.ts:163 @equivalent: PostgreSQL conflict row locking plus the upsert timestamp predicate guarantee current exists and is at least as new, leaving the equal-contradiction check unchanged.
298 packages/db/src/analytics-ingestion.ts:163 @equivalent: current.synced_at < incoming is unreachable after this upsert returns no row under the held conflict-row lock.

56 packages/connectors/src/contracts.ts:213 @equivalent: changing typeof/finite OR to AND cannot admit extra values: unchanged Number.isInteger rejects every nonnumber, NaN and infinity; unchanged metric<0 rejects negative integers.
