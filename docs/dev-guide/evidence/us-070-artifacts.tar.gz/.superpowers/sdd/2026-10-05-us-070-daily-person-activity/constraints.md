
- Persist one row per `(vendor_account_id, person_id, activity_date)`.
- Resolve email case-insensitively against `Person` with a real `company_id` predicate.
- Account IDs constrain the account/date natural key and do not grant company authority.
- Manual/CSV accounts are excluded before credential reads and provider calls, including explicitly targeted worker runs.
- For scheduled `at`, the observed activity day is the UTC calendar date minus three days.
- Missing/nullable metrics are preserved as unknown, never invented as zero.
- Full provider bodies, request headers and credentials are never persisted.
- Keep company batch writes and their audit summary in one transaction.
- Do not overwrite a row with an older sync instant; newer reruns refresh it.
- Contradictory values at an equal instant must fail rather than make worker scheduling determine the data.
- CSV/manual entry flows remain US-055; costs remain US-071; freshness UI remains US-029. No new screen, public route, queue, lease table or executable verification tooling.
- Migrations are append-only. Use committed-migration apply/verify/parity, never schema push.
- Before any test edit read `docs/dev-guide/TESTING.md` and `docs/TEST_EFFECTIVENESS_STANDARD.md`. Use real database fixtures and Pact-backed external transports; do not mock owned modules. Assertions must constrain named ACs or mutants, including tenant isolation.
- All shell commands start with `rtk`; work in the approved feature workspace. Read `CLAUDE.md`, `docs/dev-guide/local/CLAUDE.md` and applicable nested AGENTS files before edits.
- At every task boundary assess remaining work against the approved 270 minutes. If predicted work exceeds the estimate, emit `blocked` or `deviation` and reassess before continuing; no timestamp-based deadline.
- After each committed implementation task/fix: run ordinary mutation preflight, intersect its returned shard `sources` with changed production sources, preview only those exact shard IDs, and repair genuine survivors before review. No preview `test_report`. Record preview rounds/minutes.

