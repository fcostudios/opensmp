# US-070 Task 1 implementation report

Status: implemented, verified, self-reviewed and committed as `446feb7` (`feat(US-070): add source-aware activity ingestion`). Mutation previews and independent review remain controller-owned.

## Delivery and ownership

- `packages/connectors/src/contracts.ts`: additive `IngestionSource`, `ActivityIngestionRecord`, `ActivityIdentityWarning`, and allowlisted `normalizeActivityCounters`; preserves the existing `ActivitySnapshot` and other callers.
- `packages/db/src/schema.ts`: independent account `ingestionMode`, activity `source`, shared ingestion enum, and existing committed natural-key constraint reflected in Drizzle.
- `packages/db/src/migrations/V20261006013000__analytics_activity_ingestion.sql`: append-only SQL; existing accounts default/backfill manual; existing activity defaults API; only four activity refresh columns gain UPDATE permission. No committed migration was changed. Timestamp uniqueness checked: no duplicates.
- `packages/db/src/analytics-ingestion.ts`: validates complete batches, canonical duplicate checks, company-filtered matching and global authorized routing, account/Person/company/actor row locks, real conditional PostgreSQL upsert, PostgreSQL JSONB replay comparison, and atomic scoped warning/summary audit persistence. No connection created here. Narrow `Pick<PgDatabase<PgQueryResultHKT, typeof schema>, ...>` accepts PostgreSQL query builders/transactions without a driver compatibility cast.
- `packages/db/package.json`: exports `./analytics-ingestion`.
- `packages/db/src/analytics-ingestion.integration.test.ts`: real committed migrations and ledger_app runtime connection; owner only seeds, inspects privileges, and controls the audit grant fault. Deterministic identities/dates. Ten behavioral tests, each names the fault it catches.
- Controller-authorized additional path: `packages/db/scripts/verify-schema.mjs`, four expected activity UPDATE column grants only. Verifier behavior and exact key/DELETE restrictions stay strict.

The controller-owned `.nous-feedback.jsonl` was not edited or staged by this agent. No subagents, authoritative campaign, preview, test_report, or done event was emitted.

## Controller rulings

1. The brief proposed two Persons with the same normalized email across companies, but the existing global `uq_person_lower_email` forbids that fixture. Controller ruled to preserve global uniqueness, seed distinct emails, submit company B's email in a company A batch and assert unmatched/no foreign writes, and group both authorized companies once globally. No whitespace-only fixture workaround or schema change was used.
2. The schema verifier hard-codes the exact privilege matrix. Controller authorized adding the four grant declarations to that verifier as required migration metadata; cost if wrong is verifier-map rework and rejected schema verification.

## TDD and diagnostics

Before test edits, read AGENTS, CLAUDE, local guide, TESTING, Test Effectiveness Standard, TDD SKILL and writing-good-tests. Used systematic-debugging for unexpected fixture/system-actor/parity failures. `rtk pnpm readiness:check -- US-070` passed: readiness valid.

1. Initial RED: `rtk pnpm --filter @smp/db exec vitest run src/analytics-ingestion.integration.test.ts` exited 1, missing `./analytics-ingestion`. This was the expected missing-feature diagnostic from the requested brief, not infrastructure failure. Tests existed before production edits.
2. First real fixture run exposed fixture parameter $3 reused as enum and text: `inconsistent types deduced for parameter $3`. Corrected fixture SQL casts (`$3::text`, `$3::text::vendor_account_mode_enum`); no production change for this fixture error.
3. Next run: 7 failed / 2 passed, `ACTIVITY_ACTOR_NOT_FOUND`. Traced to committed system-settings migration: pinned system actor is intentionally disabled. Corrected verification to recognize the pinned ID/email and require active status for human actors. Kept real seeded system identity intact.
4. Next run: 8 passed / 1 failed, `ACTIVITY_IDENTITY_CONFLICT` in global-routing fixture. Distinct warning identities had incorrectly reused user-a provider ID. Corrected fixture IDs; conflict rejection retained.
5. Focused suite GREEN: 9 tests passed. Later strengthened existing assertions to prove a later equal conflict rolls back an earlier company A row and added a committed-history backfill test; 10 focused tests passed in 4.51s.
6. Additional named RED: `rtk pnpm --filter @smp/db exec vitest run src/analytics-ingestion.integration.test.ts -t 'validates full batches' > /tmp/us070-identity-red.log 2>&1` exited 1, contradictory duplicate null-email records with the same provider ID resolved with warnings instead of rejecting. Added provider-ID fallback only for duplicate detection; provider ID never matches Person. Equivalent identified missing-email duplicates collapse; contradictory ones reject before writes.
7. Migration metadata RED: focused fresh parity failed at exact ledger_app column-grant matrix (`counters UPDATE` unexpected). Added the controller-authorized four grant declarations.
8. Bare `rtk pnpm --filter @smp/db db:parity` exited 1 because DATABASE_ADMIN_URL was unset. Used the existing real owner/app fresh-parity fixture instead; did not count unset-env failure as parity evidence.
9. First full `rtk pnpm --filter @smp/db test` exited 1 with exactly two parity tests failing: `matches a fresh drizzle-kit push exactly`, `disposable push URL wins over a conflicting local env file`. Targeted reproduction saved `/tmp/us070-parity.log`; parsed JSON showed only `columns` differed. PostgreSQL ALTER appended source after synced_at and ingestion_mode after updated_by; Drizzle put them earlier. Moved new schema declarations to the appended positions, keeping SQL unchanged and preserving parity checker strictness.
10. Corrected narrow gate: `rtk pnpm --filter @smp/db exec vitest run src/analytics-ingestion.integration.test.ts src/migration-release.integration.test.ts -t 'refreshes|rejects contradictory|serializes|retains scoped|holds API|validates full|permits refresh|defaults both|normalizes allowlisted|backfills existing|matches a fresh drizzle-kit push exactly|disposable push URL wins over a conflicting local env file' > /tmp/us070-focused-green.log 2>&1` passed: 2 files, 13 passed, 112 skipped, 9.59s. This includes all 10 ingestion tests, both previously failing parity fixtures, and an existing matching-name migration test. Real parity runs committed migrations, verifies ledger_app privileges, and compares to a fresh disposable Drizzle database.
11. Final `rtk pnpm --filter @smp/db type-check` and `rtk pnpm --filter @smp/connectors type-check` passed, including after all changes.
12. `rtk git diff --check` passed.
13. Justified full package rerun: `rtk pnpm --filter @smp/db test > /tmp/us070-db-green.log 2>&1` passed: 24 files / 301 tests, 203.44s. Only repeated because named package parity failures were corrected.
14. Final boundary refinement: first natural-key call executes inside a real outer PostgreSQL transaction, passing its transaction object directly to ingestion; subsequent refresh uses a function assignment typed to `typeof import("./index").db` to prove compatibility with the actual application database union. An initial test-helper call incorrectly tried to pass a transaction to the full application-client type (requires `$client`) and type-check reported that test-only mismatch; corrected call sites to exercise each intended type separately. Final DB type-check passed; final focused suite passed 10/10 in 6.18s (`rtk pnpm --filter @smp/db exec vitest run src/analytics-ingestion.integration.test.ts > /tmp/us070-final-focused.log 2>&1`). No production driver cast or connection was added.
15. `rtk git add` staged exactly the seven delivery paths; `rtk git commit -m 'feat(US-070): add source-aware activity ingestion'` succeeded, `446feb7`. Controller-owned `.nous-feedback.jsonl` remains the sole unstaged modification.

## Behavioral and privilege evidence

- Newer replay refreshes counters/time/source/raw replay and preserves UUID; older and equal-equivalent retries ignore and preserve persisted data. Equal contradiction rejects and rolls back earlier rows and all audit changes.
- Concurrent equivalent calls produce one written/one ignored row; concurrent equal contradictions have one successful and one rejected transaction. Two vendor accounts retain independent natural keys.
- Foreign-only company B identity in A returns unmatched without foreign Person data or activity writes; null email is missing_email; scoped warnings and company audit summaries persist atomically. Global authorized A/B routing emits each matched identity once and only true unmatched/null warnings.
- API batch after account ingestion has been disabled returns ignored with no activity rows. CSV/manual persist regardless of account ingestion mode; all three sources retain explicit provenance and reconstruct only safe version-1 replay. Unknown counters/headers are removed, nullable/missing values stay unknown.
- Invalid full batches write neither activity nor audit. Duplicate normalized identities and conflicting provider IDs reject; equivalent duplicate identities collapse.
- Actual ledger_app updates of id/vendor_account_id/person_id/activity_date and DELETE each return SQLSTATE 42501. Real upsert succeeds using only counters/raw_payload/source/synced_at grants.
- Owner temporarily revokes audit INSERT; ingestion fails, and row/audit snapshots are unchanged; INSERT restored in finally.
- Both newly seeded provisioning modes default manual. Dedicated legacy test builds committed migration prefix, seeds automated/orchestration accounts, applies the complete committed set, and asserts manual backfill in both modes. No existing migration is altered.

## Self-review and boundaries

Reviewed transaction scope, row locks, SQL natural key, JSONB comparisons, source provenance and allowlist reconstruction, company predicates on every Person query, warning ownership, package export, preserved ActivitySnapshot and migration grants. There is no public route/provider call/queue/new lifecycle in this task. ResolveActivityScopes receives trusted company IDs; callers remain responsible for authorization. Human actor identity is verified against the current active account; system identity uses the existing disabled pinned actor.

A disabled API batch still persists its company summary audit (written=0, ignored=N), with no activity writes; this preserves the required auditable ingestion summary. Global routing warnings remain Task 3's responsibility. The app's Neon-HTTP driver cannot provide interactive transactions at runtime, an existing driver limitation; this self-hosted story uses node-postgres, and the shared type remains structurally compatible with the existing application database union and worker transaction builders. Controller will arrange touched-shard mutation previews and fresh task review.

## Cost trace (estimated, no controller feedback mutation)

- Test generation/refinement: approximately 5 minutes.
- Test execution/setup/wait: approximately 9 minutes including final package rerun.
- Failure analysis: approximately 3 minutes; real fixture enum/text, intentionally disabled system actor, reused fixture identity, strict grant metadata and schema column order were the named causes.
- Implementation/self-review/report: approximately 5 minutes.

Task remains within the approved 270-minute item estimate. Mutation preview cost belongs to the controller's next step.


## Schema preview oracle repair (2026-10-05)

Controller preview on candidate 446feb7 found 12 genuine schema survivors, 0% score. No production fault was accepted as equivalent. Read preview report, TESTING and systematic-debugging before the test edit.

Diagnosis: `scripts/mutation-scope.mjs` hard-wires the schema-static shard to `packages/db/src/schema.test.ts`, via `./apps/web/node_modules/.bin/vitest run --root packages/db --config vitest.config.ts src/schema.test.ts`. `migration-release.integration.test.ts` and `schema-parity.test.ts` are explicitly mutation-incompatible and excluded. Thus full child-process migration parity did not provide a mutation-visible oracle for US-070 schema metadata; the selected schema.test.ts constrained only prior stories.

Added scope: `packages/db/src/schema.test.ts`, the established selected schema-static test seam. Reported scope to controller before commit, as requested. Added one differential real-PostgreSQL test against committed migrations: application enum type/labels, actual column mappings/nullability and evaluated default expressions must agree with catalog rows; application natural-key name/ordered tuple must agree with the independently committed unique constraint. Catalog inspection runs as ledger_app. Defaults are evaluated, so semantically equivalent SQL and literal default declarations agree. No implementation source-text assertion, schema mock, routing/config change, or production edit.

RED: temporarily reproduced exact survivor #6 (`source.default("api")` -> `source.default("")`) under a try/finally source restoration. Ran `rtk pnpm --filter @smp/db exec vitest run src/schema.test.ts -t 'US-070 aligns'`. Exit 1, 1 failed / 3 skipped, 2.52s; exact assertion difference was committed defaultValue `api` vs generated application defaultValue empty. Log `/tmp/us070-schema-red.log`. Schema restored byte-for-byte before ordinary GREEN/type checks.

GREEN: `rtk pnpm --filter @smp/db exec vitest run src/schema.test.ts > /tmp/us070-schema-green.log 2>&1` passed 4/4; final run 2.36s. `rtk pnpm --filter @smp/db type-check` passed. An earlier test-only type check found optional Drizzle unique-name sorting needed null handling; fixed only that test sort, preserving undefined names in the compared descriptors so missing declarations still fail. `rtk git diff --check` passed.

No whole package rerun: production/schema unchanged, prior 301-test package gate remains green; ran only the covering selected test file. No mutation config, subagent, authoritative campaign, preview, test_report or done event. Controller owns the follow-up schema-only re-preview and still-unrun contracts/ingestion previews. Incremental estimated repair cost: ~4 minutes (diagnosis 1m, test generation 2m, RED/GREEN/type/commit 1m); remains within 270-minute estimate.

Repair commit: `fa59f97d4a6d0a47ec9eec35421edbf00d56c193` (`test(US-070): compare ingestion schema with committed database`). Only schema.test.ts was staged. Controller feedback and preview reports remain unstaged/untracked.

## Contracts and ingestion preview oracle repair (2026-10-05)

Consolidated preview: contracts 0 killed / 20 survived / 49 NoCoverage; ingestion 226 killed / 78 survived / 13 NoCoverage (71.29%); schema 11 killed / 1 survived (91.67%). Diagnosis: selected contracts tests never imported the new normalizer. Controller authorized the adjacent discoverable `packages/connectors/src/contracts.test.ts`; no mutation routing/config changed. Re-read testing constraints and used systematic debugging/TDD before edits.

Added bounded direct normalizer contract cases: all allowed paths with distinct valid counts and zero, nullable/missing groups and counts, null-prototype JSON objects, invalid structural shapes and counts, and forbidden getter-backed unknown fields. Exact normalized output proves allowlist reconstruction and omission without examining provider secrets. Disguised arrays/functions separately constrain the structural guards. These target the preview's metric-list, traversal, type, array and count-validation faults rather than coverage volume.

Expanded the existing real DB ingestion fixture to 15 tests. New oracles constrain UUID/date/email/provider/batch service rejection codes; distinct anonymous identities and nullable retries; unsupported/missing account/company and active human actor verification; scoped/global ambiguous trimmed identity rejection; and deterministic matched-Person scope locking. Existing warning assertions now require entity ownership and safe account/date/source metadata. Every successful write is checked against persisted activity/audit rows; rejected paths assert no writes. Ordinary tenant isolation still seeds distinct globally unique emails. Whitespace collisions appear only in a deliberate ambiguous-identity corruption fixture, with restoration in finally.

The concurrency fixture takes a real SHARE table lock on activity_record, starts ingestion, observes its actual ungranted RowExclusiveLock via pg_locks, then attempts the matched Person tenant move with PostgreSQL lock_timeout. SQLSTATE 55P03 proves the held Person share lock; releasing the relation barrier lets ingestion finish, and persisted scope is checked. No sleeps or timing luck. The 1,000-query observation bound prevents an unbounded harness loop.

Representative RED diagnostics (temporary exact mutations restored by finally):
- Contracts mutant #0: chatCounters key changed to empty. `rtk pnpm --filter @smp/connectors exec vitest run src/contracts.test.ts`, exit 1, 3 failed, 210ms; log `/tmp/us070-contracts-red.log`.
- Ingestion mutant #0: UUID validator body removed. `rtk pnpm --filter @smp/db exec vitest run src/analytics-ingestion.integration.test.ts -t 'rejects malformed global'`, exit 1, invalid scope promise resolved with empty batches/warnings instead of rejecting; 4.04s; log `/tmp/us070-uuid-red.log`.
- Ingestion mutant #268: matched Person lock argument true changed to false. `rtk pnpm --filter @smp/db exec vitest run src/analytics-ingestion.integration.test.ts -t 'holds the matched Person'`, exit 1, tenant UPDATE resolved instead of rejecting with 55P03; 3.19s; log `/tmp/us070-person-lock-red.log`.

GREEN after restoration and final test refinements:
- `rtk pnpm --filter @smp/db exec vitest run src/analytics-ingestion.integration.test.ts > /tmp/us070-ingestion-repair-green.log 2>&1`: 15/15 passed, 6.40s.
- `rtk pnpm --filter @smp/connectors exec vitest run src/contracts.test.ts > /tmp/us070-contracts-green.log 2>&1`: 3/3 passed, 388ms.
- `rtk pnpm --filter @smp/db type-check` and `rtk pnpm --filter @smp/connectors type-check`: passed.
- `rtk git diff --check`: passed.

Self-review: no production/schema/migration edits in this repair; fixtures restore modified records and release held transactions in finally. Rejection codes distinguish service-boundary validation from incidental PostgreSQL failures. Allowlist assertions compare expected public data rather than implementation source. Only covering tests ran; the previous 301-test package gate remains green, with no named cause for another full rerun.

`task-1-survivors.md` proposes 32 one-line candidate annotations from the prior preview for independent reviewer approval. They are not accepted exclusions. Error prose/path candidates distinguish specified rejection from unspecified diagnostic wording; schema #5 includes actual Drizzle ColumnBuilder.setName fallback evidence. The next controller preview must establish which IDs remain after these new oracles. No authoritative campaign, routing/config modification, test_report/done, or controller feedback edit.

Incremental repair cost approximately 14 minutes across diagnosis, bounded fixture edits, representative REDs, focused GREENs and report. No predicted overrun of the approved 270-minute item estimate is evident. Controller owns affected-shard re-previews and independent review.

Repair commit: `b13578c` (`test(US-070): constrain activity normalization and ingestion boundaries`), exactly two test files, 182 insertions. Controller feedback and preview reports remain unstaged/untracked.

## Static activation diagnosis and minimal correction (2026-10-05)

Latest controller preview preserved ingestion 92.43% and schema 91.67%, while contracts reached 59.42% (41 killed / 28 survived). Read JSON `reports/mutation/vitest-ae209c3d8c87-42973-1791254412647-d21b65085a3318.json` and round3 log before edits. All 20 allowlist initialization mutants are static:true, coveredBy empty, testsCompleted284; runtime normalizer mutants have coveredBy261–263. The earlier literal-source empty-allowlist RED already demonstrated that expected metrics are asserted. This was activation ordering, not an absent output oracle.

Exact installed-code cause: @stryker-mutator/core9.6.1 `dist/src/mutants/mutant-test-planner.js` constructor builds a nonempty globalTestFilter from explicit project.testFiles. Its static branch passes testFilter:this.globalTestFilter. createMutantRunPlan chooses mutantActivation:testFilter?'runtime':'static', irrespective of isStatic. @stryker-mutator/vitest-runner9.6.1 `dist/src/stryker-setup.js` activates runtime mutants in beforeAll, after source-module evaluation; static activation would occur at setup evaluation. The explicit shard testFiles therefore cause these declaration faults to activate after their initialization. maxTestRunnerReuse1 does not repair this ordering; cache was not established as the root cause. No runner/config edits or new tooling were made.

Controller authorized constructing the private allowlist inside normalizeActivityCounters. Moved only its existing declarations into the function without changing names, field lists, helpers or validation. This executes declaration decisions during calls, when the harness mutant is active. No lazy cache or new lifecycle; small per-record construction cost is the tradeoff. Existing malformed-path case already asserts null/nonobject/array rejection and existing count case asserts string rejection. No redundant new tests were added: surviving #55/#56/#57 are blocked by unchanged Number.isInteger(metric) and metric<0 checks; #29 changes null's Error type, proposed @accepted rather than literal equivalence. Error messages/path labels remain diagnostic-only proposals, requiring reviewer approval.

RED reproduction after refactor: temporarily replaced chatCounters literal with empty under try/finally restoration; `rtk pnpm --filter @smp/connectors exec vitest run src/contracts.test.ts` exited1, 3 failed, log `/tmp/us070-contracts-calltime-red.log`. GREEN restored same command: 3/3 passed,141ms. `rtk pnpm --filter @smp/connectors type-check` passed. Existing tests constrain the exact same allowed outputs before/after this refactor. Only contracts source changed; no ingestion/schema tests or source edits and no full package/ingestion rerun. Controller owns contracts-only preview. Survivor file appended #56 redundant-check and #29 error-type proposals; prior annotations still require independent approval.

Self-review checked that every moved declaration remains private per call and traversal/validation is unchanged. Additional diagnosis/refactor/verification cost approximately 7 minutes; no predicted 270-minute item estimate overrun.

Activation correction commit: `e4f6280` (`refactor(US-070): construct counter allowlist during normalization`). Exactly contracts.ts staged; diff check passed; representative RED duration160ms.

## Independent review I1 correction (round 1/5)

Read task-1-review.md; Important I1 was an actual duplicate-key namespace collision, outside the approved residuals. Provider-only ID x@example.test and valid email provider:x@example.test shared the former provider:x@example.test identity string. Added one real PostgreSQL regression updating Person A's email temporarily, with distinct provider-only/matched records and different counters. It requires one missing_email warning and the independent company A routing batch, successful matched activity persistence, actual Person company A scope and the warning audit. finally restores the Person email.

RED before production edit: `rtk pnpm --filter @smp/db exec vitest run src/analytics-ingestion.integration.test.ts -t 'separates provider-only' > /tmp/us070-identity-namespace-red.log 2>&1`, exit1; 1 failed/15 skipped,2.70s, ACTIVITY_DUPLICATE_CONFLICT from validateRecords line77 during resolveActivityScopes.

Smallest fix: email duplicate identity now uses email:${email}; provider-only identity retains provider:${providerUserId}. Both namespaces are tagged; null/null remains unkeyed, same-email/provider duplicate semantics unchanged. No schema/public-contract/routing/harness change.

First covering GREEN attempt exposed only a regression oracle mistake: activity_record has no companyId property. Changed assertion to persisted personId/counters plus the actual referenced Person company_id. This preserves the tenant oracle through the declared schema rather than inventing a column. Final command `rtk pnpm --filter @smp/db exec vitest run src/analytics-ingestion.integration.test.ts > /tmp/us070-identity-namespace-green-final.log 2>&1`: exit0,16/16 passed,3.58s. `rtk pnpm --filter @smp/db type-check`: passed (also passed before oracle correction). Connectors unchanged; no connector gate rerun required.

Self-review: namespace prefixes differ before any arbitrary provider/email suffix; the date suffix is fixed validated ISO format, preserving key separation. Regression constrains both public consumers and committed output, with global scopes explicitly limited to authorized fixture A/B. Fixture data restored in finally. `rtk git diff --check` passed. No full suite, other shard previews, subagents or self-approval. Controller re-previews changed ingestion only and performs scoped re-review. Existing 24 equivalent/9 accepted residual annotations were independently approved by the prior reviewer; this fix does not self-approve its new mutants.

I1 correction commit: `9dea85ccb70185e112c1e4d1c81a979176494825` (`fix(US-070): separate activity duplicate identity namespaces`), exactly ingestion source/test staged.

## Namespace oracle repair (round 2/5)

Read latest task-1-preview-report.md: ingestion round5 295 killed/23 survived/2 NoCoverage,92.19%; exact genuine #137 replaces email!==null with false at analytics-ingestion.ts:73. Incoming task-1-rereview.md was not yet present when read; controller supplied the scoped review disposition and exact missing contract. Original33 dispositions remain independently approved, #137 unapproved pending repair.

Added one bounded regression in the existing real ingestion integration file: identical normalized emails with nullable provider IDs collapse to one exact routed record; same-email contradictory counters with null IDs and same-email distinct provider IDs reject ACTIVITY_DUPLICATE_CONFLICT through both resolveActivityScopes and ingestActivityBatch; persisted activity and audit tables stay empty on rejection. Authorized scope includes fixture A/B. This kills the fault that chooses only provider keys, which previously bypassed email collapse/contradiction detection. No production correctness defect remains and no production change was made.

RED: temporary exact source replacement `const identity = email !== null ?` to `const identity = false ?`, restored in finally. `rtk pnpm --filter @smp/db exec vitest run src/analytics-ingestion.integration.test.ts -t 'deduplicates by normalized email'` (log `/tmp/us070-email-dedup-red.log`) exited1,1 failed/16 skipped,2.66s: actual routing contains two records versus one expected normalized email record.

GREEN after byte-for-byte restoration: `rtk pnpm --filter @smp/db exec vitest run src/analytics-ingestion.integration.test.ts > /tmp/us070-email-dedup-green.log 2>&1`, exit0,17/17 passed,3.37s. `rtk pnpm --filter @smp/db type-check` passed. Connectors unchanged; no repeated connector gate. `rtk git diff --check` passed.

Self-review: exact collapse oracle observes routing output rather than relying on eventual SQL upsert masking duplicates. Rejection cases assert service code and rollback/no writes, covering distinct provider identity and counter contradictions without fixture mutations. Production unchanged; one test-only edit, no subagents, full suite or preview run. Controller owns touched ingestion preview and independent scoped re-review; no self-approval.

Incoming task-1-rereview.md became available before commit and was read; it confirms I1 addressed, M1 exact #137 gap and unchanged residual approvals. Repair commit: `4b91e690b49980c016b1db5dc66cecf0f199ec12` (`test(US-070): constrain same-email activity duplicate detection`), exactly one test file staged,17 insertions.
