# US-070 covering gate rerun

**FAILED.** One authorized `pnpm check` (idle guard `caffeinate -i`), source `bc76f0c3725920b211722806684ed8a39392310c` / unchanged scored code `927835e559d3b330f3c49436ca095939f3a21216`, mutation base `ed9ff60d9dda6aaf78fae5e9a61d189b1a8e4108`. Check exit **1**, **132.075 seconds**; complete fixture-owning invocation **134.324 seconds**, `2026-10-06T04:51:47.404Z–2026-10-06T04:54:01.728Z`. No additional rerun, cache clear, campaign, source/test/config/harness/tooling-file edit was performed.

Stale-container and mutation preflight passed; preflight remains expected 5 /actual 7 shards (controller reconciliation pending). Type-check **9/9** and lint **8/8**, all cached, passed. Tests failed; build was **not reached**. Constituent stage durations were not separately instrumented; exits preceding test are established by sequential command continuation.

Fresh web suite is green: **120 files**, **926 tests passed /3 skipped**. Fresh worker: **1 failed /17 passed /2 skipped files**, **2 failed /190 passed /8 skipped tests**. Exact failures in `apps/worker/src/runtime.integration.test.ts`:

- Line **507**, cron-shaped deferred-handler execution: expected **3** success logs, observed **2** after its wait.
- Line **627**, analytics-sync deduplication: expected a **skipped** log, observed only a **succeeded** log after its wait.

Both failures were assertions at an approximately **8-second** wait boundary, not Vitest hook/timeouts. Runtime source and this test file are unchanged from mutation base. Their root cause is **not established**, and no product regression or harmless flake classification is asserted. DB was aborted by Turbo after schema (4 tests) and migration-release (115 tests) completed; there is no final DB suite summary. Connectors/config/UI/contracts/domain/notifications replayed cached successful results.

The original 997-second thermal sleep diagnosis is confirmed separately in `integration-diagnosis.md`. The rerun power window has **no Sleep/Wake/DarkWake events**. Thus the two worker failures require their own bounded diagnosis; they cannot be attributed to that original suspension. Prior fresh committed migration apply/verify/parity evidence remains valid on the unchanged scored tree; this run also applied migrations to its check/build database successfully (exit 0 /0.566 seconds).

The child did **not** receive `SMP_TEST_POSTGRES_CLUSTER_URL`; delivered web wrapper owned its test cluster, while DB/worker used delivered Vitest defaults. The check/build owner/app database pair was held in an owned cluster. Fixture and cluster cleanup both succeeded; immediate inventory briefly retained one owned ID, but independent recheck confirms **all owned IDs absent**. Only the two preexisting nous containers are running. No unrelated container was deleted.

Evidence:

- `integration-rerun-pnpm-check.log`, SHA-256 `b8580169b4c06bb1130e2b531e5a509e83bbe5938ecdc04ee0d35aa63a15c587`.
- `integration-rerun-check-db-apply.log`, SHA-256 `d94547ff57830639c06c9a0acff64c9e23d183af2c55a4f013fb10f0d366fd25`.
- `integration-rerun-results.json`: exits/timing/cutoff/ownership/counts; `integration-rerun-before.json` /`integration-rerun-after.json`: resource snapshots.
- `integration-rerun-power-window.log`, SHA-256 `0e6950aca634d9f224e14bebb355f833fe0348ff7ead5d3237d6b29b3ceaded2`.
- Own `CODEX_THREAD_ID`: `01a10f8a-3a6a-7b00-b35d-789a5c95c49d`. Rollout filename pointer (filename lookup only): `/Users/fcolomas/.codex/sessions/2026/10/05/rollout-2026-10-05T23-47-59-01a10f8a-3a6a-7b00-b35d-789a5c95c49d.jsonl`.

No green full-suite/build gate exists yet. One authoritative cold diff campaign remains pending the controller's green gates and review closure. Agent token/cost metadata is unavailable; controller may derive measured counters from the own rollout pointer. Local counts through this report write: **18 functions.exec calls +2 functions.wait calls**, **27 nested shell commands +2 write_stdin calls**; these are not controller-session totals.
