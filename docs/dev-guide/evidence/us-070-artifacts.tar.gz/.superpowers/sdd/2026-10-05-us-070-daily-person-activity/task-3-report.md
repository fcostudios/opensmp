# Task 3 implementation report — US-070

Status: initial implementation and fix round 1 committed; controller owns previews, review and broad gates. The original whole-account atomicity claim below was disproved by I1 and is superseded by the fix-round evidence at the end.
Commit: 8f3d39370c8625f2465d089b6a80e6caf9ee7f97.
Input/source cutoff: cfcfe8d1821cb73b83bc47a379f63b8f35530d68.
Production sources: apps/worker/src/jobs/analytics-activity.ts, apps/worker/src/jobs/deferred.ts.
Additional approved shared source edit: packages/db/src/analytics-ingestion.ts changes only schema/system-ids relative imports to .js, authorized explicitly by controller for worker NodeNext compatibility.
Test sources: apps/worker/src/jobs/analytics-activity.integration.test.ts; deferred.test.ts only analytics no-services story expectation changed to US-070.

## Contract and self-review

Uses existing dispatcher/rest connector factory, KEK reader/decryption, rate limiter, sanitized connector observation session and observation appender. No new composition alias, queue, lifecycle implementation, screen or route.
Global company authority is SELECT active company IDs from the trusted database, never derived from account/email. resolveActivityScopes routes once across those scopes; every shared Person match carries company_id. Provisioning mode is independent: orchestration+api ingests; automated+manual/csv is excluded.
Candidate exclusions before KEK/credentials/network: inactive account/vendor, ingestion_mode other than api, non-api connector_type, no usage data. Unsupported rest protocol or non-email matching is skipped globally; otherwise eligible explicitly targeted unsupported accounts reject ACTIVITY_ACCOUNT_UNSUPPORTED. Unknown/ineligible target yields successful zero.
After complete external pagination, a real account/vendor share lock rechecks eligibility. All company batches and global warnings use that locked PostgreSQL client with shared Drizzle ingest transactions/savepoints. Disabled-in-flight attempts persist neither rows nor warning/sync audits. This implementation atomically commits the whole account attempt; replay remains safe on any later-account failure.
Freshness is pinned from actual injected now before fetch, so slow stale attempts cannot overwrite a newer completed attempt. Processed counts written rows only. Full bodies/headers/credentials are not persisted; replay is reconstructed by shared DB code.
Global analytics_identity_warning audit entries have null company, system actor, account/day/reason/identity only. They are appended once per routed global warning per attempt, not once per company. Audit append failure rejects and rolls back account rows.
Provider-result failures rethrow sanitized ACTIVITY_PROVIDER_ERROR with code SYNC_STALE, vendorAccountId and original retryable flag, matching existing operational reporter classification. Driver exceptions propagate unchanged. No provider raw body attached.
Job drain leaves reusable resources open; deferred handler closes pool/appender in finally, including errors. Lazy connection creation means initialization/KEK failures occur under the handler-owned cleanup boundary. Real pg_stat_activity checks show zero ledger_app backends after successful and failing handler execution. Direct job use repeats drain four times before close.

Concern for reviewer: existing Anthropic credential resolver requires both admin_scoped and analytics even for analytics operations. Worker loads real stored active credentials and keeps separated values; actual activity endpoint selects analytics. Controller instructed preserving existing credential architecture, not fabricating an admin key. No credential architecture rewrite included.

## TDD / commands and results

All commands prefixed rtk and run in /Users/fcolomas/.codex/worktrees/us-070-activity/smp.
Read task brief/constraints/interfaces, RTK, TDD skill + writing-good-tests, CLAUDE/local guide, TESTING and TEST_EFFECTIVENESS_STANDARD before edits. No nested worker AGENTS files found.
1. RED: rtk pnpm --filter @smp/worker exec vitest run src/jobs/analytics-activity.integration.test.ts src/jobs/deferred.test.ts — 3 failed/4 passed, real fixture migrated/seeded; expected succeeded instead got US-026 dependency_not_delivered. No fixture failure.
2. Initial GREEN: same command — 7 passed after new worker/wiring and real stored credential contract.
3. Second RED: rtk pnpm --filter @smp/worker exec vitest run src/jobs/analytics-activity.integration.test.ts -t 'propagates provider' — 1 failed/5 skipped; expected code SYNC_STALE/account/retryable, plain provider Error lacked metadata. Added local provider-failure conversion.
4. Final worker focused: rtk pnpm --filter @smp/worker exec vitest run src/jobs/analytics-activity.integration.test.ts src/jobs/deferred.test.ts — 11 passed, 2 files, 8.64s. Includes global rerun once-per-attempt warning count and audit-failure row rollback.
5. rtk pnpm --filter @smp/worker type-check — pass. Prior run exposed shared NodeNext import extension defect; controller-authorized correction applied.
6. rtk pnpm --filter @smp/db exec vitest run src/analytics-ingestion.integration.test.ts — 17 passed, 3.20s.
7. rtk pnpm --filter @smp/connectors exec vitest run src/providers/anthropic/connector.pact.test.ts -t 'documented per-person activity' — 1 passed/19 skipped, 424ms. This contract backs nested nullable user identities, distinct counters, analytics header and opaque pagination used by worker fixtures.
8. rtk git diff --check — pass; rtk pnpm readiness:check -- US-070 — valid; normal traceability/readiness commit hook passed.
No mutation preview, broad gate, executable verification tooling or generated TESTING edit performed by worker.

## Named AC evidence

AC1 exact UTC day literals: 2026-03-03T00:00Z -> 2026-02-28; 2024-03-03T00:00Z -> leap day 2024-02-29; 2026-01-02T23:59:59Z -> 2025-12-30; 2026-03-01T00:15+14 -> 2026-02-25; 2026-03-03T23:59:59-05 -> 2026-03-01. Every fixture asserts provider date parameter directly.
AC1/4 full pagination-before-persistence: each provider page checks zero day rows; page-two disable produces processed zero, no rows/audits.
AC2 two companies' correct Person IDs retain independent 2/9 counters; later global rerun preserves IDs and refreshes synced_at; concurrent equivalent runs yield [0,1] writes, slow older completion yields zero and preserves 99 counters; equal-time contradictory 98 rejects.
AC3 manual/csv targeted accounts lack credentials, use no KEK configuration and transport that throws on every call; both succeed zero and observations remain unchanged. API orchestration account succeeds.
AC4 missing and unmatched reasons/identity are durable null-company audits. Two warnings after targeted attempt, four after second global attempt across two companies (no multiplication by company). Provider and database failures propagate; revoked audit INSERT leaves zero rows/warnings for the attempted date. Sanitized observation operation sync_activity/provisioningActionId null, no analytics credential; all handler resources close.

Task boundary estimate: approximately 7 minutes implementation/test execution; bounded task remains comfortably within approved 270-minute work estimate. Test generation/execution/failure-analysis costs not independently metered by this tool surface; no invented numeric token/API cost provenance.
Transcript pointer: live task /root/controller_resume/task3; no readily available persistent transcript path was inspected.


# Fix round 1 of 5 — I1, I2 and M1

Base: 8f3d39370c8625f2465d089b6a80e6caf9ee7f97.
Commit: 927835e559d3b330f3c49436ca095939f3a21216.
Only four Task3 paths committed: analytics-activity.ts, analytics-activity.integration.test.ts, deferred.ts, deferred.test.ts. Shared DB/provider/credential architecture unchanged. No fixture/harness/router/config/tooling edits, new external interaction, owned mocks, mutation preview or broad gate.

## Behavioral RED and repair

Read exact review/preview residuals. Added real database triggers/advisory synchronization, no owned-code mocks. Initially blocking a second company activity insert was insufficient to expose I1 because that company's helper reacquires its own account lock; corrected the adversarial fault point to the later global warning after first company completion, before production repair.
RED command: rtk pnpm --filter @smp/worker exec vitest run src/jobs/analytics-activity.integration.test.ts -t 'holds account opt-in|rolls back earlier company'. Result 2 failed/6 skipped, 2.72s. Exact failures: disabling account returned successful UPDATE instead of PostgreSQL 55P03; late global-warning trigger raised after two earlier company rows were committed, leaving count=2 rather than count=0.
Production repair uses one actual db.transaction callback on the explicitly owned pg client. Its transaction object is passed to the trusted matcher, ingestActivityBatch and global warning append; nested ingestActivityBatch transactions now create real savepoints. No manual BEGIN/COMMIT/ROLLBACK remains. The postfetch account/vendor FOR SHARE locks remain held until the outer callback completes. Zero-eligibility returns through the callback, so Drizzle finalizes that transaction normally. Failed warning inserts unwind both savepoint work and outer transaction before client release.
Immediate GREEN for those two I1 tests: 2 passed/6 skipped, 3.02s. Later strengthened opt-in test verifies both account disable and vendor usage disable reject with 55P03 at the global-warning gate. After releasing gate it asserts successful processed=1 and no open job transaction before closing. Later-warning failure test asserts no activity rows and no audits for the failed day, and no open transaction before close. Cleanup assertions occur inside guarded test bodies, with unconditional test-resource cleanup in finally.

## Exact residual repair contracts

Worker 3: sixty-one opaque analytics pages consume the real existing limiter. Injected sleep advances injected clock. Requests 1..60 occur at 10:00; exact sleep=[60000]; request61 and persisted succeeded observation are at 10:01. Removing clock prevents the budget refresh wait and fails this oracle. GET/path/analytics key asserted against existing per-person Pact-backed transport. No external 429 mock or provider contract change.
Worker 10/11: invalid Date rejects at ACTIVITY_TIME_INVALID with missing KEK and transport that throws on any call.
Worker 16/21/22: invalid UUID plus prefix/suffix corruption rejects at ACTIVITY_VENDOR_INVALID before credentials/provider.
Worker 46/59/60: real otherwise eligible API account changed to scim; global unsupported-only drain returns exact {processed:0} without KEK, targeted drain rejects ACTIVITY_ACCOUNT_UNSUPPORTED; restored in finally.
Worker 113: global warning checks entity_type VendorAccount, entity_id account, actor_user_id SYSTEM_USER_ID, null company, exact account/day/reason/identity allowlist.
Worker 99/116/119: manual outer transaction code eliminated in favor of real Drizzle transaction; real lock and later-warning rollback oracles constrain actual lifetime and atomicity.
Worker 106: disabled-in-flight test inspects real same-role pg_stat_activity after drain, before close. No other ledger_app session is idle in transaction or carries xact_start. Same oracle covers success/late failure/invalid/unsupported/throttled attempts.
Deferred 2/5/6/7/8: deferred.test.ts statically imports established analytics-activity.integration.test.ts scenarios. This bounded test import relationship makes the selected deferred seam execute real services-backed handler/drain/processed/finally oracles without mocking job factory or changing routing/config. Integration file remains direct worker seam. Execution duplication is deliberate: 11 worker scenarios run in each seam plus five existing deferred tests, 27 total assertions-based test executions, about12s total. Services-backed success and failure scenarios verify zero ledger_app backends after handler finally.
These are effectiveness candidates for controller-owned rerouted preview; no claim that mutant IDs are stable or independently killed before preview rerun.

## Final commands/results

rtk pnpm --filter @smp/worker exec vitest run src/jobs/analytics-activity.integration.test.ts src/jobs/deferred.test.ts — 27 passed across 2 files, final 12.16s (23:04:06 local runner timestamp).
rtk pnpm --filter @smp/worker type-check — pass after final source edits.
rtk git diff --check — pass. Normal commit hook/readiness guard passed.
One interim focused run had 25pass/2fail because a new test mistakenly queried nonexistent observation enum phase completed; corrected test query to existing succeeded. This was a test fixture/query correction, not production behavioral RED.
Formatting: expanded touched new source/test additions into consistent two-space indentation and visible transaction/try/finally blocks; deferred analytics options and lifetime expanded. Existing installed TypeScript printer was used once through a transient stdin script; no tooling file/dependency added. Initial root import of TypeScript failed resolution without changing files; retried the existing worker package's TypeScript path successfully.

Self-review: all shared ingestion calls receive the actual transaction, not root Drizzle; raw global warnings are inside it; eligible-zero callback finalizes transaction; client release is always finally; handler owns close. Test triggers target only designated test days/actions and are dropped in finally. No data or schema migration change. Global warning metadata remain source-safe. Shared import and two-role credential rulings remain as previously authorized.

Cost metadata: own CODEX_THREAD_ID=01a10f47-ca1f-7783-9933-4f3aca050898. Transcript file /Users/fcolomas/.codex/sessions/2026/10/05/rollout-2026-10-05T22-35-25-01a10f47-ca1f-7783-9933-4f3aca050898.jsonl. Located by exact filename glob only; no unrelated transcripts read. Approximately8minutes for this repair, forecast remains within approved270minutes. Test generation/execution/failure analysis costs not independently metered here; actual transcript metadata is provided for controller cost closure.
