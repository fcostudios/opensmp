# US-070 final runtime oracle correction

**GREEN, committed** as `e03e465e3e8be975bcaf8ca05662f0bf93bfb25a` — `test(worker): align analytics runtime oracles (US-070)`. Parent `bc76f0c3725920b211722806684ed8a39392310c`; only committed path is `apps/worker/src/runtime.integration.test.ts` (48 insertions /4 deletions). No production, configuration, harness, migration, timeout, concurrency or dependency change. No new test or owned mock. Controller feedback/readiness and unrelated untracked files were left untouched.

## Cause and corrected behavioral oracles

The supplied RED trace matches delivered source: `createDeferredJobHandlers.analyticsSync` now calls the real activity drain, converts its count with `successfulJob`, and closes it. `createAnalyticsActivityJob.drain` returns `processed: 0` when no eligible account exists. Both existing runtime tests still expected the previous deferred-stub `skipped` outcome. The unchanged 8-second assertion deadline was reached because those expectations cannot match delivered behavior; no timeout expansion was needed.

- Existing cron-shaped test: rename “deferred handler” to “handler”; assert six inserted IDs and six real pg-boss jobs in `completed` state. Keep one result log per job and the existing invite/alert success expectations. Assert analytics job ID/queue has `processed: 0`, `status: succeeded`; require exactly the member-sync and close-precheck jobs to remain skipped (two rather than three). Assert the durable execution under the literal coordinator key `analytics-sync:scheduled:2026-08-05` is exactly `{ job_name: analyticsSync, status: succeeded, result: { processed: 0, status: succeeded } }`.
- Existing vendor deduplication test: retain missing-account rejection, UUID first enqueue and null duplicate enqueue. Assert the real `analytics-sync` singleton key `analytics-sync:00000000-0000-0000-0000-000000000710:2026-07-25` has exactly one job, the first ID, completed, with the requested vendor account in its payload. Pin the successful zero-work result log to that first ID. Assert exactly one successful durable analytics execution/result for that literal vendor/date key.

These are queue/execution-state contract assertions, not log-only tests. The tests exercise empty/no-eligible-account analytics behavior; populated ingestion and tenant isolation remain covered by their existing dedicated activity tests.

## RED evidence (supplied covering gate, not rerun by this worker)

Command: `caffeinate -i pnpm check` on parent `bc76f0c3725920b211722806684ed8a39392310c`; exit **1**, reported check duration **132.075 s**. Source: `integration-rerun-report.md` and `integration-rerun-pnpm-check.log` lines 872–927.

- Old line 507: cron test `toHaveLength(3)` expected 3 skipped logs, received **2**.
- Old line 627: vendor dedup test expected analytics `{ processed: 0, status: skipped }`; received first job `{ processed: 0, status: succeeded }`.
- Worker total: **2 failed /190 passed /8 skipped** tests; **1 failed /17 passed /2 skipped** files. The supplied report establishes web **926 passed /3 skipped**, and build not reached.

## GREEN commands and evidence

All shell commands used RTK (the initial delegated brief read preceded its RTK instruction).

- `rtk pnpm readiness:check -- US-070` — exit **0**, readiness valid before edit.
- `rtk proxy sh -c 'caffeinate -i pnpm --filter @smp/worker test src/runtime.integration.test.ts > .superpowers/sdd/2026-10-05-us-070-daily-person-activity/final-runtime-oracle-green.log 2>&1; result=$?; tail -n 35 .superpowers/sdd/2026-10-05-us-070-daily-person-activity/final-runtime-oracle-green.log; exit "$result"'` — exit **0**, **1 file /14 tests passed**, Vitest duration **8.64 s** (tests **8.21 s**). No skipped tests.
- `rtk proxy sh -c 'pnpm --filter @smp/worker type-check > .superpowers/sdd/2026-10-05-us-070-daily-person-activity/final-runtime-oracle-typecheck.log 2>&1; result=$?; cat .superpowers/sdd/2026-10-05-us-070-daily-person-activity/final-runtime-oracle-typecheck.log; exit "$result"'` — exit **0**, `tsc --noEmit`, zero diagnostics.
- `rtk git diff --check` — exit **0**.
- Scoped commit — exit **0**, repository hooks accepted it.

Log SHA-256: GREEN `9a99dcf03752f93b8b88823c57c81786f60bb8ed49eaa9cfdf90830a0cde8e9f`; type-check `75e2008b8ede426d6ddfda4bf06976c4cb51e2930f2c1f71e28efecca8fbf9ac`.

## Real-resource cleanup and limits

Focused execution used the delivered fixture with real PostgreSQL 16 and pg-boss. Test-owned connections close through `queryAsOwner` finally blocks, runtime stop finally blocks, and suite `fixture.stop()`; the suite cleanup passed. Before the run only `nous-keycloak` and `nous-db` were running. After the run the same two were running; `docker ps -a` showed no newly retained test container (only older unrelated stopped containers). `/var/folders/*/*/T/ledger-runtime-*` inventory was empty, consistent with private KEK-directory cleanup. No unrelated resource was deleted.

No preview, full gate or cold campaign was run. Controller still owes its selected preflight/preview intersections, combined scoped re-review, covering full gate and ONE authoritative cold diff campaign; this focused GREEN is not full-story completion.

Own metadata pointer: `CODEX_THREAD_ID=01a10f92-0adb-7313-bb95-9ef83b4b923f`; rollout filename lookup `/Users/fcolomas/.codex/sessions/2026/10/05/rollout-2026-10-05T23-56-31-01a10f92-0adb-7313-bb95-9ef83b4b923f.jsonl`. Token/cost counters not directly available. No subagents.
